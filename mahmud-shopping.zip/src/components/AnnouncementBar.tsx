import React, { useState, useEffect } from 'react';
import { Sparkles, ArrowRight, X, Percent } from 'lucide-react';

export default function AnnouncementBar() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  const announcements = [
    { text: 'USE CODE "MAHMUD20" FOR 20% OFF ON ORDERS ABOVE $200!', icon: <Percent className="w-4 h-4 text-[#E60023] animate-bounce" /> },
    { text: 'ELEVATE YOUR LUXURY: AW26 COLLECTION IS NOW LIVE', icon: <Sparkles className="w-4 h-4 text-[#E60023]" /> },
    { text: 'FREE SHIPPING ON HAUTE COUTURE ABOVE $500', icon: <ArrowRight className="w-4 h-4 text-[#E60023]" /> }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % announcements.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  if (!isVisible) return null;

  return (
    <div id="announcement-bar" className="bg-white text-black py-2.5 px-4 relative border-b border-neutral-200 text-xs tracking-widest font-mono select-none overflow-hidden transition-all duration-300">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        {/* Empty left spacer to center the text */}
        <div className="hidden sm:block w-24"></div>
        
        <div className="flex items-center justify-center gap-3 w-full text-center animate-fade-in">
          {announcements[currentIndex].icon}
          <span className="font-semibold uppercase tracking-widest text-black hover:text-[#E60023] transition-colors duration-200">
            {announcements[currentIndex].text}
          </span>
        </div>

        <div className="flex items-center gap-4">
          <button 
            onClick={() => setIsVisible(false)}
            className="text-neutral-400 hover:text-black transition-colors p-1"
            title="Dismiss"
          >
            <X className="w-3.5 h-3.5 text-neutral-400" />
          </button>
        </div>
      </div>
    </div>
  );
}
