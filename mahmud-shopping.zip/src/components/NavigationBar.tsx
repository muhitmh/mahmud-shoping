import React, { useState, useEffect, useRef } from 'react';
import { Search, Heart, ShoppingBag, User, ShieldAlert, Menu, X, Moon, Sun, ChevronRight, LogOut, LayoutDashboard } from 'lucide-react';
import { Product } from '../types';

interface NavigationBarProps {
  currentView: string;
  onNavigate: (view: string, params?: any) => void;
  cartCount: number;
  wishlistCount: number;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  currentUser: any;
  onLogout: () => void;
  products: Product[];
  isDarkMode: boolean;
  setIsDarkMode: (val: boolean) => void;
}

export default function NavigationBar({
  currentView,
  onNavigate,
  cartCount,
  wishlistCount,
  searchQuery,
  setSearchQuery,
  currentUser,
  onLogout,
  products,
  isDarkMode,
  setIsDarkMode
}: NavigationBarProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [searchSuggestions, setSearchSuggestions] = useState<Product[]>([]);
  const [isAccountDropdownOpen, setIsAccountDropdownOpen] = useState(false);
  
  const searchRef = useRef<HTMLDivElement>(null);
  const accountRef = useRef<HTMLDivElement>(null);

  // Filter suggestions based on searchQuery
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchSuggestions([]);
      return;
    }
    const filtered = products.filter(p => 
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.category.toLowerCase().includes(searchQuery.toLowerCase())
    ).slice(0, 5);
    setSearchSuggestions(filtered);
  }, [searchQuery, products]);

  // Click outside listener for dropdowns
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsSearchFocused(false);
      }
      if (accountRef.current && !accountRef.current.contains(event.target as Node)) {
        setIsAccountDropdownOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSearchFocused(false);
    onNavigate('search', { query: searchQuery });
  };

  const navLinks = [
    { label: 'HOME', view: 'home' },
    { label: 'SHOP', view: 'shop' },
    { label: 'CATEGORIES', view: 'categories' },
    { label: 'ABOUT US', view: 'about' },
    { label: 'CONTACT', view: 'contact' },
    { label: 'FAQ', view: 'faq' }
  ];

  return (
    <nav id="navigation-bar" className="sticky top-0 z-50 transition-all duration-300 bg-white border-b border-neutral-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          
          {/* Logo */}
          <div 
            onClick={() => onNavigate('home')} 
            className="flex flex-col cursor-pointer select-none group"
          >
            <span className="font-extrabold text-2xl sm:text-3xl tracking-[0.15em] text-black transition-colors duration-200">
              MAHMUD
            </span>
            <span className="text-[9px] font-bold tracking-[0.45em] text-[#E60023] -mt-1 group-hover:tracking-[0.55em] transition-all duration-300">
              SHOPPING
            </span>
          </div>

          {/* Desktop Navigation Links */}
          <div className="hidden lg:flex items-center space-x-8">
            {navLinks.map((link) => (
              <button
                key={link.view}
                onClick={() => onNavigate(link.view)}
                className={`text-xs font-bold tracking-widest relative py-2 transition-colors duration-200 ${
                  currentView === link.view
                    ? 'text-[#E60023]'
                    : 'text-black hover:text-[#E60023]'
                }`}
              >
                {link.label}
                {currentView === link.view && (
                  <span className="absolute bottom-0 left-0 w-full h-[2px] bg-[#E60023] rounded-full" />
                )}
              </button>
            ))}
          </div>

          {/* Search Bar & Actions */}
          <div className="hidden md:flex items-center space-x-6">
            
            {/* Live Search Input */}
            <form onSubmit={handleSearchSubmit} ref={searchRef} className="relative w-64 xl:w-80">
              <input
                type="text"
                placeholder="Search premium collections..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => setIsSearchFocused(true)}
                className="w-full text-xs bg-white border border-neutral-200 rounded-full py-2.5 pl-10 pr-4 outline-none focus:border-[#E60023] text-black transition-all duration-300 shadow-inner"
              />
              <Search className="absolute left-3.5 top-3 w-4 h-4 text-[#E60023]" />
              
              {/* Search Suggestions Dropdown */}
              {isSearchFocused && searchQuery.trim() && (
                <div className="absolute top-12 left-0 w-full bg-white border border-neutral-200 rounded-xl shadow-2xl p-2 z-50 max-h-96 overflow-y-auto">
                  <div className="p-2 text-[10px] uppercase tracking-wider text-neutral-400 font-bold border-b border-neutral-100">
                    Product Suggestions
                  </div>
                  {searchSuggestions.length > 0 ? (
                    <div className="space-y-1 mt-2">
                      {searchSuggestions.map((prod) => (
                        <div
                          key={prod.id}
                          onClick={() => {
                            setIsSearchFocused(false);
                            onNavigate('product-details', { productId: prod.id });
                          }}
                          className="flex items-center gap-3 p-2 hover:bg-neutral-50 rounded-lg cursor-pointer transition-colors duration-200"
                        >
                          <img src={prod.images[0]} alt={prod.name} className="w-10 h-10 object-cover rounded-md" />
                          <div className="flex-1 min-w-0">
                            <h4 className="text-xs font-bold text-black truncate">{prod.name}</h4>
                            <p className="text-[10px] text-neutral-550 truncate">{prod.category}</p>
                          </div>
                          <span className="text-xs font-bold text-[#E60023]">${prod.price}</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="p-4 text-center text-xs text-neutral-500">
                      No matches found for "{searchQuery}"
                    </div>
                  )}
                  <div className="p-2 border-t border-neutral-100 mt-2 text-center">
                    <button
                      type="submit"
                      className="text-[10px] font-bold text-[#E60023] hover:underline"
                    >
                      View all results
                    </button>
                  </div>
                </div>
              )}
            </form>

            {/* Utility Icons */}
            <div className="flex items-center space-x-4">
              
              {/* Wishlist Link */}
              <button
                onClick={() => onNavigate('wishlist')}
                className="p-2 text-[#E60023] hover:opacity-85 transition-colors relative"
                title="Wishlist"
              >
                <Heart className={`w-5 h-5 ${wishlistCount > 0 ? 'fill-[#E60023]' : ''}`} />
                {wishlistCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-[#E60023] text-white text-[9px] font-bold rounded-full w-4 h-4 flex items-center justify-center animate-pulse">
                    {wishlistCount}
                  </span>
                )}
              </button>

              {/* Shopping Cart Link */}
              <button
                onClick={() => onNavigate('cart')}
                className="p-2 text-[#E60023] hover:opacity-85 transition-colors relative"
                title="Shopping Bag"
              >
                <ShoppingBag className="w-5 h-5" />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-[#E60023] text-white text-[9px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </button>

              {/* User Account / Admin Panel Menu */}
              <div ref={accountRef} className="relative">
                <button
                  onClick={() => setIsAccountDropdownOpen(!isAccountDropdownOpen)}
                  className="p-2 text-[#E60023] hover:opacity-85 transition-colors flex items-center gap-1"
                  title="My Account"
                >
                  <User className="w-5 h-5" />
                  {currentUser && (
                    <span className="w-1.5 h-1.5 bg-[#E60023] rounded-full animate-ping" />
                  )}
                </button>

                {/* Account Dropdown */}
                {isAccountDropdownOpen && (
                  <div className="absolute right-0 mt-3 w-56 bg-white border border-neutral-200 rounded-xl shadow-2xl p-2 z-50">
                    {currentUser ? (
                      <div>
                        <div className="p-3 border-b border-neutral-100 mb-2">
                          <p className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider">Signed in as</p>
                          <p className="text-xs font-bold text-black truncate">{currentUser.name}</p>
                          <p className="text-[10px] text-neutral-500 truncate">{currentUser.email}</p>
                          {currentUser.role === 'admin' && (
                            <span className="mt-1.5 inline-flex items-center px-1.5 py-0.5 rounded text-[8px] font-bold bg-red-100 text-[#E60023] uppercase tracking-widest">
                              Administrator
                            </span>
                          )}
                        </div>
                        
                        <div className="space-y-1">
                          <button
                            onClick={() => {
                              setIsAccountDropdownOpen(false);
                              onNavigate('dashboard');
                            }}
                            className="w-full flex items-center gap-2 p-2 hover:bg-neutral-50 rounded-lg text-xs font-bold text-black hover:text-[#E60023] text-left transition-colors"
                          >
                            <User className="w-4 h-4 text-[#E60023]" />
                            My Dashboard
                          </button>

                          {currentUser.role === 'admin' && (
                            <button
                              onClick={() => {
                                setIsAccountDropdownOpen(false);
                                onNavigate('admin');
                              }}
                              className="w-full flex items-center gap-2 p-2 hover:bg-red-50 rounded-lg text-xs font-bold text-[#E60023] text-left transition-colors"
                            >
                              <ShieldAlert className="w-4 h-4" />
                              Admin Panel
                            </button>
                          )}

                          <button
                            onClick={() => {
                              setIsAccountDropdownOpen(false);
                              onLogout();
                            }}
                            className="w-full flex items-center gap-2 p-2 hover:bg-neutral-50 rounded-lg text-xs font-bold text-black hover:text-[#E60023] text-left transition-colors"
                          >
                            <LogOut className="w-4 h-4 text-[#E60023]" />
                            Sign Out
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="p-3 text-center space-y-3">
                        <p className="text-xs text-neutral-500">Unlock luxury personalization, order histories, and exclusive discounts.</p>
                        <button
                          onClick={() => {
                            setIsAccountDropdownOpen(false);
                            onNavigate('login');
                          }}
                          className="w-full bg-[#E60023] hover:bg-red-750 text-white py-2 rounded-lg text-xs font-bold tracking-widest transition-all duration-300"
                        >
                          SIGN IN
                        </button>
                        <button
                          onClick={() => {
                            setIsAccountDropdownOpen(false);
                            onNavigate('register');
                          }}
                          className="w-full text-xs font-bold text-black hover:text-[#E60023] hover:underline"
                        >
                          Create Account
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>

            </div>
          </div>

          {/* Mobile Actions & Hamburger */}
          <div className="flex items-center space-x-3 lg:hidden">
            {/* Cart Icon Mobile */}
            <button
              onClick={() => onNavigate('cart')}
              className="p-2 text-[#E60023] relative"
            >
              <ShoppingBag className="w-4.5 h-4.5" />
              {cartCount > 0 && (
                <span className="absolute top-1 right-1 bg-[#E60023] text-white text-[8px] font-bold rounded-full w-3.5 h-3.5 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Admin Badge Quick access on mobile if admin */}
            {currentUser?.role === 'admin' && (
              <button
                onClick={() => onNavigate('admin')}
                className="p-2 text-[#E60023]"
                title="Admin Panel"
              >
                <LayoutDashboard className="w-4.5 h-4.5" />
              </button>
            )}

            {/* Hamburger Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2 text-[#E60023] hover:text-[#E60023] transition-colors"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden border-t border-neutral-200 bg-white p-4 space-y-4 animate-slide-down">
          {/* Mobile Search */}
          <form onSubmit={handleSearchSubmit} className="relative">
            <input
              type="text"
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs bg-white border border-neutral-200 rounded-full py-2.5 pl-10 pr-4 outline-none text-black"
            />
            <Search className="absolute left-3.5 top-3 w-4 h-4 text-[#E60023]" />
          </form>

          {/* Navigation Links */}
          <div className="space-y-1.5">
            {navLinks.map((link) => (
              <button
                key={link.view}
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onNavigate(link.view);
                }}
                className={`w-full flex justify-between items-center px-4 py-3 text-xs font-bold tracking-widest rounded-lg text-left ${
                  currentView === link.view
                    ? 'bg-red-50 text-[#E60023]'
                    : 'text-black hover:bg-neutral-50 hover:text-[#E60023]'
                }`}
              >
                {link.label}
                <ChevronRight className="w-4 h-4 opacity-50" />
              </button>
            ))}
          </div>

          {/* Bottom user accounts inside mobile navigation */}
          <div className="pt-4 border-t border-neutral-100 flex flex-col gap-2">
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                onNavigate('wishlist');
              }}
              className="w-full flex items-center justify-between px-4 py-2 text-xs font-bold text-black"
            >
              <span className="flex items-center gap-2">
                <Heart className="w-4 h-4 text-[#E60023]" /> Wishlist
              </span>
              <span className="bg-neutral-100 px-2 py-0.5 rounded text-[10px] font-bold text-[#E60023]">
                {wishlistCount}
              </span>
            </button>

            {currentUser ? (
              <div className="p-3 bg-neutral-50 rounded-xl space-y-2 mt-2">
                <p className="text-[10px] text-neutral-400 font-bold uppercase">Logged in as {currentUser.name}</p>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      onNavigate('dashboard');
                    }}
                    className="flex-1 bg-[#E60023] text-white py-2 rounded-lg text-[10px] font-bold tracking-widest text-center"
                  >
                    DASHBOARD
                  </button>
                  <button
                    onClick={() => {
                      setIsMobileMenuOpen(false);
                      onLogout();
                    }}
                    className="flex-1 bg-neutral-200 text-black py-2 rounded-lg text-[10px] font-bold tracking-widest text-center"
                  >
                    SIGN OUT
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex gap-2 mt-2">
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onNavigate('login');
                  }}
                  className="flex-1 bg-[#E60023] text-white py-2.5 rounded-lg text-xs font-bold tracking-widest text-center"
                >
                  SIGN IN
                </button>
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onNavigate('register');
                  }}
                  className="flex-1 bg-black text-white py-2.5 rounded-lg text-xs font-bold tracking-widest text-center"
                >
                  REGISTER
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
