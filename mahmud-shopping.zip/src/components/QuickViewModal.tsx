import React, { useState } from 'react';
import { X, Star, Heart, ShoppingBag, Eye, ShieldAlert, BadgeCheck } from 'lucide-react';
import { Product } from '../types';

interface QuickViewModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, size: string, color: { name: string; hex: string }, qty: number) => void;
  onAddToWishlist: (product: Product) => void;
  onNavigate: (view: string, params?: any) => void;
  isInWishlist: boolean;
}

export default function QuickViewModal({
  product,
  onClose,
  onAddToCart,
  onAddToWishlist,
  onNavigate,
  isInWishlist
}: QuickViewModalProps) {
  if (!product) return null;

  const [selectedSize, setSelectedSize] = useState(product.sizes[0] || 'M');
  const [selectedColor, setSelectedColor] = useState(product.colors[0] || { name: 'Default', hex: '#000000' });
  const [quantity, setQuantity] = useState(1);
  const [activeImgIndex, setActiveImgIndex] = useState(0);

  const discountAmount = product.originalPrice ? product.originalPrice - product.price : 0;
  const discountPercent = product.originalPrice ? Math.round((discountAmount / product.originalPrice) * 100) : 0;

  const handleAddToCart = () => {
    onAddToCart(product, selectedSize, selectedColor, quantity);
    onClose();
  };

  const handleBuyNow = () => {
    onAddToCart(product, selectedSize, selectedColor, quantity);
    onClose();
    onNavigate('checkout');
  };

  return (
    <div id="quickview-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 md:p-10">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/70 backdrop-blur-md" onClick={onClose}></div>

      {/* Content Card */}
      <div className="relative w-full max-w-5xl bg-white dark:bg-neutral-900 rounded-3xl overflow-hidden shadow-2xl border border-neutral-100 dark:border-neutral-800 z-10 flex flex-col md:flex-row animate-scale-up max-h-[90vh] md:max-h-[85vh]">
        
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-white/80 dark:bg-neutral-800/80 text-neutral-800 dark:text-white hover:bg-red-600 hover:text-white transition-all shadow-md"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Left: Gallery Column */}
        <div className="w-full md:w-1/2 bg-neutral-50 dark:bg-neutral-950 p-6 flex flex-col justify-between overflow-y-auto">
          <div className="relative flex-1 flex items-center justify-center min-h-[250px] md:min-h-[350px]">
            <img
              src={product.images[activeImgIndex]}
              alt={product.name}
              className="max-h-[320px] md:max-h-[400px] object-contain rounded-2xl transition-all duration-300 transform hover:scale-105"
            />
            {discountPercent > 0 && (
              <span className="absolute top-2 left-2 bg-red-600 text-white text-[10px] font-bold px-2.5 py-1 rounded-full tracking-widest font-mono">
                -{discountPercent}% OFF
              </span>
            )}
            {product.isFlashSale && (
              <span className="absolute top-2 right-2 bg-neutral-950 text-red-500 text-[10px] font-bold px-2.5 py-1 rounded-full tracking-widest font-mono border border-red-500 animate-pulse">
                ⚡ FLASH SALE
              </span>
            )}
          </div>

          {/* Thumbnails */}
          {product.images.length > 1 && (
            <div className="flex gap-2.5 justify-center mt-4">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImgIndex(idx)}
                  className={`w-14 h-14 rounded-lg overflow-hidden border-2 transition-all ${
                    idx === activeImgIndex ? 'border-red-600 scale-105 shadow-md' : 'border-neutral-200 dark:border-neutral-800 opacity-60 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right: Spec/Control Column */}
        <div className="w-full md:w-1/2 p-6 sm:p-8 flex flex-col justify-between overflow-y-auto bg-white dark:bg-neutral-900 border-t md:border-t-0 md:border-l border-neutral-100 dark:border-neutral-800">
          
          <div className="space-y-4">
            
            {/* Header details */}
            <div>
              <span className="text-[10px] uppercase font-bold tracking-[0.2em] text-red-600 dark:text-red-400">
                {product.category}
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-neutral-900 dark:text-white tracking-tight mt-1">
                {product.name}
              </h2>
              {product.tagline && (
                <p className="text-xs text-neutral-500 dark:text-neutral-400 italic mt-0.5">{product.tagline}</p>
              )}
            </div>

            {/* Ratings / Quick Stats */}
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1 bg-amber-50 dark:bg-amber-950/20 px-2 py-0.5 rounded-md text-amber-500">
                <Star className="w-3.5 h-3.5 fill-amber-500" />
                <span className="text-xs font-bold">{product.rating}</span>
              </div>
              <span className="text-xs text-neutral-400">{product.reviewsCount} verified reviews</span>
              <span className="text-neutral-300 dark:text-neutral-700">|</span>
              <span className="flex items-center gap-1 text-xs text-emerald-600 dark:text-emerald-400">
                <BadgeCheck className="w-4 h-4" /> 100% Authentic
              </span>
            </div>

            {/* Price section */}
            <div className="flex items-baseline gap-3 pt-2">
              <span className="text-2xl font-black text-neutral-950 dark:text-white">
                ${product.price}
              </span>
              {product.originalPrice && (
                <span className="text-sm text-neutral-400 line-through">
                  ${product.originalPrice}
                </span>
              )}
            </div>

            <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
              {product.description}
            </p>

            {/* Color Selection */}
            {product.colors.length > 0 && (
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-wider text-neutral-400">
                  Select Color: <span className="text-neutral-900 dark:text-white font-black">{selectedColor.name}</span>
                </label>
                <div className="flex gap-2">
                  {product.colors.map((color) => (
                    <button
                      key={color.name}
                      onClick={() => setSelectedColor(color)}
                      className={`w-8 h-8 rounded-full border-2 p-0.5 transition-transform ${
                        selectedColor.name === color.name ? 'border-red-600 scale-110 shadow' : 'border-transparent'
                      }`}
                      style={{ backgroundColor: color.hex }}
                      title={color.name}
                    >
                      <span className="sr-only">{color.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Size Selection */}
            {product.sizes.length > 0 && (
              <div className="space-y-2 pt-1">
                <div className="flex justify-between">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-neutral-400">
                    Select Size: <span className="text-neutral-900 dark:text-white font-black">{selectedSize}</span>
                  </label>
                  <button 
                    onClick={() => { onClose(); onNavigate('faq'); }}
                    className="text-[10px] font-bold text-red-600 hover:underline tracking-wider"
                  >
                    SIZE GUIDE
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map((size) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${
                        selectedSize === size
                          ? 'border-neutral-950 bg-neutral-950 text-white dark:border-white dark:bg-white dark:text-neutral-950'
                          : 'border-neutral-200 dark:border-neutral-800 hover:border-red-500'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity selection and Stock info */}
            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center border border-neutral-200 dark:border-neutral-800 rounded-xl">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3.5 py-2 text-neutral-500 hover:text-neutral-800 transition-colors"
                >
                  -
                </button>
                <span className="px-3 py-2 text-xs font-bold text-neutral-800 dark:text-white">{quantity}</span>
                <button
                  onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                  className="px-3.5 py-2 text-neutral-500 hover:text-neutral-800 transition-colors"
                >
                  +
                </button>
              </div>

              <div className="text-right">
                <p className={`text-xs font-bold ${product.stock <= 5 ? 'text-red-500' : 'text-neutral-500'}`}>
                  {product.stock <= 5 ? `Only ${product.stock} left in stock!` : `${product.stock} items available`}
                </p>
                <div className="w-24 bg-neutral-200 dark:bg-neutral-800 h-1.5 rounded-full mt-1 overflow-hidden ml-auto">
                  <div 
                    className={`h-full rounded-full ${product.stock <= 5 ? 'bg-red-600' : 'bg-green-500'}`} 
                    style={{ width: `${Math.min(100, (product.stock / 30) * 100)}%` }}
                  />
                </div>
              </div>
            </div>

          </div>

          {/* Action Buttons */}
          <div className="pt-6 border-t border-neutral-100 dark:border-neutral-800 mt-6 space-y-2">
            <div className="flex gap-2">
              <button
                onClick={handleAddToCart}
                disabled={product.stock === 0}
                className="flex-1 bg-neutral-950 text-white dark:bg-white dark:text-neutral-950 py-3.5 px-6 rounded-xl text-xs font-bold tracking-widest hover:bg-red-600 hover:text-white dark:hover:bg-red-500 dark:hover:text-white transition-all duration-300 flex items-center justify-center gap-2"
              >
                <ShoppingBag className="w-4 h-4" />
                ADD TO ATELIER BAG
              </button>
              <button
                onClick={() => onAddToWishlist(product)}
                className={`p-3.5 rounded-xl border transition-all ${
                  isInWishlist
                    ? 'border-red-600 bg-red-50 text-red-600 dark:bg-red-950/20'
                    : 'border-neutral-200 dark:border-neutral-800 hover:border-red-500'
                }`}
                title="Add to Wishlist"
              >
                <Heart className={`w-4 h-4 ${isInWishlist ? 'fill-red-600' : ''}`} />
              </button>
            </div>

            <button
              onClick={handleBuyNow}
              disabled={product.stock === 0}
              className="w-full bg-red-600 hover:bg-red-700 text-white py-3.5 px-6 rounded-xl text-xs font-bold tracking-widest transition-all duration-300 uppercase"
            >
              Express Checkout
            </button>

            <button
              onClick={() => {
                onClose();
                onNavigate('product-details', { productId: product.id });
              }}
              className="w-full text-center text-xs font-black hover:underline py-1 flex items-center justify-center gap-1 text-neutral-400 hover:text-neutral-950 dark:hover:text-white transition-colors"
            >
              <Eye className="w-3.5 h-3.5" />
              View Comprehensive Details Page
            </button>
          </div>

        </div>

      </div>
    </div>
  );
}
