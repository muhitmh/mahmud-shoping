import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, ArrowUp, ShieldCheck } from 'lucide-react';

interface FooterProps {
  onNavigate: (view: string, params?: any) => void;
  onToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
}

export default function Footer({ onNavigate, onToast }: FooterProps) {
  const [email, setEmail] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !email.includes('@')) {
      onToast('Please enter a valid luxury email address.', 'error');
      return;
    }
    onToast('Welcome to the inner circle! Exclusive invitations and AW26 drops will arrive shortly.', 'success');
    setEmail('');
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer id="footer" className="bg-neutral-950 text-neutral-300 pt-16 pb-8 border-t border-neutral-900 font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top section: Brand, Navigation, Newsletter */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 pb-12 border-b border-neutral-900">
          
          {/* Brand Info */}
          <div className="space-y-4">
            <div onClick={() => onNavigate('home')} className="cursor-pointer">
              <span className="font-extrabold text-2xl tracking-[0.2em] text-white">
                MAHMUD
              </span>
              <p className="text-[8px] font-bold tracking-[0.5em] text-[#E60023] -mt-1">
                SHOPPING
              </p>
            </div>
            <p className="text-xs text-neutral-400 leading-relaxed max-w-sm">
              Mahmud Shopping stands at the pinnacle of luxury, curation, and exquisite modern couture. Tailoring fine garments, tailored suits, and minimalist statement streetwear for the avant-garde.
            </p>
            <div className="space-y-2.5 pt-2 text-xs">
              <div className="flex items-center gap-3">
                <MapPin className="w-4 h-4 text-[#E60023] shrink-0" />
                <span>12 Royal Avenue, Gulshan, Dhaka, Bangladesh</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-[#E60023] shrink-0" />
                <span>+880 1712-345678</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-[#E60023] shrink-0" />
                <span>concierge@mahmudshopping.com</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xs font-bold tracking-[0.2em] text-white uppercase mb-5 border-l-2 border-[#E60023] pl-3">
              Curated Collections
            </h3>
            <ul className="space-y-2.5 text-xs">
              {['Outerwear', 'Dresses', 'Suits', 'Footwear', 'Accessories'].map((cat) => (
                <li key={cat}>
                  <button
                    onClick={() => onNavigate('shop', { category: cat })}
                    className="hover:text-[#E60023] hover:translate-x-1 transition-all duration-200"
                  >
                    {cat}
                  </button>
                </li>
              ))}
              <li>
                <button
                  onClick={() => onNavigate('shop', { filter: 'flash-sale' })}
                  className="text-[#E60023] font-bold hover:underline"
                >
                  Flash Sale Event
                </button>
              </li>
            </ul>
          </div>

          {/* Support / Legals */}
          <div>
            <h3 className="text-xs font-bold tracking-[0.2em] text-white uppercase mb-5 border-l-2 border-[#E60023] pl-3">
              Customer Concierge
            </h3>
            <ul className="space-y-2.5 text-xs">
              <li><button onClick={() => onNavigate('about')} className="hover:text-[#E60023] transition-colors">About Our Atelier</button></li>
              <li><button onClick={() => onNavigate('contact')} className="hover:text-[#E60023] transition-colors">Contact Our Stylist</button></li>
              <li><button onClick={() => onNavigate('faq')} className="hover:text-[#E60023] transition-colors">Frequently Asked Questions</button></li>
              <li><button onClick={() => onNavigate('privacy')} className="hover:text-[#E60023] transition-colors">Privacy Charter</button></li>
              <li><button onClick={() => onNavigate('terms')} className="hover:text-[#E60023] transition-colors">Terms of Service</button></li>
              <li><button onClick={() => onNavigate('tracking')} className="hover:text-[#E60023] transition-colors text-[#E60023] font-bold">Track Shipment</button></li>
            </ul>
          </div>

          {/* Newsletter */}
          <div className="space-y-4">
            <h3 className="text-xs font-bold tracking-[0.2em] text-white uppercase mb-5 border-l-2 border-[#E60023] pl-3">
              The Inner Circle
            </h3>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Subscribe to access invite-only sales, limited capsule drops, and early previews of haute couture.
            </p>
            <form onSubmit={handleSubscribe} className="space-y-3">
              <div className="relative">
                <input
                  type="email"
                  placeholder="Enter your email address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full text-xs bg-neutral-900 border border-neutral-800 rounded-lg py-3 px-4 outline-none focus:border-[#E60023] text-white placeholder-neutral-500"
                />
                <button
                  type="submit"
                  className="absolute right-2 top-2 p-1.5 bg-[#E60023] hover:bg-red-700 text-white rounded-md transition-colors"
                  title="Subscribe"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </form>
            <div className="flex items-center gap-2 text-[10px] text-neutral-500">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              <span>GDPR compliant. Opt out anytime.</span>
            </div>
          </div>

        </div>

        {/* Middle section: Brand Showcase / Trust Badges */}
        <div className="py-8 flex flex-wrap justify-between items-center gap-6 border-b border-neutral-900">
          <div className="flex flex-wrap items-center gap-x-8 gap-y-3 text-xs text-neutral-400 font-mono tracking-widest">
            <span className="font-bold text-white hover:text-[#E60023] transition-colors cursor-pointer">PARIS</span>
            <span className="font-bold text-white hover:text-[#E60023] transition-colors cursor-pointer">MILAN</span>
            <span className="font-bold text-white hover:text-[#E60023] transition-colors cursor-pointer">NEW YORK</span>
            <span className="font-bold text-white hover:text-[#E60023] transition-colors cursor-pointer">DHAKA</span>
          </div>

          {/* Luxury Payment Badges */}
          <div className="flex flex-wrap items-center gap-4">
            <span className="text-[10px] font-bold tracking-widest text-neutral-500 font-mono uppercase">ACCEPTED ATELIER GATEWAYS</span>
            <div className="flex items-center gap-2">
              <div className="bg-neutral-900 border border-neutral-800 px-2 py-1 rounded text-[10px] font-bold font-mono text-pink-500 tracking-wider">bKash Merchant</div>
              <div className="bg-neutral-900 border border-neutral-800 px-2 py-1 rounded text-[10px] font-bold font-mono text-neutral-400">COD Secure</div>
              <div className="bg-neutral-900 border border-neutral-800 px-2 py-1 rounded text-[10px] font-bold font-mono text-[#E60023]">VISA Platinum</div>
              <div className="bg-neutral-900 border border-neutral-800 px-2 py-1 rounded text-[10px] font-bold font-mono text-amber-500">Mastercard World</div>
            </div>
          </div>
        </div>

        {/* Bottom Section: Copyright & Back to Top */}
        <div className="pt-8 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-[10px] font-mono tracking-wider text-neutral-500 text-center sm:text-left">
            © 2026 MAHMUD SHOPPING ATELIER. ALL RIGHTS RESERVED. POWERED BY PREMIUM VANILLA-REACT ENGINES.
          </p>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-2 text-[10px] font-bold tracking-widest text-neutral-400 hover:text-white transition-colors uppercase"
          >
            Back to Top
            <ArrowUp className="w-4.5 h-4.5 bg-neutral-900 p-1 rounded hover:bg-[#E60023] transition-colors duration-300" />
          </button>
        </div>

      </div>
    </footer>
  );
}
