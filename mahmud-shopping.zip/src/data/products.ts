import { Product, Coupon, Banner } from '../types';

export const INITIAL_PRODUCTS: Product[] = [
  // ==========================================
  // 1. FASHION (12 Products)
  // ==========================================
  {
    id: 'prod-001',
    name: 'Noir Sovereign Wool Coat',
    tagline: 'The ultimate statement of minimalist luxury.',
    description: 'An elegant longline wool coat tailored with structured shoulders, peak lapels, and a belted waist. Crafted from 100% fine Italian merino wool.',
    detailedDescription: 'Elevate your cold-weather rotation with the Noir Sovereign Coat. Cut for a sharp, tailored fit that accommodates layering, this piece combines structural strength with exquisite softness. Features classic double-breasted closure, fully lined inside with luxurious silk satin, and custom engraved buffalo-horn buttons.',
    price: 890,
    originalPrice: 1250,
    images: [
      'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=800&q=80'
    ],
    rating: 4.9,
    reviewsCount: 42,
    category: 'Fashion',
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: [
      { name: 'Onyx Black', hex: '#111111' },
      { name: 'Sovereign Red', hex: '#E60023' }
    ],
    specifications: [
      { label: 'Material', value: '100% Merino Wool, 100% Silk Lining' },
      { label: 'Fit', value: 'Slim-tailored fit' },
      { label: 'Care', value: 'Dry clean only' },
      { label: 'Origin', value: 'Made in Italy' }
    ],
    isFlashSale: true,
    flashSalePrice: 890,
    isBestSeller: true,
    isTrending: true,
    isNewArrival: false,
    stock: 12,
    reviews: [
      { id: 'rev-001', userName: 'Alexander V.', rating: 5, comment: 'Absolutely sublime drape. Worth every penny.', date: '2026-05-12' },
      { id: 'rev-002', userName: 'Serena K.', rating: 5, comment: 'Elegant, warm, and the red version is spectacular.', date: '2026-06-01' }
    ]
  },
  {
    id: 'prod-002',
    name: 'Crimson Horizon Silk Gown',
    tagline: 'Graceful fluidity meets captivating shade.',
    description: 'A mesmerizing high-slit pure mulberry silk gown featuring a draped cowl neck and an open-back cross strap design.',
    detailedDescription: 'Turn heads at any gala with the Crimson Horizon Gown. Crafted from heavy-weight sand-washed silk that catches the light beautifully. The fluid cowl neckline and low-back detail create an alluring yet highly sophisticated silhouette, while the double-lined interior ensures maximum comfort.',
    price: 1200,
    images: [
      'https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=800&q=80'
    ],
    rating: 4.8,
    reviewsCount: 19,
    category: 'Fashion',
    sizes: ['XXS', 'XS', 'S', 'M', 'L'],
    colors: [
      { name: 'Crimson Red', hex: '#E60023' },
      { name: 'Midnight Onyx', hex: '#0B0B0C' }
    ],
    specifications: [
      { label: 'Material', value: '100% Mulberry Silk' },
      { label: 'Length', value: 'Floor length with 30cm train' },
      { label: 'Features', value: 'Adjustable cross-back straps' },
      { label: 'Origin', value: 'Handcrafted in France' }
    ],
    isFlashSale: false,
    isBestSeller: false,
    isTrending: true,
    isNewArrival: true,
    stock: 6,
    reviews: [
      { id: 'rev-003', userName: 'Emilia R.', rating: 5, comment: 'This dress fits like a dream! The silk feels incredibly luxurious.', date: '2026-04-20' }
    ]
  },
  {
    id: 'prod-003',
    name: 'Alabaster Sculpted Suit',
    tagline: 'Modern tailoring for the visionary mind.',
    description: 'A sharp, modern double-breasted blazer paired with fluid high-waisted wide-leg trousers in pristine ivory crepe.',
    detailedDescription: 'Redefining formalwear, the Alabaster Suit merges structured masculine geometry with flowing, elegant movement. Made of technical crepe fabric that resists creasing, complete with internal pocket details, fully padded shoulders, and custom gold-bordered horn buttons.',
    price: 950,
    originalPrice: 1100,
    images: [
      'https://images.unsplash.com/photo-1548142813-c348350df52b?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1488426862026-3ee34a7d66df?auto=format&fit=crop&w=800&q=80'
    ],
    rating: 4.7,
    reviewsCount: 28,
    category: 'Fashion',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { name: 'Ivory White', hex: '#FDFBF7' },
      { name: 'Obsidian Black', hex: '#171717' }
    ],
    specifications: [
      { label: 'Material', value: '80% Viscose Crepe, 18% Wool, 2% Elastane' },
      { label: 'Jacket Style', value: 'Double-breasted peak lapel' },
      { label: 'Pant Style', value: 'High-waisted wide-leg pleated trouser' },
      { label: 'Origin', value: 'Made in Portugal' }
    ],
    isFlashSale: false,
    isBestSeller: true,
    isTrending: true,
    isNewArrival: false,
    stock: 15,
    reviews: [
      { id: 'rev-004', userName: 'Charlotte M.', rating: 4, comment: 'Absolutely beautiful. Had to hem the trousers slightly, but the suit is impeccable.', date: '2026-05-30' }
    ]
  },
  {
    id: 'prod-004',
    name: 'Onyx Stealth Leather Jacket',
    tagline: 'Rebellious attitude, refined construction.',
    description: 'A premium full-grain lambskin biker jacket with silver-tone hardware, asymmetrical zip closure, and multiple utility pockets.',
    detailedDescription: 'The perfect leather jacket is hard to find, but we designed it. Built from selected supple lambskin leather that develops a magnificent patina over time. It is cut slim, tailored to conform to your physique, and completed with Japanese YKK Excella zippers.',
    price: 750,
    originalPrice: 950,
    images: [
      'https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=800&q=80'
    ],
    rating: 4.9,
    reviewsCount: 84,
    category: 'Fashion',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: [
      { name: 'Onyx Black', hex: '#1C1917' },
      { name: 'Cherry Oxblood', hex: '#4C0519' }
    ],
    specifications: [
      { label: 'Material', value: '100% Genuine Full-Grain Lambskin' },
      { label: 'Lining', value: 'Polyester quilted thermal lining' },
      { label: 'Hardware', value: 'Heavyweight brushed metal' },
      { label: 'Origin', value: 'Made in Turkey' }
    ],
    isFlashSale: true,
    flashSalePrice: 650,
    isBestSeller: false,
    isTrending: false,
    isNewArrival: true,
    stock: 8,
    reviews: [
      { id: 'rev-005', userName: 'Marcus G.', rating: 5, comment: 'Unparalleled leather quality. Smells incredible and fits perfectly.', date: '2026-06-11' }
    ]
  },
  {
    id: 'prod-007',
    name: 'Elysian Crimson Velvet Blazer',
    tagline: 'Decadence woven into modern tailoring.',
    description: 'A luxurious single-breasted velvet blazer featuring silk lapels, structured shoulders, and a tailored slim silhouette.',
    detailedDescription: 'The Elysian Blazer is created using premium Italian cotton velvet that boasts an exceptionally rich luster and soft pile. Detailed with sharp satin contrast peak lapels, double-vented back, and beautiful velvet-wrapped buttons.',
    price: 680,
    images: [
      'https://images.unsplash.com/photo-1505022610485-0249ba5b3675?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1593032465175-481da7e4725f?auto=format&fit=crop&w=800&q=80'
    ],
    rating: 4.9,
    reviewsCount: 12,
    category: 'Fashion',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { name: 'Crimson Velvet', hex: '#881337' },
      { name: 'Pitch Black', hex: '#020617' }
    ],
    specifications: [
      { label: 'Material', value: '100% Cotton Velvet, Silk Trim' },
      { label: 'Fit', value: 'Slim architectural' },
      { label: 'Details', value: 'Three exterior pockets, two interior pockets' },
      { label: 'Origin', value: 'Made in Spain' }
    ],
    isFlashSale: false,
    isBestSeller: false,
    isTrending: true,
    isNewArrival: true,
    stock: 4,
    reviews: [
      { id: 'rev-008', userName: 'Julian P.', rating: 5, comment: 'Outstanding feel. Tailoring fits perfectly out of the box.', date: '2026-04-12' }
    ]
  },
  {
    id: 'prod-009',
    name: 'Sartorial Double-Breasted Trench',
    tagline: 'Rain-resistant heritage with structural poise.',
    description: 'Classic British-style double-breasted trench coat with storm flaps, epaulettes, and a signature belt with tortoiseshell D-rings.',
    detailedDescription: 'A timeless transitional outerwear masterpiece. Hand-cut from premium cotton gabardine weave, treated with water-resistant nanoparticles. Features a historical plaid print inner lining, adjustable cuffs, and hand-bound buttonholes.',
    price: 590,
    originalPrice: 720,
    images: ['https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&w=800&q=80'],
    rating: 4.8,
    reviewsCount: 22,
    category: 'Fashion',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { name: 'Honey Beige', hex: '#D7C49E' },
      { name: 'Onyx Black', hex: '#111111' }
    ],
    specifications: [
      { label: 'Shell', value: '100% Rainproof Egyptian Cotton Gabardine' },
      { label: 'Closure', value: 'Tortoiseshell double-breast buttons' },
      { label: 'Features', value: 'Adjustable throat latch & storm flaps' }
    ],
    isFlashSale: false,
    isBestSeller: false,
    isTrending: false,
    isNewArrival: true,
    stock: 14,
    reviews: []
  },
  {
    id: 'prod-010',
    name: 'Cashmere Ribbed Knit Cardigan',
    tagline: 'Enveloping warmth in featherlight weights.',
    description: 'An elegant long-line relaxed knit cardigan made from 100% pure Himalayan high-grade cashmere.',
    detailedDescription: 'Spun from select Grade-A cashmere fibers gathered from ethical high-altitude herders. Highly breathable, cloud-like softness, featuring micro-ribbed cuffs and a relaxed waterfall drape front.',
    price: 450,
    images: ['https://images.unsplash.com/photo-1516762689617-e1cffcef479d?auto=format&fit=crop&w=800&q=80'],
    rating: 4.7,
    reviewsCount: 15,
    category: 'Fashion',
    sizes: ['XS', 'S', 'M', 'L'],
    colors: [
      { name: 'Oatmeal Heather', hex: '#EAE6DF' },
      { name: 'Slate Grey', hex: '#707A8A' }
    ],
    specifications: [
      { label: 'Composition', value: '100% Himalayan Mongolian Cashmere' },
      { label: 'Weave', value: '12-Gauge fine rib knit' }
    ],
    isFlashSale: false,
    isBestSeller: true,
    isTrending: false,
    isNewArrival: false,
    stock: 20,
    reviews: []
  },
  {
    id: 'prod-011',
    name: 'Architectural Pleated Midi Skirt',
    tagline: 'Kinetic geometry in flawless drape.',
    description: 'High-waisted midi skirt with sharp permanent heat-pressed knife pleats and an asymmetric visual hemline.',
    detailedDescription: 'Moving fluidly with every stride, this structural skirt utilizes technical satin fiber to retain razor-sharp pleats even after extensive dry cleaning. Closes via hidden side-seam zipper.',
    price: 340,
    originalPrice: 420,
    images: ['https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?auto=format&fit=crop&w=800&q=80'],
    rating: 4.6,
    reviewsCount: 11,
    category: 'Fashion',
    sizes: ['XXS', 'XS', 'S', 'M', 'L'],
    colors: [
      { name: 'Emerald Velvet', hex: '#064E3B' },
      { name: 'Champagne Gold', hex: '#F3E8FF' }
    ],
    specifications: [
      { label: 'Fabric', value: 'Luxurious Asymmetric Poly-Satin Crepe' },
      { label: 'Length', value: 'Midi (78cm center back length)' }
    ],
    isFlashSale: true,
    flashSalePrice: 290,
    isBestSeller: false,
    isTrending: true,
    isNewArrival: false,
    stock: 10,
    reviews: []
  },
  {
    id: 'prod-012',
    name: 'Sovereign White Poplin Shirt',
    tagline: 'The timeless foundation of formal dressing.',
    description: 'Crisp white shirt tailored from two-ply 120s Egyptian cotton poplin with a structured spread collar.',
    detailedDescription: 'Nothing beats a flawless white shirt. Built with standard French cuffs, mother-of-pearl buttons, and a slight back waist dart for a pristine outline that holds form throughout high-powered days.',
    price: 220,
    images: ['https://images.unsplash.com/photo-1620012253295-c05518e993bd?auto=format&fit=crop&w=800&q=80'],
    rating: 4.9,
    reviewsCount: 65,
    category: 'Fashion',
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: [{ name: 'Optic White', hex: '#FFFFFF' }],
    specifications: [
      { label: 'Yarn', value: '2-Ply 120s Egyptian Cotton Poplin' },
      { label: 'Collar', value: 'Removable collar stays, spread cut' }
    ],
    isFlashSale: false,
    isBestSeller: true,
    isTrending: false,
    isNewArrival: false,
    stock: 45,
    reviews: []
  },
  {
    id: 'prod-013',
    name: 'Emperor Gold Embroidered Sherwani',
    tagline: 'Imperial artistry for auspicious occasions.',
    description: 'An premium hand-tailored ivory raw silk Sherwani adorned with intricate real zari gold metallic embroidery.',
    detailedDescription: 'A masterclass in celebratory couture. Features a structured bandhgala collar, padded shoulders, fully silk-lined inner side, and custom filigree gold buttons.',
    price: 1450,
    images: ['https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=800&q=80'],
    rating: 5.0,
    reviewsCount: 8,
    category: 'Fashion',
    sizes: ['M', 'L', 'XL'],
    colors: [{ name: 'Ivory Gold', hex: '#FCF8EE' }],
    specifications: [
      { label: 'Body', value: '100% Hand-loomed Raw Mulberry Silk' },
      { label: 'Artistry', value: 'Handmade zardozi using gold alloy yarns' }
    ],
    isFlashSale: false,
    isBestSeller: false,
    isTrending: true,
    isNewArrival: true,
    stock: 3,
    reviews: []
  },
  {
    id: 'prod-014',
    name: 'Saffron Silk Cowl Blouse',
    tagline: 'Effortless silk fluidity with visual flare.',
    description: 'An elegant long-sleeved silk crepe blouse with a drape cowl neck and keyhole button cuffs.',
    detailedDescription: 'Designed with luxury in mind, this pure silk blouse drapes magnificently. Perfect under double-breasted velvet blazers or tucked into wide-leg trousers.',
    price: 310,
    originalPrice: 380,
    images: ['https://images.unsplash.com/photo-1548142813-c348350df52b?auto=format&fit=crop&w=800&q=80'],
    rating: 4.8,
    reviewsCount: 14,
    category: 'Fashion',
    sizes: ['S', 'M', 'L'],
    colors: [
      { name: 'Saffron Yellow', hex: '#F59E0B' },
      { name: 'Crimson Red', hex: '#E60023' }
    ],
    specifications: [
      { label: 'Material', value: '100% Sandwashed Silk Crepe' },
      { label: 'Care', value: 'Handwash cold or dry clean' }
    ],
    isFlashSale: true,
    flashSalePrice: 250,
    isBestSeller: false,
    isTrending: false,
    isNewArrival: false,
    stock: 12,
    reviews: []
  },
  {
    id: 'prod-015',
    name: 'Merino Knit Mockneck Jumper',
    tagline: 'Essential structured insulation.',
    description: 'Superfine merino wool knit sweater featuring a sleek mockneck collar and micro-ribbed cuffs.',
    detailedDescription: 'Constructed using tight-gauge premium merino wool. Fits close to body as an ideal lightweight mid-layer. Retains shape beautifully and is highly active-thermoregulating.',
    price: 185,
    images: ['https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=800&q=80'],
    rating: 4.7,
    reviewsCount: 30,
    category: 'Fashion',
    sizes: ['S', 'M', 'L', 'XL'],
    colors: [
      { name: 'Charcoal Black', hex: '#262626' },
      { name: 'Taupe Beige', hex: '#D4C5B9' }
    ],
    specifications: [
      { label: 'Yarn', value: '100% Extrafine Australian Merino Wool' },
      { label: 'Gauge', value: '18-Gauge seamless luxury knit' }
    ],
    isFlashSale: false,
    isBestSeller: true,
    isTrending: false,
    isNewArrival: false,
    stock: 25,
    reviews: []
  },

  // ==========================================
  // 2. SHOES (8 Products)
  // ==========================================
  {
    id: 'prod-005',
    name: 'Scarlet Avant-Garde Heels',
    tagline: 'Confidence carved in lacquer red.',
    description: 'Statement high heels featuring an architectural sculptural heel, patent gloss finish, and an elegant pointed toe.',
    detailedDescription: 'Make your presence felt. Crafted from high-gloss lacquered leather with an ergonomic footbed that balances supreme structural posture with remarkable walkability. Features the iconic crimson signature sole, signifying pure craftsmanship.',
    price: 490,
    images: [
      'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1535043934128-cf0b28d52f95?auto=format&fit=crop&w=800&q=80'
    ],
    rating: 4.6,
    reviewsCount: 15,
    category: 'Shoes',
    sizes: ['36', '37', '38', '39', '40', '41'],
    colors: [
      { name: 'Scarlet Red', hex: '#E60023' },
      { name: 'Pitch Black', hex: '#111111' }
    ],
    specifications: [
      { label: 'Heel Height', value: '105mm / 4.1 inches' },
      { label: 'Upper', value: 'Premium Patent Leather' },
      { label: 'Insole', value: 'Cushioned calfskin memory leather' },
      { label: 'Origin', value: 'Handcrafted in Italy' }
    ],
    isFlashSale: false,
    isBestSeller: false,
    isTrending: true,
    isNewArrival: false,
    stock: 5,
    reviews: [
      { id: 'rev-006', userName: 'Diana B.', rating: 5, comment: 'Exquisite construction. They elevate any outfit instantly.', date: '2026-05-18' }
    ]
  },
  {
    id: 'prod-006',
    name: 'Monochrome Minimalist Sneaker',
    tagline: 'Casual elegance for high-frequency living.',
    description: 'Premium white calf leather court sneakers featuring a matte black heel tab, tonal topstitching, and an eco-rubber sole.',
    detailedDescription: 'An everyday luxury staple. Made from hand-selected full-grain Italian calf leather that is incredibly soft, meaning zero break-in period. Mounted on durable margins with heavy wax-coated cotton laces and customized foot orthotics support.',
    price: 320,
    originalPrice: 380,
    images: [
      'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1608231387042-66d1773070a5?auto=format&fit=crop&w=800&q=80'
    ],
    rating: 4.8,
    reviewsCount: 56,
    category: 'Shoes',
    sizes: ['40', '41', '42', '43', '44', '45'],
    colors: [
      { name: 'Alabaster White', hex: '#FFFFFF' },
      { name: 'Void Black', hex: '#1E293B' }
    ],
    specifications: [
      { label: 'Material', value: 'Italian Full-Grain Calfskin' },
      { label: 'Sole', value: 'Margom rubber stitched cupsole' },
      { label: 'Insole', value: 'Removable cork-backed leather' },
      { label: 'Origin', value: 'Made in Italy' }
    ],
    isFlashSale: false,
    isBestSeller: true,
    isTrending: false,
    isNewArrival: true,
    stock: 22,
    reviews: [
      { id: 'rev-007', userName: 'Daniel L.', rating: 5, comment: 'Most comfortable leather sneaker I own. Clean styling.', date: '2026-06-05' }
    ]
  },
  {
    id: 'prod-016',
    name: 'Atelier Suede Chelsea Boots',
    tagline: 'Timeless silhouette, luxurious texture.',
    description: 'Italian calf suede boots with flexible elasticated side panels and a hand-stacked Cuban leather heel.',
    detailedDescription: 'Crafted with premium weather-resistant suede to withstand light autumn showers. Hand-stitched welt ensures robust longevity and allows resolving decades down the line.',
    price: 430,
    originalPrice: 520,
    images: ['https://images.unsplash.com/photo-1520639888713-7851133b1ed0?auto=format&fit=crop&w=800&q=80'],
    rating: 4.7,
    reviewsCount: 38,
    category: 'Shoes',
    sizes: ['41', '42', '43', '44', '45'],
    colors: [
      { name: 'Cognac Suede', hex: '#7C2D12' },
      { name: 'Onyx Suede', hex: '#1A1A1A' }
    ],
    specifications: [
      { label: 'Upper', value: 'Water-repellent Premium Italian Suede' },
      { label: 'Construction', value: 'Blake stitched sole' }
    ],
    isFlashSale: true,
    flashSalePrice: 380,
    isBestSeller: false,
    isTrending: true,
    isNewArrival: false,
    stock: 12,
    reviews: []
  },
  {
    id: 'prod-017',
    name: 'Sovereign Patent Loafers',
    tagline: 'Flawless glossy polish for black-tie affairs.',
    description: 'Black patent calfskin evening loafers detailed with hand-wrapped grosgrain textile bands across the instep.',
    detailedDescription: 'Refined evening luxury. Glossy lacquered leather reflects light, contrasted beautifully with high-density premium velvet collar lines. Padded quilted interior.',
    price: 380,
    images: ['https://images.unsplash.com/photo-1533867617858-e7b97e060509?auto=format&fit=crop&w=800&q=80'],
    rating: 4.9,
    reviewsCount: 17,
    category: 'Shoes',
    sizes: ['40', '41', '42', '43', '44'],
    colors: [{ name: 'Gloss Onyx', hex: '#000000' }],
    specifications: [
      { label: 'Upper', value: 'Lacquered Patent Calf Leather' },
      { label: 'Insole', value: 'Silk quilted memory orthotic' }
    ],
    isFlashSale: false,
    isBestSeller: true,
    isTrending: false,
    isNewArrival: false,
    stock: 7,
    reviews: []
  },
  {
    id: 'prod-018',
    name: 'Venetian Strappy Leather Sandals',
    tagline: 'Minimalist straps, maximal structural style.',
    description: 'Pristine flat leather sandals with a crossed toe loop and secure buckled metallic ankle buckle straps.',
    detailedDescription: 'Handmade by traditional artisans in Greece. Constructed from certified vegetable-tanned natural vachetta leather which develops an outstanding golden caramel tan over summer wear.',
    price: 195,
    images: ['https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=800&q=80'],
    rating: 4.5,
    reviewsCount: 9,
    category: 'Shoes',
    sizes: ['36', '37', '38', '39', '40'],
    colors: [
      { name: 'Tan Vachetta', hex: '#B45309' },
      { name: 'Alabaster White', hex: '#FFFFFF' }
    ],
    specifications: [
      { label: 'Sole', value: 'Dense flexible natural rubber compound' },
      { label: 'Straps', value: '100% Genuine Tuscan leather' }
    ],
    isFlashSale: false,
    isBestSeller: false,
    isTrending: false,
    isNewArrival: true,
    stock: 18,
    reviews: []
  },
  {
    id: 'prod-019',
    name: 'Sartorial Wingtip Brogues',
    tagline: 'Heritage punching, contemporary stride.',
    description: 'Traditional full-grain calfskin oxford brogues with bespoke decorative wingtip punching and a double-stitched leather sole.',
    detailedDescription: 'Crafted using hand-stained calf leather with beautiful burnished toe details. Built on a Goodyear welted frame, ensuring complete water seal and decades of durable wear.',
    price: 450,
    originalPrice: 550,
    images: ['https://images.unsplash.com/photo-1533867617858-e7b97e060509?auto=format&fit=crop&w=800&q=80'],
    rating: 4.8,
    reviewsCount: 29,
    category: 'Shoes',
    sizes: ['41', '42', '43', '44', '45'],
    colors: [
      { name: 'Burnished Tan', hex: '#78350F' },
      { name: 'Dark Espresso', hex: '#3B0764' }
    ],
    specifications: [
      { label: 'Yarn Welt', value: 'Goodyear Welted with cork paste fill' },
      { label: 'Lining', value: 'Full glove-leather breathable lining' }
    ],
    isFlashSale: true,
    flashSalePrice: 390,
    isBestSeller: false,
    isTrending: false,
    isNewArrival: false,
    stock: 11,
    reviews: []
  },
  {
    id: 'prod-020',
    name: 'Urban High-Top Athletic Trainer',
    tagline: 'Streetwise posture with energetic bounce.',
    description: 'High-top knit-upper sneakers utilizing lightweight carbon fiber arch supports and high-rebound responsive soles.',
    detailedDescription: 'Engineered for street fashion lovers. Features premium nubuck leather panelling over a breathable, seamless performance knit mesh. Padded collar protects your ankles.',
    price: 280,
    images: ['https://images.unsplash.com/photo-1608231387042-66d1773070a5?auto=format&fit=crop&w=800&q=80'],
    rating: 4.7,
    reviewsCount: 44,
    category: 'Shoes',
    sizes: ['40', '41', '42', '43', '44', '45'],
    colors: [
      { name: 'Stealth Black', hex: '#111111' },
      { name: 'Sovereign Red', hex: '#E60023' }
    ],
    specifications: [
      { label: 'Upper', value: '3D woven knit mesh with nubuck leather panels' },
      { label: 'Arch support', value: 'Integrated aerospace carbon plate' }
    ],
    isFlashSale: false,
    isBestSeller: true,
    isTrending: true,
    isNewArrival: false,
    stock: 30,
    reviews: []
  },
  {
    id: 'prod-021',
    name: 'Sovereign Crocodile-Embossed Boots',
    tagline: 'Exotic texture meets premium armor posture.',
    description: 'Premium calfskin boots embossed with a crocodile scale pattern, detailed with a side silver zipper and double monk straps.',
    detailedDescription: 'A highly luxurious fashion-forward statement shoe. Features deep burnished red tones or onyx finishes. Beautiful Cuban stacked heel and leather sole.',
    price: 620,
    images: ['https://images.unsplash.com/photo-1520639888713-7851133b1ed0?auto=format&fit=crop&w=800&q=80'],
    rating: 4.9,
    reviewsCount: 14,
    category: 'Shoes',
    sizes: ['41', '42', '43', '44'],
    colors: [
      { name: 'Crimson Croc', hex: '#991B1B' },
      { name: 'Onyx Croc', hex: '#111111' }
    ],
    specifications: [
      { label: 'Embroidery', value: 'Deep-pressed crocodile pattern calfskin' },
      { label: 'Origin', value: 'Made in Italy' }
    ],
    isFlashSale: false,
    isBestSeller: false,
    isTrending: false,
    isNewArrival: true,
    stock: 5,
    reviews: []
  },

  // ==========================================
  // 3. WATCHES (6 Products)
  // ==========================================
  {
    id: 'prod-022',
    name: 'Atelier Royal Chronograph',
    tagline: 'Mastering time with mechanical majesty.',
    description: 'An elite automatic luxury watch featuring a skeleton back, stainless steel chassis, and deep navy sunray dial.',
    detailedDescription: 'An heirloom-quality mechanical watch. Operates on a premium Japanese automatic movement caliber with a 48-hour reserve. Protected by anti-reflective domed sapphire crystal glass. Water-resistant up to 100 meters.',
    price: 1350,
    originalPrice: 1600,
    images: ['https://images.unsplash.com/photo-1524592094714-0f0654e20314?auto=format&fit=crop&w=800&q=80'],
    rating: 4.9,
    reviewsCount: 31,
    category: 'Watches',
    sizes: ['40mm'],
    colors: [
      { name: 'Silver Steel', hex: '#9CA3AF' },
      { name: '24K Gold Plated', hex: '#FBBF24' }
    ],
    specifications: [
      { label: 'Caliber', value: 'Miyota 9015 Automatic, 24 jewels' },
      { label: 'Glass', value: 'Genuine Domed Sapphire Crystal' },
      { label: 'Strap', value: 'Premium French alligator leather' }
    ],
    isFlashSale: true,
    flashSalePrice: 1250,
    isBestSeller: true,
    isTrending: true,
    isNewArrival: false,
    stock: 4,
    reviews: []
  },
  {
    id: 'prod-023',
    name: 'Sovereign Gold Minimalist Watch',
    tagline: 'Sleek luxury stripped of distraction.',
    description: 'An ultra-slim 24k yellow gold plated watch with an elegant milanese mesh strap and clean black dial.',
    detailedDescription: 'Sleek, elegant, understated. Features a quartz movement made in Switzerland, clean hour ticks, and an integrated quick-release clasp. Just 6mm thick.',
    price: 490,
    images: ['https://images.unsplash.com/photo-1542496658-e33a6d0d50f6?auto=format&fit=crop&w=800&q=80'],
    rating: 4.8,
    reviewsCount: 18,
    category: 'Watches',
    sizes: ['38mm', '42mm'],
    colors: [
      { name: 'Yellow Gold', hex: '#F59E0B' },
      { name: 'Rose Gold', hex: '#FDA4AF' }
    ],
    specifications: [
      { label: 'Movement', value: 'Swiss Quartz Movement' },
      { label: 'Case Thickness', value: '6.0 mm ultra-slim profile' }
    ],
    isFlashSale: false,
    isBestSeller: true,
    isTrending: false,
    isNewArrival: true,
    stock: 15,
    reviews: []
  },
  {
    id: 'prod-024',
    name: 'Pro-Stealth Carbon Sports Watch',
    tagline: 'Lightweight strength, supreme precision.',
    description: 'An aggressive sports watch constructed using recycled carbon fiber casing and a heavy-duty vulcanized rubber strap.',
    detailedDescription: 'Built to survive extreme adventures. Ultra-light, highly impact-resistant. Features digital-analog dual layouts, backlighting, compass, temperature sensors, and 200m water seal.',
    price: 350,
    originalPrice: 450,
    images: ['https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3?auto=format&fit=crop&w=800&q=80'],
    rating: 4.7,
    reviewsCount: 51,
    category: 'Watches',
    sizes: ['44mm'],
    colors: [
      { name: 'Carbon Black', hex: '#111111' },
      { name: 'Crimson Red', hex: '#E60023' }
    ],
    specifications: [
      { label: 'Case Material', value: 'Carbon Core Guard structure' },
      { label: 'Water Seal', value: '20 Bar / 200 Meters deep' }
    ],
    isFlashSale: true,
    flashSalePrice: 290,
    isBestSeller: false,
    isTrending: true,
    isNewArrival: false,
    stock: 19,
    reviews: []
  },
  {
    id: 'prod-025',
    name: 'Sovereign Titan Smartwatch Wear',
    tagline: 'Next-generation tech in classical premium casing.',
    description: 'An high-end titanium smartwatch housing high-fidelity fitness sensors, 7-day battery, and high-brightness AMOLED panel.',
    detailedDescription: 'Merges fine horology with smart alerts. Automatically monitors heart-rate, blood-oxygen, stress, and GPS tracks runs. Beautiful titanium bezel looks incredible in boardroom meetings.',
    price: 790,
    images: ['https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?auto=format&fit=crop&w=800&q=80'],
    rating: 4.9,
    reviewsCount: 27,
    category: 'Watches',
    sizes: ['46mm'],
    colors: [
      { name: 'Titanium Grey', hex: '#64748B' },
      { name: 'Onyx Black', hex: '#111111' }
    ],
    specifications: [
      { label: 'Chassis', value: 'Grade-5 Aerospace Solid Titanium' },
      { label: 'Display', value: '1.43" Always-on AMOLED Sapphire Glass' }
    ],
    isFlashSale: false,
    isBestSeller: true,
    isTrending: true,
    isNewArrival: false,
    stock: 10,
    reviews: []
  },
  {
    id: 'prod-026',
    name: 'Classic Roman Vintage Gold',
    tagline: 'Mid-century aesthetics for contemporary collectors.',
    description: 'A beautiful rectangular hand-wound vintage gold watch featuring a white face and crisp Roman numeral indexes.',
    detailedDescription: 'Inspired by iconic 1930s dress watches. Features hand-stitched honey leather bands, manual mechanical winding, and a subtle blue steel hands accent.',
    price: 650,
    images: ['https://images.unsplash.com/photo-1524592094714-0f0654e20314?auto=format&fit=crop&w=800&q=80'],
    rating: 4.8,
    reviewsCount: 12,
    category: 'Watches',
    sizes: ['32mm x 40mm'],
    colors: [{ name: 'Vintage Gold', hex: '#EAB308' }],
    specifications: [
      { label: 'Movement', value: 'Hand-wound mechanical caliber' },
      { label: 'Strap', value: 'Tuscan vegetable-tanned honey calf' }
    ],
    isFlashSale: false,
    isBestSeller: false,
    isTrending: false,
    isNewArrival: true,
    stock: 6,
    reviews: []
  },
  {
    id: 'prod-027',
    name: 'Diver Pro Deep Ocean Edition',
    tagline: 'Uncompromising mechanical reliability under pressure.',
    description: 'High-visibility automatic professional diver watch featuring a rotating ceramic bezel, helium valve, and super-luminova markings.',
    detailedDescription: 'Tested in oceanic depths. The heavy steel bracelet features a wet-suit extension link. Features scratch-proof ceramic bezel inserts.',
    price: 850,
    originalPrice: 1100,
    images: ['https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3?auto=format&fit=crop&w=800&q=80'],
    rating: 4.9,
    reviewsCount: 20,
    category: 'Watches',
    sizes: ['43mm'],
    colors: [
      { name: 'Oceanic Blue', hex: '#1E3A8A' },
      { name: 'Stealth Black', hex: '#000000' }
    ],
    specifications: [
      { label: 'Water Seal', value: '300 Meters / 1000 Feet deep' },
      { label: 'Bezel', value: '120-Click Unidirectional ceramic' }
    ],
    isFlashSale: true,
    flashSalePrice: 750,
    isBestSeller: false,
    isTrending: false,
    isNewArrival: false,
    stock: 8,
    reviews: []
  },

  // ==========================================
  // 4. BAGS (7 Products)
  // ==========================================
  {
    id: 'prod-008',
    name: 'Sovereign Quilted Bag',
    tagline: 'The pinnacle of refined storage.',
    description: 'A stunning shoulder clutch bag crafted in luxurious lambskin chevron-quilted leather with a thick gold chain strap.',
    detailedDescription: 'Designed for versatility and statement elegance. Features two expandable compartments, one secure zipper sleeve, a gold turn-lock buckle carrying the Mahmud emblem monogram, and adjustable sliding heavy chain straps to wear as cross-body or short shoulder bags.',
    price: 520,
    originalPrice: 650,
    images: [
      'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80'
    ],
    rating: 4.9,
    reviewsCount: 37,
    category: 'Bags',
    sizes: ['One Size'],
    colors: [
      { name: 'Onyx Black', hex: '#111111' },
      { name: 'Scarlet Gold', hex: '#E60023' },
      { name: 'Alabaster White', hex: '#F9FAFB' }
    ],
    specifications: [
      { label: 'Dimensions', value: '25cm x 15cm x 8cm' },
      { label: 'Material', value: 'Nappa Lambskin Leather' },
      { label: 'Hardware', value: '24K gold-plated solid brass' },
      { label: 'Origin', value: 'Made in Italy' }
    ],
    isFlashSale: true,
    flashSalePrice: 420,
    isBestSeller: true,
    isTrending: false,
    isNewArrival: false,
    stock: 9,
    reviews: [
      { id: 'rev-009', userName: 'Victoria S.', rating: 5, comment: 'The hardware has a satisfying weight. Absolutely beautiful leather.', date: '2026-06-14' }
    ]
  },
  {
    id: 'prod-028',
    name: 'Full-Grain Weekend Leather Duffel',
    tagline: 'The ultimate luxury getaway companion.',
    description: 'A spacious, heavy-duty weekend holdall handmade from thick Tuscan pull-up leather that develops a splendid natural patina.',
    detailedDescription: 'Perfect for first-class overhead storage compartments. Includes a shoe compartment, laptop padding sleeve, reinforced base rails, and solid brass YKK zippers. Detachable padded shoulder strap.',
    price: 490,
    images: ['https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80'],
    rating: 4.9,
    reviewsCount: 46,
    category: 'Bags',
    sizes: ['45L'],
    colors: [
      { name: 'Cognac Brown', hex: '#7C2D12' },
      { name: 'Onyx Black', hex: '#111111' }
    ],
    specifications: [
      { label: 'Material', value: '3.0mm thick full-grain Tuscan Leather' },
      { label: 'Dimensions', value: '55cm x 30cm x 28cm' }
    ],
    isFlashSale: false,
    isBestSeller: true,
    isTrending: true,
    isNewArrival: false,
    stock: 14,
    reviews: []
  },
  {
    id: 'prod-029',
    name: 'Minimalist Leather Laptop Portfolio',
    tagline: 'Streamlined organization for high-profile business.',
    description: 'A sleek, structured brief portfolio tailored to shelter a 16-inch Macbook with separate compartments for files, stylus, and keys.',
    detailedDescription: 'Ditch the bulk. Handcrafted with scratch-resistant saffiano calf leather. Lined inside with thick protective velvet suede. Sleek external magnetic pockets.',
    price: 290,
    originalPrice: 380,
    images: ['https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=800&q=80'],
    rating: 4.8,
    reviewsCount: 19,
    category: 'Bags',
    sizes: ['16-inch'],
    colors: [
      { name: 'Saffiano Charcoal', hex: '#374151' },
      { name: 'Espresso Black', hex: '#111111' }
    ],
    specifications: [
      { label: 'Material', value: 'Saffiano Scratch-Resistant Calf Leather' },
      { label: 'Lining', value: 'Faux velvet microfiber cushioning' }
    ],
    isFlashSale: true,
    flashSalePrice: 240,
    isBestSeller: false,
    isTrending: false,
    isNewArrival: true,
    stock: 22,
    reviews: []
  },
  {
    id: 'prod-030',
    name: 'Empress Silk Handle Tote',
    tagline: 'An elegant statement of daytime luxury.',
    description: 'A structural white canvas tote bag with contrast leather base trim and a beautiful handle wrapped in custom silk scarves.',
    detailedDescription: 'Spacious and highly fashionable. Perfect for holding luxury planners, tablets, cosmetics, and keys. Includes a matching inner zippered leather pouch.',
    price: 360,
    images: ['https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80'],
    rating: 4.7,
    reviewsCount: 23,
    category: 'Bags',
    sizes: ['Medium'],
    colors: [
      { name: 'Ivory Canvas', hex: '#FAF9F6' },
      { name: 'Red Velvet', hex: '#E60023' }
    ],
    specifications: [
      { label: 'Body', value: 'High-density Belgian flax canvas' },
      { label: 'Trims', value: 'Vachetta leather bindings' }
    ],
    isFlashSale: false,
    isBestSeller: true,
    isTrending: false,
    isNewArrival: false,
    stock: 15,
    reviews: []
  },
  {
    id: 'prod-031',
    name: 'Voyage Carbon Hardshell Suitcase',
    tagline: 'Indestructible shield for global explorers.',
    description: 'An premium carry-on hardshell suitcase constructed using pure aerospace carbon-fiber weave with Japanese silent-glide spinner wheels.',
    detailedDescription: 'At just 2.4kg, this carbon fiber case withstands immense pressures. Integrated TSA lock, leather handle trims, and customizable internal mesh packing dividers.',
    price: 680,
    images: ['https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80'],
    rating: 4.9,
    reviewsCount: 15,
    category: 'Bags',
    sizes: ['Cabin Size'],
    colors: [{ name: 'Polished Carbon', hex: '#1C1917' }],
    specifications: [
      { label: 'Shell', value: '100% Aerospace Grade Carbon Fiber' },
      { label: 'Wheels', value: 'Hinomoto Japan double spinner wheels' }
    ],
    isFlashSale: false,
    isBestSeller: false,
    isTrending: true,
    isNewArrival: true,
    stock: 5,
    reviews: []
  },
  {
    id: 'prod-032',
    name: 'Sartorial Leather Sling Pack',
    tagline: 'Sleek crossbody profile for city mobility.',
    description: 'A modern, single-strap sling chest pack crafted in water-resistant technical nylon with full-grain leather pocket panels.',
    detailedDescription: 'The perfect urban utility. Features anti-theft back pockets, padded phone sleeve, and adjustable clip-on strap for left or right shoulder styling.',
    price: 195,
    originalPrice: 250,
    images: ['https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80'],
    rating: 4.6,
    reviewsCount: 33,
    category: 'Bags',
    sizes: ['One Size'],
    colors: [
      { name: 'Void Black', hex: '#111111' },
      { name: 'Olive Drab', hex: '#3F6212' }
    ],
    specifications: [
      { label: 'Material', value: '1680D Ballistic Nylon & Calf Leather' },
      { label: 'Capacity', value: '6 Liters smart storage' }
    ],
    isFlashSale: true,
    flashSalePrice: 155,
    isBestSeller: false,
    isTrending: false,
    isNewArrival: false,
    stock: 25,
    reviews: []
  },
  {
    id: 'prod-033',
    name: 'Elite Leather Backpack',
    tagline: 'Ergonomic structure, executive prestige.',
    description: 'An executive structured backpack tailored with clean lines, padded notebook sleeves, and full pebble leather skin.',
    detailedDescription: 'Designed for the modern professional. Cushioned orthopedic backing keeps you cool and comfortable during travel, with integrated luggage strap sliders.',
    price: 420,
    images: ['https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80'],
    rating: 4.8,
    reviewsCount: 29,
    category: 'Bags',
    sizes: ['22L'],
    colors: [
      { name: 'Midnight Onyx', hex: '#111111' },
      { name: 'Tobacco Pebble', hex: '#78350F' }
    ],
    specifications: [
      { label: 'Material', value: 'Premium Pebble Grain Calf Leather' },
      { label: 'Hardware', value: 'Gunmetal corrosion-proof zippers' }
    ],
    isFlashSale: false,
    isBestSeller: true,
    isTrending: false,
    isNewArrival: false,
    stock: 12,
    reviews: []
  },

  // ==========================================
  // 5. ELECTRONICS (7 Products)
  // ==========================================
  {
    id: 'prod-034',
    name: 'Acoustic Sovereign Headphones',
    tagline: 'Pristine sound, silence customized.',
    description: 'Premium active noise-cancelling wireless headphones finished in aluminum framing and lambskin leather cups.',
    detailedDescription: 'Experience pure sonic isolation. Custom-tuned 40mm beryllium drivers produce breathtaking detail. Adaptive ANC monitors noise 400 times a second, delivering absolute acoustic purity.',
    price: 550,
    originalPrice: 650,
    images: ['https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80'],
    rating: 4.9,
    reviewsCount: 78,
    category: 'Electronics',
    sizes: ['One Size'],
    colors: [
      { name: 'Argent Silver', hex: '#D1D5DB' },
      { name: 'Obsidian Black', hex: '#111111' },
      { name: 'Atelier Gold', hex: '#E60023' }
    ],
    specifications: [
      { label: 'Drivers', value: '40mm Pure Beryllium Diaphragms' },
      { label: 'Battery', value: '38 Hours continuous playback with ANC' },
      { label: 'Codec Support', value: 'LDAC, aptX Adaptive, AAC, SBC' }
    ],
    isFlashSale: true,
    flashSalePrice: 480,
    isBestSeller: true,
    isTrending: true,
    isNewArrival: false,
    stock: 15,
    reviews: []
  },
  {
    id: 'prod-035',
    name: 'Sovereign Audio Studio Earbuds',
    tagline: 'Tiny scales, colossal cinematic depths.',
    description: 'In-ear true wireless earbuds with advanced micro-planar drivers, liquid silicon tips, and an aluminum pocket charge box.',
    detailedDescription: 'Audiophile grade in-ear acoustics. Features a hybrid tri-microphone setup for crystal clear audio calls and adaptive noise canceling. 10 hours battery on a single drop.',
    price: 240,
    images: ['https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=800&q=80'],
    rating: 4.8,
    reviewsCount: 41,
    category: 'Electronics',
    sizes: ['XS/S/M/L Tips'],
    colors: [
      { name: 'Ceramic White', hex: '#FFFFFF' },
      { name: 'Pitch Onyx', hex: '#111111' }
    ],
    specifications: [
      { label: 'Drive caliber', value: '6mm planar magnetic drivers' },
      { label: 'Water Seal', value: 'IPX5 Sweat and rain resistant' }
    ],
    isFlashSale: false,
    isBestSeller: true,
    isTrending: false,
    isNewArrival: true,
    stock: 40,
    reviews: []
  },
  {
    id: 'prod-036',
    name: 'Elysian High-Fidelity Smart Speaker',
    tagline: 'Fill your spaces with acoustic elegance.',
    description: 'A modern, cylindrical wireless speaker clad in gorgeous merino wool textile with an interactive top bronze turntable dial.',
    detailedDescription: 'Combines breathtaking high-fidelity acoustics with smart room calibration. Emits true 360-degree audio, adapting parameters automatically based on wall layout reflections.',
    price: 690,
    images: ['https://images.unsplash.com/photo-1589003077984-894e133dabab?auto=format&fit=crop&w=800&q=80'],
    rating: 4.9,
    reviewsCount: 19,
    category: 'Electronics',
    sizes: ['Home Size'],
    colors: [
      { name: 'Oatmeal Wool', hex: '#FAF9F6' },
      { name: 'Charcoal Tweed', hex: '#374151' }
    ],
    specifications: [
      { label: 'Amplifiers', value: 'Class-D 120W total system power' },
      { label: 'Interfaces', value: 'Wi-Fi 6, AirPlay 2, Spotify Connect, BT 5.2' }
    ],
    isFlashSale: false,
    isBestSeller: false,
    isTrending: true,
    isNewArrival: false,
    stock: 8,
    reviews: []
  },
  {
    id: 'prod-037',
    name: 'Stealth Charge Carbon Pad',
    tagline: 'Accelerated power, sculpted aesthetics.',
    description: 'A 15W high-density wireless charger wrapped in genuine premium carbon fiber skin with a polished aluminum rim.',
    detailedDescription: 'Fast, secure charging without cables. Built-in smart heat-management chips prevent mobile devices from heating up during high-current charging.',
    price: 85,
    originalPrice: 120,
    images: ['https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&w=800&q=80'],
    rating: 4.7,
    reviewsCount: 60,
    category: 'Electronics',
    sizes: ['Standard'],
    colors: [{ name: 'Matte Carbon', hex: '#1C1917' }],
    specifications: [
      { label: 'Charging standard', value: 'WPC Qi-Certified 15W Max' },
      { label: 'Input port', value: 'USB-C Power Delivery 20W' }
    ],
    isFlashSale: true,
    flashSalePrice: 65,
    isBestSeller: true,
    isTrending: false,
    isNewArrival: false,
    stock: 50,
    reviews: []
  },
  {
    id: 'prod-038',
    name: 'Sovereign Pocket Beamer Pro',
    tagline: 'A cinematic theatre inside your pockets.',
    description: 'An ultra-compact 4K portable projector utilizing laser optics, integrated Android TV, and a built-in battery.',
    detailedDescription: 'Cast up to a 150-inch pristine picture onto any flat surface. Autofocus and automatic keystone correction adjust the visual output in less than two seconds.',
    price: 890,
    images: ['https://images.unsplash.com/photo-1535016120720-40c646be5580?auto=format&fit=crop&w=800&q=80'],
    rating: 4.8,
    reviewsCount: 16,
    category: 'Electronics',
    sizes: ['Travel Size'],
    colors: [{ name: 'Space Grey', hex: '#4B5563' }],
    specifications: [
      { label: 'Brightness', value: '1500 ANSI Lumens Laser Light Source' },
      { label: 'Battery Life', value: '3 Hours video projecting' }
    ],
    isFlashSale: false,
    isBestSeller: false,
    isTrending: false,
    isNewArrival: true,
    stock: 5,
    reviews: []
  },
  {
    id: 'prod-039',
    name: 'Atelier ANC Elite Streambar',
    tagline: 'Cinema-level surround sound, elegant profile.',
    description: 'An premium, wall-mountable Dolby Atmos soundbar wrapped in hand-woven Danish kvadrat textile fabric panels.',
    detailedDescription: 'Features 11 high-density drivers with upwards-firing speakers to create immersive surround acoustics. Fits elegantly below luxury television panels.',
    price: 980,
    originalPrice: 1200,
    images: ['https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&w=800&q=80'],
    rating: 4.9,
    reviewsCount: 11,
    category: 'Electronics',
    sizes: ['Standard'],
    colors: [
      { name: 'Kvadrat Grey', hex: '#6B7280' },
      { name: 'Onyx Black', hex: '#111111' }
    ],
    specifications: [
      { label: 'Audio decoding', value: 'Dolby Atmos, DTS:X, LPCM 7.1' },
      { label: 'Inputs', value: 'HDMI eARC, Optical, AirPlay, Bluetooth' }
    ],
    isFlashSale: true,
    flashSalePrice: 850,
    isBestSeller: false,
    isTrending: false,
    isNewArrival: false,
    stock: 6,
    reviews: []
  },
  {
    id: 'prod-040',
    name: 'Titanium Multi-Device Keyboard',
    tagline: 'Precision keys carved in metallic luxury.',
    description: 'An ultra-slim, silent mechanical keyboard utilizing hand-brushed solid grade-5 titanium top plate and Bluetooth multi-pairing.',
    detailedDescription: 'Engineered for developers and executives. Tactile, silent switches provide a satisfying typing click without noise. Recharges via USB-C, lasting 6 months.',
    price: 245,
    images: ['https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=800&q=80'],
    rating: 4.7,
    reviewsCount: 35,
    category: 'Electronics',
    sizes: ['Full Size'],
    colors: [{ name: 'Titanium Silver', hex: '#9CA3AF' }],
    specifications: [
      { label: 'Plate', value: 'Grade-5 Brushed Titanium Alloy' },
      { label: 'Switches', value: 'Custom low-profile silent tactiles' }
    ],
    isFlashSale: false,
    isBestSeller: true,
    isTrending: true,
    isNewArrival: false,
    stock: 15,
    reviews: []
  },

  // ==========================================
  // 6. ACCESSORIES (6 Products)
  // ==========================================
  {
    id: 'prod-041',
    name: 'Sovereign Hexagon Sunglasses',
    tagline: 'Sculpt your visual field in titanium.',
    description: 'Ultra-lightweight hexagonal sunglasses featuring solid Japanese beta-titanium frames and gold-mirrored polarized lenses.',
    detailedDescription: 'Hand-polished in Fukui, Japan. Beta-titanium arms provide incredible elasticity and robust strength, weighting just 14 grams. Full UVA/UVB shield.',
    price: 340,
    originalPrice: 420,
    images: ['https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=800&q=80'],
    rating: 4.9,
    reviewsCount: 52,
    category: 'Accessories',
    sizes: ['Standard'],
    colors: [
      { name: '24K Gold Frame', hex: '#EAB308' },
      { name: 'Polished Platinum', hex: '#D1D5DB' }
    ],
    specifications: [
      { label: 'Frame', value: '100% Japanese Beta-Titanium' },
      { label: 'Lens', value: 'Polarized CR-39 scratch-resistant with anti-reflective coating' }
    ],
    isFlashSale: true,
    flashSalePrice: 280,
    isBestSeller: true,
    isTrending: true,
    isNewArrival: false,
    stock: 11,
    reviews: []
  },
  {
    id: 'prod-042',
    name: 'Saddle Leather Monogram Belt',
    tagline: 'Robust saddle leather, iconic solid brass.',
    description: 'A beautiful 35mm wide belt crafted from heavy English saddle bridle leather, finished with a hand-burnished red accent edge.',
    detailedDescription: 'Double-sided versatility. Constructed from select vegetable-tanned shoulder leathers, completed with an artisan solid-brass buckle carrying the Mahmud emblem.',
    price: 165,
    images: ['https://images.unsplash.com/photo-1624222247344-550fb80555d1?auto=format&fit=crop&w=800&q=80'],
    rating: 4.8,
    reviewsCount: 29,
    category: 'Accessories',
    sizes: ['80cm', '85cm', '90cm', '95cm', '100cm'],
    colors: [
      { name: 'Havana Brown', hex: '#451A03' },
      { name: 'Onyx Black', hex: '#111111' }
    ],
    specifications: [
      { label: 'Material', value: 'Vegetable-Tanned English Bridle Leather' },
      { label: 'Buckle', value: '100% Solid sand-cast brass' }
    ],
    isFlashSale: false,
    isBestSeller: true,
    isTrending: false,
    isNewArrival: false,
    stock: 30,
    reviews: []
  },
  {
    id: 'prod-043',
    name: 'Mulberry Silk Monogram Scarf',
    tagline: 'Whispers of absolute silk sophistication.',
    description: 'A large, square silk scarf hand-printed with seasonal abstract motifs and hand-rolled edge boundaries.',
    detailedDescription: 'Woven in Lyon, France, from premium long-fiber mulberry silk. The colors are incredibly deep and hold rich vibrancies over years of wear. Tie around handbag handles or drape over wool coats.',
    price: 240,
    images: ['https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=800&q=80'],
    rating: 4.9,
    reviewsCount: 18,
    category: 'Accessories',
    sizes: ['90cm x 90cm'],
    colors: [
      { name: 'Sovereign Red', hex: '#E60023' },
      { name: 'Midnight Gold', hex: '#D97706' }
    ],
    specifications: [
      { label: 'Material', value: '100% Twill Mulberry Silk (18 momme)' },
      { label: 'Edges', value: 'Exquisite hand-rolled needle stitched' }
    ],
    isFlashSale: false,
    isBestSeller: false,
    isTrending: true,
    isNewArrival: true,
    stock: 12,
    reviews: []
  },
  {
    id: 'prod-044',
    name: 'Sovereign Leather Bi-Fold Wallet',
    tagline: 'Streamlined pocket asset organization.',
    description: 'An ultra-slim bi-fold wallet made from premium french calfskin, offering 8 credit card slots and RFID protection layers.',
    detailedDescription: 'Hand-painted raw edge finishes. Fits flush inside custom suit interior chest pockets without causing lines.',
    price: 180,
    originalPrice: 220,
    images: ['https://images.unsplash.com/photo-1624222247344-550fb80555d1?auto=format&fit=crop&w=800&q=80'],
    rating: 4.7,
    reviewsCount: 41,
    category: 'Accessories',
    sizes: ['One Size'],
    colors: [
      { name: 'Espresso Calf', hex: '#1F1610' },
      { name: 'Obsidian Black', hex: '#111111' }
    ],
    specifications: [
      { label: 'Material', value: 'French box calf leather skin' },
      { label: 'Shielding', value: 'Integrated flexible RFID blocking foil' }
    ],
    isFlashSale: true,
    flashSalePrice: 145,
    isBestSeller: false,
    isTrending: false,
    isNewArrival: false,
    stock: 22,
    reviews: []
  },
  {
    id: 'prod-045',
    name: 'Extrafine Merino Wool Gloves',
    tagline: 'Warm fingertips, mobile responsive.',
    description: 'Fine ribbed knit gloves tailored in extrafine Australian merino wool with capacitive touch tips on the indices.',
    detailedDescription: 'Never freeze your hands to type. Crafted from double-ply merino, keeping hands extremely warm while providing flawless smartphone interaction.',
    price: 95,
    images: ['https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=800&q=80'],
    rating: 4.6,
    reviewsCount: 15,
    category: 'Accessories',
    sizes: ['S/M', 'L/XL'],
    colors: [{ name: 'Heather Grey', hex: '#9CA3AF' }],
    specifications: [
      { label: 'Yarn', value: '100% Extrafine Merino Wool' },
      { label: 'Tips', value: 'Capacitive silver nylon thread embroidery' }
    ],
    isFlashSale: false,
    isBestSeller: true,
    isTrending: false,
    isNewArrival: false,
    stock: 35,
    reviews: []
  },
  {
    id: 'prod-046',
    name: 'Sovereign Cashmere Ribbed Beanie',
    tagline: 'Absolute crowning softness.',
    description: 'A classic, thick cuffed knit beanie crafted in 100% pure organic cashmere from high-altitude Mongolian herds.',
    detailedDescription: 'Beautifully insulated, highly stretchable, and incredibly soft. Classic fisherman rib pattern fits all head sizes seamlessly.',
    price: 135,
    images: ['https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=800&q=80'],
    rating: 4.9,
    reviewsCount: 33,
    category: 'Accessories',
    sizes: ['One Size'],
    colors: [
      { name: 'Oatmeal Heather', hex: '#EAE6DF' },
      { name: 'Charcoal Black', hex: '#262626' }
    ],
    specifications: [
      { label: 'Composition', value: '100% Grade-A cashmere knit' },
      { label: 'Care', value: 'Dry clean or cold wool wash' }
    ],
    isFlashSale: false,
    isBestSeller: false,
    isTrending: false,
    isNewArrival: true,
    stock: 18,
    reviews: []
  },

  // ==========================================
  // 7. SPORTS ITEMS (6 Products)
  // ==========================================
  {
    id: 'prod-047',
    name: 'Atelier Premium Cork Yoga Mat',
    tagline: 'Grounded organic posture, ultimate grip.',
    description: 'An eco-luxury yoga mat crafted with sustainable Portuguese cork tree bark and a thick, high-density natural rubber base.',
    detailedDescription: 'Ditch the synthetic plastics. The raw cork surface active-grip increases when wet with sweat, keeping you stable in rigorous sessions. Printed with laser-etched posture alignment guides.',
    price: 145,
    originalPrice: 195,
    images: ['https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?auto=format&fit=crop&w=800&q=80'],
    rating: 4.9,
    reviewsCount: 30,
    category: 'Sports Items',
    sizes: ['72" x 26"'],
    colors: [{ name: 'Natural Cork', hex: '#CDBA96' }],
    specifications: [
      { label: 'Top', value: '100% Sustainable Organic Portuguese Cork' },
      { label: 'Bottom', value: '6mm Non-slip Vietnamese natural rubber base' },
      { label: 'Weight', value: '2.8 kg heavy density' }
    ],
    isFlashSale: true,
    flashSalePrice: 115,
    isBestSeller: true,
    isTrending: true,
    isNewArrival: false,
    stock: 12,
    reviews: []
  },
  {
    id: 'prod-048',
    name: 'Elysian Gym Duffel Bag',
    tagline: 'Your athletic armory in weather-sealed style.',
    description: 'A structural, water-sealed duffel crafted with premium recycled matte composite skin, ventilated shoe cabins, and water bottle slots.',
    detailedDescription: 'The perfect gym companion. Features internal waterproof sections for wet swimwear, side elastic pockets, and a magnetic handle wrap.',
    price: 185,
    images: ['https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80'],
    rating: 4.8,
    reviewsCount: 22,
    category: 'Sports Items',
    sizes: ['35L'],
    colors: [
      { name: 'Onyx Black', hex: '#111111' },
      { name: 'Olive Green', hex: '#4B5320' }
    ],
    specifications: [
      { label: 'Material', value: 'Waterproof Matte TPU Coated Canvas' },
      { label: 'Zippers', value: 'Seamless weather-sealed aqua closures' }
    ],
    isFlashSale: false,
    isBestSeller: true,
    isTrending: false,
    isNewArrival: false,
    stock: 20,
    reviews: []
  },
  {
    id: 'prod-049',
    name: 'Stealth Thermal Water Flask',
    tagline: 'Double-walled steel, extreme chill index.',
    description: 'A 1.0-liter double-walled vacuum insulated flask crafted with culinary grade stainless steel and a scratch-proof powder coat finish.',
    detailedDescription: 'Retains cold beverages chilled for 36 hours and hot drinks warm for 18 hours. Wide-mouth screw cap is leak-proof, detailed with an integrated carry loop.',
    price: 65,
    images: ['https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=800&q=80'],
    rating: 4.7,
    reviewsCount: 75,
    category: 'Sports Items',
    sizes: ['1.0 Liter'],
    colors: [
      { name: 'Stealth Black', hex: '#111111' },
      { name: 'Sovereign Red', hex: '#E60023' }
    ],
    specifications: [
      { label: 'Metal', value: '18/8 Pro-Grade Culinary Stainless Steel' },
      { label: 'Cap', value: 'BPA-Free, leak-proof magnetic lock cap' }
    ],
    isFlashSale: false,
    isBestSeller: true,
    isTrending: false,
    isNewArrival: false,
    stock: 60,
    reviews: []
  },
  {
    id: 'prod-050',
    name: 'Sovereign Dial Adjustable Dumbbells',
    tagline: 'Entire dumbbell racks, compacted.',
    description: 'An elite single adjustable dumbbell with robust safety dial selectors shifting weights from 2.5kg up to 24kg instantly.',
    detailedDescription: 'Maximized home workout efficiency. Heavy steel core plates are wrapped in thick, noise-absorbing thermoplastic polymer shields to prevent floor scratches.',
    price: 320,
    originalPrice: 390,
    images: ['https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=800&q=80'],
    rating: 4.8,
    reviewsCount: 18,
    category: 'Sports Items',
    sizes: ['Single (24kg)'],
    colors: [{ name: 'Industrial Grey', hex: '#4B5563' }],
    specifications: [
      { label: 'Plates', value: 'Heavy cast-iron core with polymer shields' },
      { label: 'Weights Range', value: '2.5kg to 24kg (15 settings)' }
    ],
    isFlashSale: true,
    flashSalePrice: 275,
    isBestSeller: false,
    isTrending: true,
    isNewArrival: false,
    stock: 8,
    reviews: []
  },
  {
    id: 'prod-051',
    name: 'Sartorial latex Resistance Bands',
    tagline: 'Uncompromising elasticity, zero snapped fibers.',
    description: 'Set of five loop resistance exercise bands tailored in 100% natural Malaysian latex with premium carrying pouches.',
    detailedDescription: 'Five distinct resistance ratings, perfect for physical therapies, strength training, or stretching routines.',
    price: 45,
    images: ['https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=800&q=80'],
    rating: 4.6,
    reviewsCount: 32,
    category: 'Sports Items',
    sizes: ['5-Pack Set'],
    colors: [{ name: 'Multi-Resistance', hex: '#6B7280' }],
    specifications: [
      { label: 'Material', value: '100% Genuine eco natural latex' },
      { label: 'Tension', value: 'From 5 lbs to 40 lbs load equivalents' }
    ],
    isFlashSale: false,
    isBestSeller: false,
    isTrending: false,
    isNewArrival: true,
    stock: 45,
    reviews: []
  },
  {
    id: 'prod-052',
    name: 'Atelier Premium Leather Skipping Rope',
    tagline: 'Cardio speed, handcrafted legacy.',
    description: 'An elite skipping speed rope detailed with hand-wrapped cowhide leather handles and high-velocity dual steel ball-bearings.',
    detailedDescription: 'Adjustable weighted steel cable wrapped in supple raw leather skin. Provides a fast, heavy visual swing loop ideal for boxers and professional cardio athletes.',
    price: 75,
    images: ['https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=800&q=80'],
    rating: 4.9,
    reviewsCount: 12,
    category: 'Sports Items',
    sizes: ['Adjustable 3M'],
    colors: [{ name: 'Saddle Leather Brown', hex: '#7C2D12' }],
    specifications: [
      { label: 'Bearing caliber', value: 'High-speed 360 degree fluid ball joint' },
      { label: 'Rope material', value: 'Cowhide leather over protective steel core' }
    ],
    isFlashSale: false,
    isBestSeller: false,
    isTrending: false,
    isNewArrival: true,
    stock: 14,
    reviews: []
  }
];

export const INITIAL_COUPONS: Coupon[] = [
  { code: 'MAHMUD20', discountType: 'percentage', value: 20, minSpend: 200, isActive: true },
  { code: 'LUXURY50', discountType: 'fixed', value: 50, minSpend: 300, isActive: true },
  { code: 'WELCOME10', discountType: 'percentage', value: 10, minSpend: 0, isActive: true }
];

export const INITIAL_BANNERS: Banner[] = [
  {
    id: 'ban-001',
    title: 'THE ROYAL REDEFINTION',
    subtitle: 'Autumn/Winter Haute Couture Collection 2026',
    ctaText: 'Explore Collection',
    image: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?auto=format&fit=crop&w=1600&q=80',
    isActive: true
  },
  {
    id: 'ban-002',
    title: 'THE SILK HORIZON',
    subtitle: 'Fluid lines and luxury evening attire curated for you.',
    ctaText: 'Shop New Arrivals',
    image: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1600&q=80',
    isActive: true
  },
  {
    id: 'ban-003',
    title: 'ARCHITECTURAL SUITS',
    subtitle: 'Crisp whites, deep blacks, bold structures.',
    ctaText: 'Discover Suits',
    image: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=1600&q=80',
    isActive: true
  }
];

export const CATEGORIES = ['All', 'Fashion', 'Shoes', 'Watches', 'Bags', 'Electronics', 'Accessories', 'Sports Items'];
