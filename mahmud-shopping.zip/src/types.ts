export interface Review {
  id: string;
  userName: string;
  rating: number;
  comment: string;
  date: string;
}

export interface Product {
  id: string;
  name: string;
  tagline?: string;
  description: string;
  detailedDescription?: string;
  price: number;
  originalPrice?: number;
  images: string[];
  rating: number;
  reviewsCount: number;
  reviews: Review[];
  category: string;
  sizes: string[];
  colors: { name: string; hex: string }[];
  specifications: { label: string; value: string }[];
  isFlashSale?: boolean;
  flashSalePrice?: number;
  isBestSeller?: boolean;
  isTrending?: boolean;
  isNewArrival?: boolean;
  stock: number;
}

export interface CartItem {
  id: string; // Unique combination of product.id + size + color
  product: Product;
  selectedSize: string;
  selectedColor: { name: string; hex: string };
  quantity: number;
}

export interface Address {
  id: string;
  label: string;
  fullName: string;
  phone: string;
  street: string;
  city: string;
  postalCode: string;
  country: string;
  isDefault: boolean;
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'user' | 'admin';
  phone?: string;
  addresses: Address[];
}

export interface Order {
  id: string;
  trackingNumber: string;
  date: string;
  items: CartItem[];
  subtotal: number;
  shippingCost: number;
  discount: number;
  total: number;
  status: 'Pending' | 'Processing' | 'Shipped' | 'Delivered' | 'Cancelled';
  paymentMethod: 'cod' | 'bkash';
  paymentStatus: 'Pending' | 'Paid' | 'Failed';
  shippingAddress: Address;
  notes?: string;
  couponCode?: string;
}

export interface Coupon {
  code: string;
  discountType: 'percentage' | 'fixed';
  value: number;
  minSpend: number;
  isActive: boolean;
}

export interface Banner {
  id: string;
  title: string;
  subtitle: string;
  ctaText: string;
  image: string;
  isActive: boolean;
}
