import React, { useState, useEffect } from 'react';
import { ArrowRight, Star, ShoppingBag, Eye, Heart, Flame, ShieldCheck, Truck, RefreshCw, Zap, Sparkles } from 'lucide-react';
import { Product, Banner } from '../types';

interface HomeViewProps {
  products: Product[];
  banners: Banner[];
  onNavigate: (view: string, params?: any) => void;
  onQuickView: (product: Product) => void;
  onAddToWishlist: (product: Product) => void;
  wishlistIds: string[];
  onToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
}

export default function HomeView({
  products,
  banners,
  onNavigate,
  onQuickView,
  onAddToWishlist,
  wishlistIds,
  onToast
}: HomeViewProps) {
  const [countdown, setCountdown] = useState({ hours: 4, minutes: 12, seconds: 59 });

  // Hero background image slider state
  const sliderImages = [
    'https://images.unsplash.com/photo-1469334031218-e382a71b716b?auto=format&fit=crop&w=1600&q=80',
    'https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=1600&q=80',
    'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1600&q=80'
  ];
  const [currentSlide, setCurrentSlide] = useState(0);

  // Auto slide every 4 seconds
  useEffect(() => {
    const slideInterval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % sliderImages.length);
    }, 4000);
    return () => clearInterval(slideInterval);
  }, []);

  // Flash Sale Countdown timer
  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { hours: prev.hours, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        } else {
          return { hours: 4, minutes: 12, seconds: 59 }; // Reset
        }
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const flashSaleProducts = products.filter(p => p.isFlashSale);

  const categoriesList = [
    { name: 'Fashion', image: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?auto=format&fit=crop&w=400&q=80', items: '14 Items' },
    { name: 'Shoes', image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=400&q=80', items: '8 Items' },
    { name: 'Watches', image: 'https://images.unsplash.com/photo-1524592094714-0f0654e20314?auto=format&fit=crop&w=400&q=80', items: '6 Items' },
    { name: 'Bags', image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=400&q=80', items: '8 Items' },
    { name: 'Electronics', image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=400&q=80', items: '6 Items' }
  ];

  const trustStats = [
    { icon: <Truck className="w-6 h-6 text-[#E60023]" />, title: 'COMPLIMENTARY DHL EXPRESS', desc: 'On orders over $500, else standard courier' },
    { icon: <ShieldCheck className="w-6 h-6 text-[#E60023]" />, title: 'AUTHENTICITY ASSURED', desc: 'Straight from Milan & Paris fashion ateliers' },
    { icon: <RefreshCw className="w-6 h-6 text-[#E60023]" />, title: '30-DAY COUTURE TRIAL', desc: 'Hassle-free custom-fit returns and swaps' }
  ];

  const customerReviews = [
    { name: 'Yasmin Rahman', role: 'Dhaka Stylist', comment: 'Mahmud Shopping provides unparalleled customer care and elite-level fabrics. My bespoke suits fit exactly as designed!', rating: 5 },
    { name: 'Faisal Kabir', role: 'Creative Director', comment: 'The wool long coat exceeded all expectations. The velvet blazer has a rich, captivating luster. Masterclass craftsmanship!', rating: 5 },
    { name: 'Zara S.', role: 'Fashion Influencer', comment: 'Arrived within 24 hours via premium courier. The silk gown is fluid, eye-safe, and perfectly weighted. Outstanding.', rating: 5 }
  ];

  const instagramMedia = [
    'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=300&q=80',
    'https://images.unsplash.com/photo-1469334031218-e382a71b716b?auto=format&fit=crop&w=300&q=80',
    'https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=300&q=80',
    'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=300&q=80',
    'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=300&q=80',
    'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80'
  ];

  return (
    <div id="home-view" className="space-y-16 animate-fade-in pb-12 bg-white text-black">
      
      {/* 1. Hero Section with Background Image Slider */}
      <section id="hero-section" className="relative flex flex-col items-center justify-center text-center overflow-hidden max-w-7xl mx-auto border-b border-neutral-150 min-h-[60vh] sm:min-h-[70vh] md:min-h-[80vh] rounded-3xl mt-4">
        
        {/* Background Images Layer */}
        {sliderImages.map((img, idx) => (
          <div
            key={idx}
            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
              idx === currentSlide ? 'opacity-15 scale-100' : 'opacity-0 scale-105'
            }`}
          >
            <img src={img} alt="" className="w-full h-full object-cover transition-transform duration-[4000ms]" />
          </div>
        ))}

        {/* Soft Luxury Glassmorphic Overlay */}
        <div className="absolute inset-0 bg-white/70 backdrop-blur-[1px] pointer-events-none" />

        {/* Centered Typography Content */}
        <div className="relative z-10 space-y-8 sm:space-y-10 max-w-5xl px-4 py-16">
          <h1 className="font-black uppercase tracking-tight leading-none select-none">
            <span className="block text-black text-5xl sm:text-7xl md:text-8xl lg:text-[95px] xl:text-[115px] transition-all">
              WELCOME TO
            </span>
            <span className="block text-[#E60023] text-5xl sm:text-7xl md:text-8xl lg:text-[95px] xl:text-[115px] transition-all mt-4">
              MAHMUD SHOPPING
            </span>
          </h1>

          <p className="text-sm sm:text-lg md:text-xl text-neutral-500 font-medium tracking-wide max-w-2xl mx-auto leading-relaxed">
            Your Premium Online Shopping Destination
          </p>

          <div className="pt-4 flex justify-center">
            <button
              onClick={() => onNavigate('shop')}
              className="bg-[#E60023] text-white hover:opacity-90 active:scale-95 px-10 py-4 sm:px-14 sm:py-4.5 rounded-xl text-xs sm:text-sm font-extrabold tracking-[0.25em] transition-all duration-300 shadow-lg shadow-red-500/15 uppercase"
            >
              Shop Now
            </button>
          </div>
        </div>

        {/* Slider Navigation Arrows */}
        <button
          onClick={() => setCurrentSlide((prev) => (prev - 1 + sliderImages.length) % sliderImages.length)}
          className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white text-black p-2.5 rounded-full shadow-md hover:text-[#E60023] transition-all border border-neutral-100 z-20"
          title="Previous slide"
        >
          <span className="text-xs font-black select-none">&larr;</span>
        </button>
        <button
          onClick={() => setCurrentSlide((prev) => (prev + 1) % sliderImages.length)}
          className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white text-black p-2.5 rounded-full shadow-md hover:text-[#E60023] transition-all border border-neutral-100 z-20"
          title="Next slide"
        >
          <span className="text-xs font-black select-none">&rarr;</span>
        </button>

        {/* Slider Dots Indicator */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2 z-20">
          {sliderImages.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentSlide(idx)}
              className={`w-2.5 h-2.5 rounded-full transition-all ${
                idx === currentSlide ? 'bg-[#E60023] w-6' : 'bg-neutral-300 hover:bg-neutral-400'
              }`}
            >
              <span className="sr-only">Slide {idx + 1}</span>
            </button>
          ))}
        </div>

      </section>

      {/* 2. Featured Categories */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="text-center space-y-2">
          <p className="text-xs font-bold tracking-[0.3em] text-[#E60023] uppercase">AESTHETIC DEPARTMENTS</p>
          <h2 className="text-3xl font-black tracking-tight uppercase text-black">Featured Categories</h2>
          <div className="w-16 h-1 bg-[#E60023] mx-auto rounded-full" />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {categoriesList.map((cat) => (
            <div
              key={cat.name}
              onClick={() => onNavigate('shop', { category: cat.name })}
              className="group relative h-64 rounded-2xl overflow-hidden cursor-pointer shadow-md transition-all duration-500 hover:shadow-xl hover:-translate-y-1"
            >
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/25 to-transparent z-10" />
              <img
                src={cat.image}
                alt={cat.name}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute bottom-4 left-4 z-20 text-white space-y-0.5">
                <h3 className="text-sm font-extrabold uppercase tracking-widest">{cat.name}</h3>
                <p className="text-[10px] tracking-wider text-neutral-300">{cat.items}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. Flash Sale Section with timer */}
      {flashSaleProducts.length > 0 && (
        <section className="bg-white py-12 border-y border-neutral-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-4 gap-12 items-center">
            
            {/* Flash Sale Promo block */}
            <div className="space-y-6 lg:col-span-1">
              <div className="inline-flex items-center gap-1 bg-[#E60023] text-white text-[10px] font-bold tracking-widest uppercase px-3 py-1 rounded-full">
                <Flame className="w-3.5 h-3.5 fill-white" /> 24HR VENTURE
              </div>
              <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-black uppercase leading-tight">
                Flash Sale <br />
                <span className="text-[#E60023]">Event is Live</span>
              </h2>
              <p className="text-xs text-neutral-500">
                Premium garments on rare markdown for limited stock. Strictly limited runs. Swaps apply.
              </p>
              
              {/* Timer Box */}
              <div className="space-y-2">
                <p className="text-[10px] font-bold tracking-widest text-neutral-400 uppercase">Atelier Timer Ends In:</p>
                <div className="flex gap-2 text-center font-mono select-none">
                  <div className="bg-black text-white rounded-lg p-2.5 min-w-14">
                    <span className="text-xl font-bold">{String(countdown.hours).padStart(2, '0')}</span>
                    <p className="text-[8px] text-neutral-400 tracking-wider">HRS</p>
                  </div>
                  <div className="bg-black text-white rounded-lg p-2.5 min-w-14">
                    <span className="text-xl font-bold">{String(countdown.minutes).padStart(2, '0')}</span>
                    <p className="text-[8px] text-neutral-400 tracking-wider">MIN</p>
                  </div>
                  <div className="bg-[#E60023] text-white rounded-lg p-2.5 min-w-14">
                    <span className="text-xl font-bold animate-pulse">{String(countdown.seconds).padStart(2, '0')}</span>
                    <p className="text-[8px] text-white tracking-wider">SEC</p>
                  </div>
                </div>
              </div>

              <button
                onClick={() => onNavigate('shop', { filter: 'flash-sale' })}
                className="w-full bg-[#E60023] text-white py-3.5 rounded-xl text-xs font-bold tracking-widest hover:bg-[#E60023]/90 transition-all duration-300 shadow"
              >
                BROWSE FLASH MARKDOWNS
              </button>
            </div>

            {/* Flash Sale Product list */}
            <div className="lg:col-span-3 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
              {flashSaleProducts.slice(0, 3).map((prod) => {
                const discount = prod.originalPrice ? Math.round(((prod.originalPrice - prod.price) / prod.originalPrice) * 100) : 0;
                return (
                  <div
                    key={prod.id}
                    className="bg-white rounded-2xl overflow-hidden border border-neutral-100 shadow-md group relative flex flex-col justify-between"
                  >
                    <div className="relative aspect-square overflow-hidden bg-white p-4">
                      <img
                        src={prod.images[0]}
                        alt={prod.name}
                        className="w-full h-full object-contain mix-blend-multiply transition-transform duration-500 group-hover:scale-105"
                      />
                      {discount > 0 && (
                        <span className="absolute top-3 left-3 bg-[#E60023] text-white text-[9px] font-bold px-2 py-0.5 rounded-full font-mono">
                          -{discount}%
                        </span>
                      )}
                      
                      {/* Interactive hover utilities */}
                      <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-3 z-20">
                        <button
                          onClick={() => onQuickView(prod)}
                          className="bg-white hover:bg-[#E60023] hover:text-white text-black p-2.5 rounded-full transition-all duration-200 transform scale-90 group-hover:scale-100 shadow-md"
                          title="Quick Inspect"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => onAddToWishlist(prod)}
                          className="bg-white hover:bg-[#E60023] hover:text-white text-black p-2.5 rounded-full transition-all duration-200 transform scale-90 group-hover:scale-100 shadow-md"
                          title="Wishlist"
                        >
                          <Heart className={`w-4 h-4 ${wishlistIds.includes(prod.id) ? 'fill-[#E60023] text-[#E60023]' : ''}`} />
                        </button>
                      </div>
                    </div>

                    <div className="p-4 space-y-2">
                      <div>
                        <p className="text-[10px] text-neutral-450 font-bold uppercase">{prod.category}</p>
                        <h4
                          onClick={() => onNavigate('product-details', { productId: prod.id })}
                          className="text-xs font-bold text-black hover:text-[#E60023] cursor-pointer truncate"
                        >
                          {prod.name}
                        </h4>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-extrabold text-[#E60023]">${prod.price}</span>
                        {prod.originalPrice && (
                          <span className="text-xs text-neutral-400 line-through">${prod.originalPrice}</span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

          </div>
        </section>
      )}

      {/* 4. Best Sellers & New Arrivals Showcase */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col sm:flex-row justify-between items-baseline gap-4 border-b border-neutral-200 pb-4">
          <div>
            <p className="text-xs font-bold tracking-[0.3em] text-[#E60023] uppercase">HIGH DEMAND ESSENTIALS</p>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight uppercase text-black mt-1">Trending at Mahmud</h2>
          </div>
          <button
            onClick={() => onNavigate('shop')}
            className="text-xs font-bold text-[#E60023] hover:opacity-85 flex items-center gap-1 uppercase tracking-widest"
          >
            Shop Full Catalog <ArrowRight className="w-3.5 h-3.5 text-[#E60023]" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {products.slice(0, 4).map((prod) => {
            const isWish = wishlistIds.includes(prod.id);
            return (
              <div
                key={prod.id}
                className="group border border-neutral-100 rounded-2xl overflow-hidden shadow-sm hover:shadow-xl bg-white transition-all duration-300 flex flex-col justify-between"
              >
                <div className="relative aspect-square overflow-hidden bg-white p-4">
                  <img
                    src={prod.images[0]}
                    alt={prod.name}
                    className="w-full h-full object-contain transition-transform duration-500 group-hover:scale-105"
                  />
                  {prod.isNewArrival && (
                    <span className="absolute top-3 left-3 bg-[#E60023] text-white text-[9px] font-bold px-2 py-0.5 rounded-full tracking-widest uppercase font-mono">
                      NEW DROP
                    </span>
                  )}
                  {prod.isBestSeller && (
                    <span className="absolute top-3 right-3 bg-black text-white text-[9px] font-bold px-2 py-0.5 rounded-full tracking-widest uppercase font-mono">
                      BEST SELLER
                    </span>
                  )}

                  {/* Actions overlay */}
                  <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-3 z-10">
                    <button
                      onClick={() => onQuickView(prod)}
                      className="bg-white text-black hover:bg-[#E60023] hover:text-white p-2.5 rounded-full transition-transform transform scale-90 group-hover:scale-100 shadow-md"
                      title="Quick View"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onAddToWishlist(prod)}
                      className="bg-white text-black hover:bg-[#E60023] hover:text-white p-2.5 rounded-full transition-transform transform scale-90 group-hover:scale-100 shadow-md"
                      title="Wishlist"
                    >
                      <Heart className={`w-4 h-4 ${isWish ? 'fill-[#E60023] text-[#E60023]' : ''}`} />
                    </button>
                    <button
                      onClick={() => onNavigate('product-details', { productId: prod.id })}
                      className="bg-white text-black hover:bg-[#E60023] hover:text-white p-2.5 rounded-full transition-transform transform scale-90 group-hover:scale-100 shadow-md"
                      title="View Details"
                    >
                      <ShoppingBag className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                <div className="p-4 space-y-2">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-neutral-400 tracking-widest">
                      {prod.category}
                    </span>
                    <h3
                      onClick={() => onNavigate('product-details', { productId: prod.id })}
                      className="text-sm font-bold text-black hover:text-[#E60023] cursor-pointer truncate mt-0.5"
                    >
                      {prod.name}
                    </h3>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-base font-black text-black">
                      ${prod.price}
                    </span>
                    {prod.originalPrice && (
                      <span className="text-xs text-neutral-400 line-through">
                        ${prod.originalPrice}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-1.5 pt-1">
                    <div className="flex gap-0.5">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-3 h-3 ${
                            i < Math.floor(prod.rating) ? 'fill-amber-400 text-amber-400' : 'text-neutral-200'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-[10px] font-semibold text-neutral-500">({prod.reviewsCount})</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 5. Luxury Featured Collections Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative bg-white text-black rounded-3xl overflow-hidden shadow-xl p-8 sm:p-12 lg:p-16 flex flex-col md:flex-row items-center gap-12 border border-neutral-200">
          <div className="absolute inset-0 opacity-10 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-[#E60023] via-white to-white z-0" />
          
          <div className="space-y-6 flex-1 z-10 text-left">
            <span className="text-[#E60023] font-bold tracking-[0.3em] text-xs uppercase block">THE MODERN GENTLEMAN</span>
            <h2 className="text-3xl sm:text-5xl font-black uppercase tracking-tight leading-none text-black">
              ATELIER BESPOKE <br />
              SUITS & COATS
            </h2>
            <p className="text-xs sm:text-sm text-neutral-500 max-w-md leading-relaxed">
              Experience hand-crafted bespoke suits made of 100% genuine crepe and premium wool with tailored silk lining details. Elegance for the elite visionary.
            </p>
            <div className="flex gap-4">
              <button
                onClick={() => onNavigate('shop', { category: 'Suits' })}
                className="bg-[#E60023] text-white hover:opacity-90 px-6 py-3.5 rounded-xl text-xs font-bold tracking-widest transition-all duration-300 shadow"
              >
                DISCOVER SUITS
              </button>
              <button
                onClick={() => onNavigate('shop', { category: 'Outerwear' })}
                className="border border-neutral-300 hover:border-[#E60023] hover:text-[#E60023] px-6 py-3.5 rounded-xl text-xs font-bold tracking-widest transition-all duration-300 text-black"
              >
                OUTERWEAR CAPSULES
              </button>
            </div>
          </div>

          <div className="flex-1 w-full relative z-10">
            <div className="grid grid-cols-2 gap-4">
              <img
                src="https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=400&q=80"
                alt="Suit aesthetic"
                className="rounded-2xl h-48 sm:h-64 w-full object-cover shadow-lg border border-neutral-100"
              />
              <img
                src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=400&q=80"
                alt="Suit details"
                className="rounded-2xl h-48 sm:h-64 w-full object-cover shadow-lg translate-y-6 border border-neutral-100"
              />
            </div>
          </div>
        </div>
      </section>

      {/* 6. Elite Services/Trust Pillars */}
      <section className="bg-white py-12 border-y border-neutral-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            {trustStats.map((pillar, index) => (
              <div key={index} className="space-y-3 p-4 flex flex-col items-center">
                <div className="p-3 bg-white rounded-full shadow-md border border-neutral-100">
                  {pillar.icon}
                </div>
                <h3 className="text-xs font-bold tracking-[0.2em] text-black uppercase">
                  {pillar.title}
                </h3>
                <p className="text-xs text-neutral-500 max-w-xs">
                  {pillar.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. Customer Reviews Carousel */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="text-center space-y-2">
          <p className="text-xs font-bold tracking-[0.3em] text-[#E60023] uppercase">SATISFIED ATELIER PATRONS</p>
          <h2 className="text-3xl font-black tracking-tight uppercase text-black">Verified Reviews</h2>
          <div className="w-16 h-1 bg-[#E60023] mx-auto rounded-full" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {customerReviews.map((rev, index) => (
            <div
              key={index}
              className="bg-white border border-neutral-100 p-6 rounded-2xl shadow-sm hover:shadow-md transition-shadow relative flex flex-col justify-between"
            >
              <div className="space-y-4">
                <div className="flex gap-1">
                  {[...Array(rev.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                </div>
                <p className="text-xs text-neutral-600 leading-relaxed italic">
                  "{rev.comment}"
                </p>
              </div>
              <div className="pt-4 border-t border-neutral-100 mt-4 flex justify-between items-center">
                <div>
                  <h4 className="text-xs font-bold text-black">{rev.name}</h4>
                  <p className="text-[10px] text-neutral-450">{rev.role}</p>
                </div>
                <div className="bg-red-50 text-[#E60023] px-2.5 py-0.5 rounded-full text-[9px] font-mono font-black uppercase">
                  Verified Purchase
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 8. Brand Showcase */}
      <section className="bg-white text-neutral-500 border-y border-neutral-200 py-12 select-none">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-wrap justify-center items-center gap-12 sm:gap-16">
          <span className="text-xs tracking-[0.5em] font-extrabold text-black">MAHMUD ATELIER</span>
          <span className="text-xs tracking-[0.3em] font-semibold hover:text-[#E60023] transition-colors">VOGUE PARIS</span>
          <span className="text-xs tracking-[0.4em] font-bold hover:text-[#E60023] transition-colors">MILANO COUTURE</span>
          <span className="text-xs tracking-[0.35em] font-medium hover:text-[#E60023] transition-colors">HARPERS BAZAAR</span>
          <span className="text-xs tracking-[0.5em] font-extrabold hover:text-[#E60023] transition-colors">GQ STYLE</span>
        </div>
      </section>

      {/* 9. Instagram Gallery */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="text-center space-y-2">
          <p className="text-xs font-bold tracking-[0.3em] text-[#E60023] uppercase">#MAHMUD_COUTURE</p>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight uppercase text-black">Atelier Life on Instagram</h2>
          <p className="text-xs text-neutral-500">Tag us on Instagram to get featured in our seasonal lookbooks.</p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          {instagramMedia.map((url, idx) => (
            <div
              key={idx}
              className="group relative h-48 rounded-xl overflow-hidden cursor-pointer"
            >
              <div className="absolute inset-0 bg-[#E60023]/10 opacity-0 group-hover:opacity-100 transition-opacity z-10" />
              <img
                src={url}
                alt=""
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
            </div>
          ))}
        </div>
      </section>

    </div>
  );
}
