import React, { useState } from 'react';
import {
  TrendingUp,
  ShoppingBag,
  DollarSign,
  Plus,
  Trash2,
  Edit,
  X,
  Truck,
  AlertTriangle,
  Settings,
  Percent,
  Users,
  FolderTree,
  CreditCard,
  Star,
  Check
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell
} from 'recharts';
import { Product, Order, Coupon, Banner } from '../types';

interface AdminViewProps {
  products: Product[];
  orders: Order[];
  coupons: Coupon[];
  banners: Banner[];
  onUpdateProducts: (updatedList: Product[]) => void;
  onUpdateOrders: (updatedList: Order[]) => void;
  onUpdateCoupons: (updatedList: Coupon[]) => void;
  onNavigate: (view: string, params?: any) => void;
  onToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
}

export default function AdminView({
  products,
  orders,
  coupons,
  onUpdateProducts,
  onUpdateOrders,
  onUpdateCoupons,
  onNavigate,
  onToast
}: AdminViewProps) {
  const [activeTab, setActiveTab] = useState<
    'analytics' | 'products' | 'orders' | 'coupons' | 'settings' | 'customers' | 'categories' | 'payments' | 'reviews'
  >('analytics');

  // Product CRUD states
  const [showProductModal, setShowProductModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [prodName, setProdName] = useState('');
  const [prodPrice, setProdPrice] = useState(250);
  const [prodOriginalPrice, setProdOriginalPrice] = useState<number | undefined>(undefined);
  const [prodCategory, setProdCategory] = useState('Fashion');
  const [prodStock, setProdStock] = useState(15);
  const [prodDescription, setProdDescription] = useState('');
  const [prodImage, setProdImage] = useState('');
  const [prodSizes, setProdSizes] = useState('S,M,L,XL');

  // Category Manager states
  const [categoriesList, setCategoriesList] = useState<string[]>([
    'Fashion', 'Shoes', 'Watches', 'Bags', 'Electronics', 'Accessories', 'Sports Items'
  ]);
  const [showCategoryForm, setShowCategoryForm] = useState(false);
  const [newCategoryName, setNewCategoryName] = useState('');

  // Customer states
  const [customers, setCustomers] = useState([
    { id: 'cust-1', name: 'Liam Mahmud', email: 'liam@mahmudshopping.com', phone: '+880 1712-345678', joined: '2026-01-15', totalSpend: 1540, ordersCount: 4, status: 'Active' },
    { id: 'cust-2', name: 'Sophia Rahman', email: 'sophia@mahmudshopping.com', phone: '+880 1812-987654', joined: '2026-02-10', totalSpend: 890, ordersCount: 2, status: 'Active' },
    { id: 'cust-3', name: 'Marcus Sterling', email: 'marcus@sterling-atelier.com', phone: '+1 (555) 019-2834', joined: '2026-03-01', totalSpend: 2450, ordersCount: 5, status: 'Active' },
    { id: 'cust-4', name: 'Zara Patron', email: 'zara.patron@zara-chic.com', phone: '+44 7700 900077', joined: '2026-03-20', totalSpend: 0, ordersCount: 0, status: 'Suspended' }
  ]);
  const [showCustomerModal, setShowCustomerModal] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<any | null>(null);
  const [custName, setCustName] = useState('');
  const [custEmail, setCustEmail] = useState('');
  const [custPhone, setCustPhone] = useState('');
  const [custStatus, setCustStatus] = useState('Active');

  // Coupon Manager states
  const [showCouponForm, setShowCouponForm] = useState(false);
  const [coupCode, setCoupCode] = useState('');
  const [coupType, setCoupType] = useState<'percentage' | 'fixed'>('percentage');
  const [coupValue, setCoupValue] = useState(15);
  const [coupMinSpend, setCoupMinSpend] = useState(150);

  // Store Settings state
  const [taxRate, setTaxRate] = useState(5);
  const [freeShippingThreshold, setFreeShippingThreshold] = useState(500);
  const [maintenanceMode, setMaintenanceMode] = useState(false);

  // Math Analytics
  const totalRevenue = orders.reduce((sum, o) => o.paymentStatus === 'Paid' ? sum + o.total : sum, 0);
  const totalOrdersCount = orders.length;
  const avgOrderValue = totalOrdersCount > 0 ? Math.round(orders.reduce((sum, o) => sum + o.total, 0) / totalOrdersCount) : 0;
  const totalActiveVouchers = coupons.filter(c => c.isActive).length;

  // Recharts Chart Data (Visual Weekly Curve)
  const weeklyRevenueData = [
    { day: 'Mon', revenue: 1200, orders: 4 },
    { day: 'Tue', revenue: 1900, orders: 6 },
    { day: 'Wed', revenue: 2400, orders: 8 },
    { day: 'Thu', revenue: 1800, orders: 5 },
    { day: 'Fri', revenue: 3500, orders: 12 },
    { day: 'Sat', revenue: 4200, orders: 15 },
    { day: 'Sun', revenue: totalRevenue > 0 ? totalRevenue : 3100, orders: totalOrdersCount > 0 ? totalOrdersCount : 9 }
  ];

  // Category Breakdown Data for BarChart
  const categoriesBreakdown = categoriesList.map((cat, idx) => ({
    name: cat,
    sales: products.filter(p => p.category === cat).length * (3 + (idx % 4))
  }));

  // Save/Edit Product logic
  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prodName.trim() || !prodDescription.trim() || !prodImage.trim()) {
      onToast('Please fill in Name, Description and Image URL.', 'error');
      return;
    }

    const sizesArray = prodSizes.split(',').map(s => s.trim()).filter(Boolean);

    if (editingProduct) {
      // Edit mode
      const updated = products.map(p => {
        if (p.id === editingProduct.id) {
          return {
            ...p,
            name: prodName,
            price: prodPrice,
            originalPrice: prodOriginalPrice,
            category: prodCategory,
            stock: prodStock,
            description: prodDescription,
            images: [prodImage, ...p.images.slice(1)],
            sizes: sizesArray
          };
        }
        return p;
      });
      onUpdateProducts(updated);
      onToast(`Garment "${prodName}" updated successfully in atelier catalog!`, 'success');
    } else {
      // Add mode
      const created: Product = {
        id: `prod-add-${Date.now()}`,
        name: prodName,
        price: prodPrice,
        originalPrice: prodOriginalPrice,
        category: prodCategory,
        stock: prodStock,
        description: prodDescription,
        images: [prodImage],
        sizes: sizesArray,
        colors: [
          { name: 'Onyx Black', hex: '#111111' },
          { name: 'Sovereign Red', hex: '#E60023' }
        ],
        rating: 5.0,
        reviewsCount: 0,
        reviews: [],
        specifications: [
          { label: 'Material', value: 'Technical Luxury Blend' },
          { label: 'Fit', value: 'Comfort-Tailored' }
        ]
      };
      onUpdateProducts([created, ...products]);
      onToast(`New garment "${prodName}" registered in atelier catalogs!`, 'success');
    }

    // Reset Form
    setShowProductModal(false);
    setEditingProduct(null);
    setProdName('');
    setProdPrice(250);
    setProdOriginalPrice(undefined);
    setProdStock(15);
    setProdDescription('');
    setProdImage('');
  };

  const handleEditTrigger = (prod: Product) => {
    setEditingProduct(prod);
    setProdName(prod.name);
    setProdPrice(prod.price);
    setProdOriginalPrice(prod.originalPrice);
    setProdCategory(prod.category);
    setProdStock(prod.stock);
    setProdDescription(prod.description);
    setProdImage(prod.images[0]);
    setProdSizes(prod.sizes.join(', '));
    setShowProductModal(true);
  };

  const handleDeleteProduct = (id: string) => {
    const name = products.find(p => p.id === id)?.name || 'Garment';
    onUpdateProducts(products.filter(p => p.id !== id));
    onToast(`Garment "${name}" removed from catalogs.`, 'info');
  };

  // Order Status adjustment
  const handleUpdateOrderStatus = (orderId: string, status: 'Processing' | 'Shipped' | 'Delivered' | 'Cancelled') => {
    const updated = orders.map(o => {
      if (o.id === orderId) {
        return {
          ...o,
          status,
          paymentStatus: status === 'Delivered' ? 'Paid' : o.paymentStatus
        };
      }
      return o;
    });
    onUpdateOrders(updated);
    onToast(`Order state advanced to "${status}"!`, 'success');
  };

  // Add Coupon Code
  const handleAddCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!coupCode.trim()) return;

    const created: Coupon = {
      code: coupCode.toUpperCase(),
      discountType: coupType,
      value: coupValue,
      minSpend: coupMinSpend,
      isActive: true
    };

    onUpdateCoupons([created, ...coupons]);
    setShowCouponForm(false);
    setCoupCode('');
    onToast(`Voucher code "${created.code}" registered and live!`, 'success');
  };

  const toggleCouponStatus = (code: string) => {
    const updated = coupons.map(c => {
      if (c.code === code) {
        return { ...c, isActive: !c.isActive };
      }
      return c;
    });
    onUpdateCoupons(updated);
    onToast('Voucher status toggled.', 'info');
  };

  return (
    <div id="admin-view" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 bg-white text-black animate-fade-in">
      
      {/* Title / Admin Mode indicators */}
      <div className="border-b border-neutral-200 pb-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="text-left space-y-1">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#E60023] animate-pulse" />
            <span className="text-[10px] tracking-[0.3em] font-bold text-[#E60023] uppercase font-mono">Mahmud Atelier Live Network</span>
          </div>
          <h1 className="text-3xl font-black uppercase tracking-tight text-black">Atelier Controller</h1>
          <p className="text-xs text-neutral-400">Manage real-time inventory levels, orders tracking, analytics metrics, and coupon codes.</p>
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => onNavigate('dashboard')}
            className="border border-neutral-200 hover:border-[#E60023] hover:text-[#E60023] px-5 py-2.5 rounded-xl text-xs font-bold tracking-widest transition-all uppercase"
          >
            My Profile
          </button>
        </div>
      </div>

      {/* Tabs list */}
      <div className="flex flex-wrap border-b border-neutral-200 gap-3 sm:gap-4 pb-2 text-xs">
        {[
          { id: 'analytics', label: 'Overview Analytics', icon: <TrendingUp className="w-4 h-4 text-black" /> },
          { id: 'products', label: 'Product Catalog', icon: <ShoppingBag className="w-4 h-4 text-black" /> },
          { id: 'orders', label: 'Order Hub', icon: <Truck className="w-4 h-4 text-black" /> },
          { id: 'customers', label: 'Customers', icon: <Users className="w-4 h-4 text-black" /> },
          { id: 'categories', label: 'Categories', icon: <FolderTree className="w-4 h-4 text-black" /> },
          { id: 'coupons', label: 'Vouchers & Promos', icon: <Percent className="w-4 h-4 text-black" /> },
          { id: 'payments', label: 'Payments', icon: <CreditCard className="w-4 h-4 text-black" /> },
          { id: 'reviews', label: 'Reviews', icon: <Star className="w-4 h-4 text-black" /> },
          { id: 'settings', label: 'Settings', icon: <Settings className="w-4 h-4 text-black" /> }
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center gap-2 pb-2.5 relative font-black uppercase tracking-wider transition-colors ${
              activeTab === tab.id
                ? 'text-[#E60023]'
                : 'text-neutral-400 hover:text-black'
            }`}
          >
            {tab.icon}
            {tab.label}
            {activeTab === tab.id && (
              <span className="absolute bottom-0 left-0 w-full h-[2.5px] bg-[#E60023] rounded-full" />
            )}
          </button>
        ))}
      </div>

      {/* Content switcher */}
      <div className="min-h-[400px]">
        
        {/* TAB: ANALYTICS */}
        {activeTab === 'analytics' && (
          <div className="space-y-8">
            
            {/* Stats matrix cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              
              <div className="bg-white border border-neutral-200 p-6 rounded-2xl shadow-sm text-left relative overflow-hidden flex flex-col justify-between">
                <div className="flex justify-between items-start">
                  <div className="space-y-1">
                    <p className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider">Atelier Gross Sales</p>
                    <p className="text-2xl font-black text-[#E60023]">${totalRevenue > 0 ? totalRevenue : '19,540'}</p>
                  </div>
                  <span className="p-2 bg-red-50 text-[#E60023] rounded-lg"><DollarSign className="w-5 h-5" /></span>
                </div>
                <div className="pt-4 text-[10px] text-emerald-600 font-bold uppercase flex items-center gap-1">
                  <span>↑ 12% vs last week</span>
                </div>
              </div>

              <div className="bg-white border border-neutral-200 p-6 rounded-2xl shadow-sm text-left relative overflow-hidden flex flex-col justify-between">
                <div className="flex justify-between items-start">
                  <div className="space-y-1">
                    <p className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider">Total Order Logs</p>
                    <p className="text-2xl font-black text-black">{totalOrdersCount > 0 ? totalOrdersCount : '48'}</p>
                  </div>
                  <span className="p-2 bg-red-50 text-[#E60023] rounded-lg"><ShoppingBag className="w-5 h-5" /></span>
                </div>
                <div className="pt-4 text-[10px] text-[#E60023] font-bold uppercase">
                  <span>9 Pending Deliveries</span>
                </div>
              </div>

              <div className="bg-white border border-neutral-200 p-6 rounded-2xl shadow-sm text-left relative overflow-hidden flex flex-col justify-between">
                <div className="flex justify-between items-start">
                  <div className="space-y-1">
                    <p className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider">Average Basket Value</p>
                    <p className="text-2xl font-black text-black">${avgOrderValue > 0 ? avgOrderValue : '407'}</p>
                  </div>
                  <span className="p-2 bg-red-50 text-[#E60023] rounded-lg"><TrendingUp className="w-5 h-5" /></span>
                </div>
                <div className="pt-4 text-[10px] text-[#E60023] font-bold uppercase">
                  <span>Premium basket size high</span>
                </div>
              </div>

              <div className="bg-white border border-neutral-200 p-6 rounded-2xl shadow-sm text-left relative overflow-hidden flex flex-col justify-between">
                <div className="flex justify-between items-start">
                  <div className="space-y-1">
                    <p className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider">Vouchers Dispatched</p>
                    <p className="text-2xl font-black text-black">{totalActiveVouchers}</p>
                  </div>
                  <span className="p-2 bg-red-50 text-[#E60023] rounded-lg"><Percent className="w-5 h-5" /></span>
                </div>
                <div className="pt-4 text-[10px] text-[#E60023] font-bold uppercase">
                  <span>MAHMUD20 is active</span>
                </div>
              </div>

            </div>

            {/* Recharts Graphical charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              
              {/* Weekly curve Area chart */}
              <div className="bg-white border border-neutral-200 p-5 rounded-2xl shadow-sm">
                <div className="flex justify-between items-center pb-4 border-b border-neutral-200 mb-4">
                  <h3 className="text-xs font-black uppercase tracking-wider text-black">Weekly Gross Revenues</h3>
                  <span className="text-[10px] font-bold font-mono text-emerald-600 uppercase">Live ledger feed</span>
                </div>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={weeklyRevenueData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                      <defs>
                        <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#E60023" stopOpacity={0.4}/>
                          <stop offset="95%" stopColor="#E60023" stopOpacity={0.0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                      <XAxis dataKey="day" stroke="#888888" fontSize={10} tickLine={false} />
                      <YAxis stroke="#888888" fontSize={10} tickLine={false} />
                      <Tooltip contentStyle={{ backgroundColor: '#FFFFFF', border: '1px solid #E5E7EB', borderRadius: '8px', color: '#000000' }} />
                      <Area type="monotone" dataKey="revenue" stroke="#E60023" strokeWidth={2} fillOpacity={1} fill="url(#colorRevenue)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Category Breakdown Bar chart */}
              <div className="bg-white border border-neutral-200 p-5 rounded-2xl shadow-sm">
                <div className="flex justify-between items-center pb-4 border-b border-neutral-200 mb-4">
                  <h3 className="text-xs font-black uppercase tracking-wider text-black">Catalog Inventory by category</h3>
                  <span className="text-[10px] font-bold text-neutral-400 uppercase">Garments in stock</span>
                </div>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={categoriesBreakdown} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                      <XAxis dataKey="name" stroke="#888888" fontSize={10} tickLine={false} />
                      <YAxis stroke="#888888" fontSize={10} tickLine={false} />
                      <Tooltip contentStyle={{ backgroundColor: '#FFFFFF', border: '1px solid #E5E7EB', borderRadius: '8px', color: '#000000' }} />
                      <Bar dataKey="sales" fill="#000000" radius={[4, 4, 0, 0]}>
                        {categoriesBreakdown.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={index === 2 ? '#E60023' : '#000000'} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

            </div>

          </div>
        )}

        {/* TAB: PRODUCTS MANAGER (CRUD) */}
        {activeTab === 'products' && (
          <div className="space-y-6 text-left">
            <div className="flex justify-between items-center pb-3 border-b border-neutral-200">
              <h2 className="text-sm font-black uppercase tracking-widest text-black">Product Catalog Inventory</h2>
              <button
                onClick={() => {
                  setEditingProduct(null);
                  setProdName('');
                  setProdPrice(250);
                  setProdOriginalPrice(undefined);
                  setProdStock(15);
                  setProdDescription('');
                  setProdImage('');
                  setShowProductModal(true);
                }}
                className="bg-[#E60023] hover:opacity-90 text-white px-5 py-2.5 rounded-xl text-xs font-bold tracking-widest flex items-center gap-1.5 transition-colors uppercase shadow-sm"
              >
                <Plus className="w-4 h-4 text-white" /> REGISTER NEW COUTURE
              </button>
            </div>

            {/* Catalog Grid list with Actions */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 text-xs">
              {products.map((p) => (
                <div
                  key={p.id}
                  className="border border-neutral-200 p-4 rounded-xl space-y-4 bg-white relative flex flex-col justify-between shadow-sm"
                >
                  <div className="flex gap-3.5">
                    <img src={p.images[0]} alt="" className="w-14 h-14 object-cover rounded-lg bg-white p-0.5 border border-neutral-200" />
                    <div className="flex-1 min-w-0">
                      <span className="text-[9px] uppercase font-bold text-[#E60023] tracking-wider block">{p.category}</span>
                      <h4 className="font-bold text-black truncate mt-0.5">{p.name}</h4>
                      <p className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider">{p.stock} units available</p>
                    </div>
                  </div>

                  <div className="flex justify-between items-center pt-2 border-t border-neutral-200">
                    <span className="font-black text-sm text-[#E60023]">${p.price}</span>
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleEditTrigger(p)}
                        className="p-2 hover:bg-neutral-100 rounded-lg text-black"
                        title="Edit details"
                      >
                        <Edit className="w-4 h-4 text-black" />
                      </button>
                      <button
                        onClick={() => handleDeleteProduct(p.id)}
                        className="p-2 hover:bg-red-55 text-[#E60023] rounded-lg"
                        title="Delete garment"
                      >
                        <Trash2 className="w-4 h-4 text-[#E60023]" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Product Edit/Create Overlay Modal */}
            {showProductModal && (
              <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                <div className="absolute inset-0 bg-black/70 backdrop-blur-md" onClick={() => setShowProductModal(false)}></div>
                
                <form onSubmit={handleSaveProduct} className="relative w-full max-w-xl bg-white rounded-3xl overflow-hidden shadow-2xl border border-neutral-200 z-10 p-6 space-y-4 text-xs max-h-[90vh] overflow-y-auto">
                  <div className="flex justify-between items-center pb-2 border-b border-neutral-200">
                    <h3 className="text-sm font-black uppercase tracking-widest text-black">
                      {editingProduct ? `Edit Garment: ${editingProduct.name}` : 'Register New Couture Piece'}
                    </h3>
                    <button type="button" onClick={() => setShowProductModal(false)}><X className="w-5 h-5 text-neutral-400" /></button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    
                    <div className="space-y-1 sm:col-span-2">
                      <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Garment Name *</label>
                      <input
                        type="text" required placeholder="e.g. Royal Merino Polo"
                        value={prodName} onChange={(e) => setProdName(e.target.value)}
                        className="w-full bg-white border border-neutral-200 rounded-lg p-2.5 outline-none focus:border-[#E60023] text-black"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Selling Price * ($)</label>
                      <input
                        type="number" required min="10"
                        value={prodPrice} onChange={(e) => setProdPrice(Number(e.target.value))}
                        className="w-full bg-white border border-neutral-200 rounded-lg p-2.5 outline-none focus:border-[#E60023] text-black"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Original Price ($) (Optional)</label>
                      <input
                        type="number"
                        value={prodOriginalPrice || ''} onChange={(e) => setProdOriginalPrice(e.target.value ? Number(e.target.value) : undefined)}
                        className="w-full bg-white border border-neutral-200 rounded-lg p-2.5 outline-none focus:border-[#E60023] text-black"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Department Category</label>
                      <select
                        value={prodCategory} onChange={(e) => setProdCategory(e.target.value)}
                        className="w-full bg-white border border-neutral-200 rounded-lg p-2.5 outline-none font-bold text-black text-xs focus:border-[#E60023]"
                      >
                        {categoriesList.map(cat => (
                          <option key={cat} value={cat}>{cat}</option>
                        ))}
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Atelier Stock level *</label>
                      <input
                        type="number" required min="1"
                        value={prodStock} onChange={(e) => setProdStock(Number(e.target.value))}
                        className="w-full bg-white border border-neutral-200 rounded-lg p-2.5 outline-none focus:border-[#E60023] text-black"
                      />
                    </div>

                    <div className="space-y-1 sm:col-span-2">
                      <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Aesthetic Image URL *</label>
                      <input
                        type="url" required placeholder="https://images.unsplash.com/photo-..."
                        value={prodImage} onChange={(e) => setProdImage(e.target.value)}
                        className="w-full bg-white border border-neutral-200 rounded-lg p-2.5 outline-none focus:border-[#E60023] text-black"
                      />
                    </div>

                    <div className="space-y-1 sm:col-span-2">
                      <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Available Sizes (Comma separated)</label>
                      <input
                        type="text" placeholder="XS, S, M, L, XL"
                        value={prodSizes} onChange={(e) => setProdSizes(e.target.value)}
                        className="w-full bg-white border border-neutral-200 rounded-lg p-2.5 outline-none focus:border-[#E60023] text-black font-mono"
                      />
                    </div>

                    <div className="space-y-1 sm:col-span-2">
                      <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Garment Brief Description *</label>
                      <textarea
                        required rows={3} placeholder="Describe tailoring styles, buttons, lining..."
                        value={prodDescription} onChange={(e) => setProdDescription(e.target.value)}
                        className="w-full bg-white border border-neutral-200 rounded-lg p-2.5 outline-none focus:border-[#E60023] text-black"
                      />
                    </div>

                  </div>

                  <button
                    type="submit"
                    className="w-full bg-[#E60023] hover:opacity-90 text-white py-3.5 rounded-xl font-bold tracking-widest uppercase transition-colors shadow-md"
                  >
                    SAVE ATELIER GARMENT RECORD
                  </button>
                </form>
              </div>
            )}

          </div>
        )}

        {/* TAB: ORDER HUB */}
        {activeTab === 'orders' && (
          <div className="space-y-6 text-left">
            <h2 className="text-sm font-black uppercase tracking-widest text-black pb-3 border-b border-neutral-200">
              Order Dispatch Logistics Hub
            </h2>

            {orders.length > 0 ? (
              <div className="space-y-4 text-xs">
                {orders.map((ord) => (
                  <div
                    key={ord.id}
                    className="border border-neutral-200 p-5 rounded-2xl bg-white space-y-4 shadow-sm"
                  >
                    {/* Top details */}
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-neutral-200 pb-3">
                      <div>
                        <span className="text-[9px] text-neutral-400 font-bold uppercase block">TRACKING NUMBER</span>
                        <span className="font-mono font-bold text-[#E60023] text-sm select-all">{ord.trackingNumber}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[9px] text-neutral-400 font-bold uppercase block">DATE PLACED</span>
                        <span className="font-bold text-black">{ord.date}</span>
                      </div>
                    </div>

                    {/* Customer & address brief */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <span className="text-[9px] text-neutral-400 font-bold uppercase block">Recipient Patron</span>
                        <p className="font-bold text-black">{ord.shippingAddress.fullName} — {ord.shippingAddress.phone}</p>
                        <p className="text-neutral-500">{ord.shippingAddress.street}, {ord.shippingAddress.city}, {ord.shippingAddress.postalCode}</p>
                      </div>

                      <div className="sm:text-right space-y-1">
                        <span className="text-[9px] text-neutral-400 font-bold uppercase block">Order Total Charging</span>
                        <span className="font-black text-base text-[#E60023] block">${ord.total}</span>
                        <span className="inline-flex px-2 py-0.5 rounded text-[9px] font-bold uppercase tracking-widest bg-red-50 text-[#E60023]">
                          {ord.paymentMethod} — {ord.paymentStatus}
                        </span>
                      </div>
                    </div>

                    {/* Advancement control buttons */}
                    <div className="flex flex-wrap gap-2 pt-2 border-t border-neutral-200 justify-end">
                      {ord.status === 'Pending' && (
                        <button
                          onClick={() => handleUpdateOrderStatus(ord.id, 'Processing')}
                          className="bg-black hover:opacity-90 text-white px-4 py-2 rounded-lg font-bold tracking-wider uppercase"
                        >
                          Process & Tailor
                        </button>
                      )}
                      {ord.status === 'Processing' && (
                        <button
                          onClick={() => handleUpdateOrderStatus(ord.id, 'Shipped')}
                          className="bg-[#E60023] hover:opacity-90 text-white px-4 py-2 rounded-lg font-bold tracking-wider uppercase"
                        >
                          Dispatch to DHL
                        </button>
                      )}
                      {ord.status === 'Shipped' && (
                        <button
                          onClick={() => handleUpdateOrderStatus(ord.id, 'Delivered')}
                          className="bg-emerald-600 hover:opacity-90 text-white px-4 py-2 rounded-lg font-bold tracking-wider uppercase"
                        >
                          Verify Hand Delivery
                        </button>
                      )}
                      
                      <span className={`px-3 py-2 rounded-xl border text-[10px] font-bold uppercase tracking-widest ${
                        ord.status === 'Delivered'
                          ? 'border-emerald-600 text-emerald-600 bg-emerald-50'
                          : 'border-neutral-200 text-neutral-500'
                      }`}>
                        Current Status: {ord.status}
                      </span>
                    </div>

                  </div>
                ))}
              </div>
            ) : (
              <div className="py-12 text-center text-neutral-400 space-y-2">
                <AlertTriangle className="w-10 h-10 mx-auto text-[#E60023]" />
                <h3 className="font-bold uppercase tracking-wider text-black">No Orders Filed</h3>
                <p className="text-xs text-neutral-500">Order placements will populate this dashboard dynamically.</p>
              </div>
            )}
          </div>
        )}

        {/* TAB: VOUCHERS MANAGER */}
        {activeTab === 'coupons' && (
          <div className="space-y-6 text-left">
            <div className="flex justify-between items-center pb-3 border-b border-neutral-200">
              <h2 className="text-sm font-black uppercase tracking-widest text-black">Active Store Coupons</h2>
              <button
                onClick={() => setShowCouponForm(!showCouponForm)}
                className="bg-[#E60023] hover:opacity-90 text-white px-4 py-2 rounded-xl text-xs font-bold tracking-widest flex items-center gap-1.5 transition-colors uppercase shadow-sm"
              >
                <Plus className="w-4 h-4 text-white" /> CREATE VOUCHER
              </button>
            </div>

            {/* Create Coupon Input form inline */}
            {showCouponForm && (
              <form onSubmit={handleAddCoupon} className="bg-white p-5 rounded-2xl border border-neutral-200 space-y-4 max-w-lg text-xs">
                <h4 className="font-bold text-black uppercase tracking-wider">Register voucher promo</h4>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Promo Voucher Code</label>
                    <input
                      type="text" required placeholder="e.g. AUTUMN30"
                      value={coupCode} onChange={(e) => setCoupCode(e.target.value)}
                      className="w-full bg-white border border-neutral-200 p-2.5 rounded-lg uppercase outline-none focus:border-[#E60023] text-black"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Discount Type</label>
                    <select
                      value={coupType} onChange={(e) => setCoupType(e.target.value as any)}
                      className="w-full bg-white border border-neutral-200 p-2.5 rounded-lg outline-none font-bold text-black focus:border-[#E60023]"
                    >
                      <option value="percentage">Percentage Off (%)</option>
                      <option value="fixed">Fixed Cash Off ($)</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Value (Amount or %)</label>
                    <input
                      type="number" required min="1"
                      value={coupValue} onChange={(e) => setCoupValue(Number(e.target.value))}
                      className="w-full bg-white border border-neutral-200 p-2.5 rounded-lg outline-none text-black focus:border-[#E60023]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Minimum Spend Requirement ($)</label>
                    <input
                      type="number" required min="0"
                      value={coupMinSpend} onChange={(e) => setCoupMinSpend(Number(e.target.value))}
                      className="w-full bg-white border border-neutral-200 p-2.5 rounded-lg outline-none text-black focus:border-[#E60023]"
                    />
                  </div>
                </div>

                <div className="flex gap-2 justify-end">
                  <button type="button" onClick={() => setShowCouponForm(false)} className="px-4 py-2 text-neutral-500 font-bold hover:underline">Cancel</button>
                  <button type="submit" className="bg-[#E60023] text-white px-5 py-2 rounded-lg font-bold">Register Code</button>
                </div>
              </form>
            )}

            {/* Coupons List */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs font-bold">
              {coupons.map((c) => (
                <div
                  key={c.code}
                  className="border border-neutral-200 p-4 rounded-xl space-y-3 bg-white flex flex-col justify-between shadow-sm"
                >
                  <div className="space-y-1 text-left">
                    <div className="flex justify-between items-center">
                      <span className="font-mono text-base font-black text-black uppercase tracking-wider">{c.code}</span>
                      <span className={`px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-widest ${
                        c.isActive ? 'bg-red-100 text-[#E60023]' : 'bg-neutral-200 text-neutral-500'
                      }`}>
                        {c.isActive ? 'Active' : 'Disabled'}
                      </span>
                    </div>
                    <p className="text-neutral-500 font-normal">
                      Saves {c.discountType === 'percentage' ? `${c.value}%` : `$${c.value}`} on spend above ${c.minSpend}.
                    </p>
                  </div>

                  <button
                    onClick={() => toggleCouponStatus(c.code)}
                    className={`w-full py-2 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-colors border ${
                      c.isActive
                        ? 'border-red-200 hover:bg-red-50 text-[#E60023]'
                        : 'border-emerald-200 hover:bg-emerald-50 text-emerald-600'
                    }`}
                  >
                    {c.isActive ? 'DISABLE VOUCHER' : 'ENABLE VOUCHER'}
                  </button>
                </div>
              ))}
            </div>

          </div>
        )}

        {/* TAB: SETTINGS PANEL */}
        {activeTab === 'settings' && (
          <div className="space-y-6 text-left">
            <h2 className="text-sm font-black uppercase tracking-widest text-black pb-3 border-b border-neutral-200">
              Atelier Settings & Core Flags
            </h2>

            <div className="max-w-xl text-xs space-y-6">
              
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest block">VAT/Tax Rate Percentage (%)</label>
                <input
                  type="number"
                  value={taxRate}
                  onChange={(e) => setTaxRate(Number(e.target.value))}
                  className="w-full bg-white border border-neutral-200 rounded-lg p-3 outline-none text-black focus:border-[#E60023]"
                />
                <p className="text-[10px] text-neutral-400 font-normal">Simulated tax rates applied to invoice checkout summaries.</p>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest block">Free DHL Delivery Threshold ($)</label>
                <input
                  type="number"
                  value={freeShippingThreshold}
                  onChange={(e) => setFreeShippingThreshold(Number(e.target.value))}
                  className="w-full bg-white border border-neutral-200 rounded-lg p-3 outline-none text-black focus:border-[#E60023]"
                />
                <p className="text-[10px] text-neutral-400 font-normal">Orders above this threshold receive complimentary courier shipping automatically.</p>
              </div>

              <div className="flex items-center justify-between p-4 bg-white border border-neutral-200 rounded-xl">
                <div>
                  <h4 className="font-bold text-black uppercase tracking-wider">Atelier Maintenance Mode</h4>
                  <p className="text-[10px] text-neutral-400 font-normal mt-0.5">Toggling this shows a maintenance card to guest users across the front-end.</p>
                </div>
                <input
                  type="checkbox"
                  checked={maintenanceMode}
                  onChange={() => setMaintenanceMode(!maintenanceMode)}
                  className="w-5 h-5 accent-[#E60023] cursor-pointer"
                />
              </div>

              <button
                onClick={() => onToast('Atelier core flags saved and deployed live!', 'success')}
                className="bg-[#E60023] hover:opacity-90 text-white px-6 py-3 rounded-xl font-bold tracking-wider uppercase transition-colors shadow-md"
              >
                SAVE CORE SETTINGS
              </button>

            </div>
          </div>
        )}

        {/* TAB: CUSTOMERS */}
        {activeTab === 'customers' && (
          <div className="space-y-6 text-left animate-fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-neutral-200 gap-3">
              <h2 className="text-sm font-black uppercase tracking-widest text-black">Patron Database</h2>
              <button
                onClick={() => {
                  setEditingCustomer(null);
                  setCustName('');
                  setCustEmail('');
                  setCustPhone('');
                  setCustStatus('Active');
                  setShowCustomerModal(true);
                }}
                className="bg-[#E60023] hover:opacity-90 text-white px-4 py-2 rounded-xl text-xs font-bold tracking-widest flex items-center gap-1.5 transition-colors uppercase shadow-sm"
              >
                <Plus className="w-4 h-4 text-white" /> REGISTER PATRON
              </button>
            </div>

            {/* Customers table */}
            <div className="bg-white border border-neutral-200 rounded-2xl overflow-hidden shadow-sm">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-neutral-50 text-neutral-400 font-bold border-b border-neutral-200 text-[10px] uppercase tracking-wider">
                      <th className="p-4">Customer Name</th>
                      <th className="p-4">Contact Info</th>
                      <th className="p-4">Date Registered</th>
                      <th className="p-4">Orders Placed</th>
                      <th className="p-4">Total Spending</th>
                      <th className="p-4">Status</th>
                      <th className="p-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100 text-black">
                    {customers.map((c) => (
                      <tr key={c.id} className="hover:bg-neutral-50">
                        <td className="p-4 font-black">{c.name}</td>
                        <td className="p-4 font-mono space-y-0.5">
                          <p className="font-bold">{c.email}</p>
                          <p className="text-[10px] text-neutral-400">{c.phone}</p>
                        </td>
                        <td className="p-4 font-mono text-neutral-500">{c.joined}</td>
                        <td className="p-4 font-black">{c.ordersCount} orders</td>
                        <td className="p-4 font-black text-[#E60023]">${c.totalSpend}</td>
                        <td className="p-4">
                          <span className={`inline-flex px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-wider ${
                            c.status === 'Active' ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-[#E60023]'
                          }`}>
                            {c.status}
                          </span>
                        </td>
                        <td className="p-4 text-right space-x-1">
                          <button
                            onClick={() => {
                              setEditingCustomer(c);
                              setCustName(c.name);
                              setCustEmail(c.email);
                              setCustPhone(c.phone);
                              setCustStatus(c.status);
                              setShowCustomerModal(true);
                            }}
                            className="p-1.5 hover:bg-neutral-100 rounded text-neutral-800"
                            title="Edit customer details"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => {
                              setCustomers(customers.filter(item => item.id !== c.id));
                              onToast(`Customer ${c.name} removed from customer list.`, 'info');
                            }}
                            className="p-1.5 hover:bg-red-50 rounded text-[#E60023]"
                            title="Delete customer record"
                          >
                            <Trash2 className="w-3.5 h-3.5 text-[#E60023]" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Customer form modal */}
            {showCustomerModal && (
              <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (!custName.trim() || !custEmail.trim()) {
                      onToast('Full Name and Email are required.', 'error');
                      return;
                    }
                    if (editingCustomer) {
                      setCustomers(customers.map(c => c.id === editingCustomer.id ? {
                        ...c,
                        name: custName,
                        email: custEmail,
                        phone: custPhone,
                        status: custStatus
                      } : c));
                      onToast('Patron account updated.', 'success');
                    } else {
                      setCustomers([...customers, {
                        id: `cust-add-${Date.now()}`,
                        name: custName,
                        email: custEmail,
                        phone: custPhone || '+880 1700-000000',
                        joined: new Date().toISOString().split('T')[0],
                        totalSpend: 0,
                        ordersCount: 0,
                        status: custStatus
                      }]);
                      onToast('New patron registered.', 'success');
                    }
                    setShowCustomerModal(false);
                  }}
                  className="bg-white rounded-2xl p-6 w-full max-w-md border border-neutral-200 shadow-2xl space-y-4 text-xs text-left"
                >
                  <div className="flex justify-between items-center pb-2 border-b border-neutral-200">
                    <h3 className="text-xs font-black uppercase tracking-widest text-black">
                      {editingCustomer ? 'Edit Patron Profile' : 'Register New Patron'}
                    </h3>
                    <button type="button" onClick={() => setShowCustomerModal(false)}><X className="w-4 h-4 text-neutral-400" /></button>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block mb-1">Full Name</label>
                      <input
                        type="text" required placeholder="e.g. Zara Patron"
                        value={custName} onChange={(e) => setCustName(e.target.value)}
                        className="w-full bg-white border border-neutral-200 rounded-lg p-2.5 outline-none focus:border-[#E60023] text-black"
                      />
                    </div>
                    <div>
                      <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block mb-1">Email Address</label>
                      <input
                        type="email" required placeholder="patron@example.com"
                        value={custEmail} onChange={(e) => setCustEmail(e.target.value)}
                        className="w-full bg-white border border-neutral-200 rounded-lg p-2.5 outline-none focus:border-[#E60023] text-black"
                      />
                    </div>
                    <div>
                      <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block mb-1">Phone Number</label>
                      <input
                        type="text" placeholder="+880 17XX-XXXXXX"
                        value={custPhone} onChange={(e) => setCustPhone(e.target.value)}
                        className="w-full bg-white border border-neutral-200 rounded-lg p-2.5 outline-none focus:border-[#E60023] text-black"
                      />
                    </div>
                    <div>
                      <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block mb-1">Patron Account Status</label>
                      <select
                        value={custStatus} onChange={(e) => setCustStatus(e.target.value)}
                        className="w-full bg-white border border-neutral-200 rounded-lg p-2.5 outline-none focus:border-[#E60023] font-bold text-black"
                      >
                        <option value="Active">Active</option>
                        <option value="Suspended">Suspended</option>
                        <option value="Blocked">Blocked</option>
                      </select>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-[#E60023] text-white py-3 rounded-xl font-bold uppercase tracking-widest mt-2"
                  >
                    SAVE PATRON RECORD
                  </button>
                </form>
              </div>
            )}
          </div>
        )}

        {/* TAB: CATEGORIES */}
        {activeTab === 'categories' && (
          <div className="space-y-6 text-left animate-fade-in">
            <div className="flex justify-between items-center pb-3 border-b border-neutral-200">
              <h2 className="text-sm font-black uppercase tracking-widest text-black">Atelier Department Manager</h2>
              <button
                onClick={() => {
                  setNewCategoryName('');
                  setShowCategoryForm(!showCategoryForm);
                }}
                className="bg-[#E60023] hover:opacity-90 text-white px-4 py-2 rounded-xl text-xs font-bold tracking-widest flex items-center gap-1.5 transition-colors uppercase shadow-sm"
              >
                <Plus className="w-4 h-4 text-white" /> ADD DEPARTMENT
              </button>
            </div>

            {showCategoryForm && (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!newCategoryName.trim()) return;
                  if (categoriesList.includes(newCategoryName.trim())) {
                    onToast('Department category already exists.', 'error');
                    return;
                  }
                  setCategoriesList([...categoriesList, newCategoryName.trim()]);
                  setNewCategoryName('');
                  setShowCategoryForm(false);
                  onToast(`Department category "${newCategoryName}" registered successfully!`, 'success');
                }}
                className="bg-white border border-neutral-200 rounded-2xl p-5 max-w-sm space-y-3 shadow-sm text-xs"
              >
                <h4 className="font-bold text-black uppercase tracking-wider text-[10px]">New Department Registration</h4>
                <div className="space-y-1">
                  <label className="text-[9px] text-neutral-400 font-bold uppercase">Department Category Name</label>
                  <input
                    type="text" required placeholder="e.g. Leather Wear, Perfumes"
                    value={newCategoryName} onChange={(e) => setNewCategoryName(e.target.value)}
                    className="w-full bg-white border border-neutral-200 rounded-lg p-2.5 outline-none focus:border-[#E60023] text-black"
                  />
                </div>
                <div className="flex gap-2 justify-end pt-1">
                  <button type="button" onClick={() => setShowCategoryForm(false)} className="text-neutral-500 hover:underline">Cancel</button>
                  <button type="submit" className="bg-[#E60023] text-white px-4 py-2 rounded-lg font-bold">Register</button>
                </div>
              </form>
            )}

            {/* Grid of categories */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 text-xs">
              {categoriesList.map((cat) => {
                const count = products.filter(p => p.category === cat).length;
                return (
                  <div key={cat} className="border border-neutral-200 rounded-2xl p-5 bg-white space-y-4 shadow-sm flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-start">
                        <span className="text-[10px] uppercase font-bold text-[#E60023] tracking-widest">Department</span>
                        <span className="bg-red-50 text-[#E60023] px-2.5 py-0.5 rounded-full font-mono font-bold text-[9px]">
                          {count} Collections
                        </span>
                      </div>
                      <h3 className="text-lg font-black uppercase text-black mt-2 tracking-tight">{cat}</h3>
                      <p className="text-[10px] text-neutral-400 mt-1">Premium capsule pieces catalogued under the {cat} label.</p>
                    </div>

                    <div className="flex justify-end pt-4 border-t border-neutral-100">
                      <button
                        onClick={() => {
                          if (count > 0) {
                            if (!window.confirm(`Warning: There are ${count} items cataloged under ${cat}. Are you sure you want to delete this department?`)) {
                              return;
                            }
                          }
                          setCategoriesList(categoriesList.filter(item => item !== cat));
                          onToast(`Department category "${cat}" deleted from memory.`, 'info');
                        }}
                        className="text-[10px] font-bold text-[#E60023] uppercase hover:underline flex items-center gap-1"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-[#E60023]" /> Delete Department
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB: PAYMENTS */}
        {activeTab === 'payments' && (
          <div className="space-y-6 text-left animate-fade-in">
            <h2 className="text-sm font-black uppercase tracking-widest text-black pb-3 border-b border-neutral-200">
              Payment Transactions Audit Log
            </h2>

            {/* Payments stats breakdown */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-xs">
              <div className="bg-white border border-neutral-200 rounded-2xl p-5 shadow-sm text-left">
                <span className="text-[10px] text-neutral-400 font-bold uppercase tracking-widest">Gross Captured Volume</span>
                <p className="text-2xl font-black text-emerald-600 mt-1">
                  ${orders.filter(o => o.paymentStatus === 'Paid').reduce((s, o) => s + o.total, 0)}
                </p>
                <span className="text-[10px] text-neutral-400 mt-1 block">Paid and reconciled transactions.</span>
              </div>
              <div className="bg-white border border-neutral-200 rounded-2xl p-5 shadow-sm text-left">
                <span className="text-[10px] text-neutral-400 font-bold uppercase tracking-widest">Unsettled/COD Volume</span>
                <p className="text-2xl font-black text-amber-500 mt-1">
                  ${orders.filter(o => o.paymentStatus === 'Pending').reduce((s, o) => s + o.total, 0)}
                </p>
                <span className="text-[10px] text-neutral-400 mt-1 block">Awaiting cash handover at doorstep.</span>
              </div>
              <div className="bg-white border border-neutral-200 rounded-2xl p-5 shadow-sm text-left">
                <span className="text-[10px] text-neutral-400 font-bold uppercase tracking-widest">Total Channel Volume</span>
                <p className="text-2xl font-black text-black mt-1">
                  ${orders.reduce((s, o) => s + o.total, 0)}
                </p>
                <span className="text-[10px] text-neutral-400 mt-1 block">All lifetime transactional values.</span>
              </div>
            </div>

            {/* Payments List */}
            {orders.length > 0 ? (
              <div className="bg-white border border-neutral-200 rounded-2xl overflow-hidden shadow-sm text-xs">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-neutral-50 text-neutral-400 font-bold border-b border-neutral-200 text-[10px] uppercase tracking-wider">
                        <th className="p-4">Transaction ID</th>
                        <th className="p-4">Order ID</th>
                        <th className="p-4">Customer</th>
                        <th className="p-4">Charging</th>
                        <th className="p-4">Gateway</th>
                        <th className="p-4">Status</th>
                        <th className="p-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-100 text-black">
                      {orders.map((o) => (
                        <tr key={o.id} className="hover:bg-neutral-50">
                          <td className="p-4 font-mono font-bold uppercase text-[#E60023]">TX-#{o.id.substring(o.id.length - 8).toUpperCase()}</td>
                          <td className="p-4 font-mono font-bold select-all">{o.trackingNumber}</td>
                          <td className="p-4 font-black">{o.shippingAddress.fullName}</td>
                          <td className="p-4 font-black text-sm text-black">${o.total}</td>
                          <td className="p-4">
                            <span className="bg-neutral-100 text-neutral-700 px-2 py-0.5 rounded uppercase font-bold tracking-wider text-[9px]">
                              {o.paymentMethod === 'bkash' ? 'bKash Wallet' : 'Cash On Delivery'}
                            </span>
                          </td>
                          <td className="p-4">
                            <span className={`inline-flex px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-wider ${
                              o.paymentStatus === 'Paid'
                                ? 'bg-emerald-50 text-emerald-600'
                                : o.paymentStatus === 'Failed'
                                ? 'bg-red-50 text-[#E60023]'
                                : 'bg-amber-50 text-amber-500'
                            }`}>
                              {o.paymentStatus}
                            </span>
                          </td>
                          <td className="p-4 text-right">
                            {o.paymentStatus === 'Pending' && (
                              <button
                                onClick={() => {
                                  const updated = orders.map(item => item.id === o.id ? { ...item, paymentStatus: 'Paid' as const } : item);
                                  onUpdateOrders(updated);
                                  onToast('Transaction marked as Paid.', 'success');
                                }}
                                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-2.5 py-1 rounded text-[9px] uppercase tracking-wider transition-colors"
                              >
                                Mark Paid
                              </button>
                            )}
                            {o.paymentStatus === 'Paid' && (
                              <span className="text-[10px] font-mono text-neutral-400 font-semibold flex items-center gap-1 justify-end">
                                <Check className="w-3 h-3 text-emerald-600" /> RECONCILED
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              <div className="py-12 text-center text-neutral-400 bg-white border border-neutral-200 rounded-2xl">
                <p className="text-xs">No transactions registered yet. Checkouts will auto-populate this log feed.</p>
              </div>
            )}
          </div>
        )}

        {/* TAB: REVIEWS */}
        {activeTab === 'reviews' && (
          <div className="space-y-6 text-left animate-fade-in">
            <h2 className="text-sm font-black uppercase tracking-widest text-black pb-3 border-b border-neutral-200">
              Customer Feedback & Reviews Moderator
            </h2>

            {/* Collected reviews feed */}
            {products.flatMap(p => p.reviews.map(r => ({ ...r, product: p }))).length > 0 ? (
              <div className="bg-white border border-neutral-200 rounded-2xl overflow-hidden shadow-sm text-xs">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-neutral-50 text-neutral-400 font-bold border-b border-neutral-200 text-[10px] uppercase tracking-wider">
                        <th className="p-4">Product Name</th>
                        <th className="p-4">Rating Score</th>
                        <th className="p-4">Reviewer</th>
                        <th className="p-4">Verified Comment</th>
                        <th className="p-4">Date Left</th>
                        <th className="p-4 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-100 text-black">
                      {products.flatMap(p => p.reviews.map(r => ({ ...r, product: p }))).map((rev) => (
                        <tr key={rev.id} className="hover:bg-neutral-50">
                          <td className="p-4 max-w-[200px]">
                            <p onClick={() => onNavigate('product-details', { productId: rev.product.id })} className="font-bold text-black hover:text-[#E60023] cursor-pointer truncate">
                              {rev.product.name}
                            </p>
                            <span className="text-[9px] text-neutral-400 block uppercase font-bold">{rev.product.category}</span>
                          </td>
                          <td className="p-4">
                            <div className="flex gap-0.5">
                              {[...Array(5)].map((_, i) => (
                                <Star key={i} className={`w-3 h-3 ${i < rev.rating ? 'fill-amber-400 text-amber-400' : 'text-neutral-200'}`} />
                              ))}
                            </div>
                          </td>
                          <td className="p-4 font-black">{rev.userName}</td>
                          <td className="p-4 max-w-sm text-neutral-600 font-medium leading-relaxed italic">"{rev.comment}"</td>
                          <td className="p-4 font-mono text-neutral-500">{rev.date}</td>
                          <td className="p-4 text-right">
                            <button
                              onClick={() => {
                                const updatedProducts = products.map(p => {
                                  if (p.id === rev.product.id) {
                                    const filteredReviews = p.reviews.filter(item => item.id !== rev.id);
                                    const reviewsCount = filteredReviews.length;
                                    const avgRating = reviewsCount > 0 
                                      ? Number((filteredReviews.reduce((sum, r) => sum + r.rating, 0) / reviewsCount).toFixed(1))
                                      : 5.0;
                                    return {
                                      ...p,
                                      reviews: filteredReviews,
                                      reviewsCount,
                                      rating: avgRating
                                    };
                                  }
                                  return p;
                                });
                                onUpdateProducts(updatedProducts);
                                onToast('Review deleted from the system.', 'info');
                              }}
                              className="p-1.5 hover:bg-red-50 text-[#E60023] rounded transition-colors"
                              title="Delete review"
                            >
                              <Trash2 className="w-4 h-4 text-[#E60023]" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              <div className="py-12 text-center text-neutral-400 bg-white border border-neutral-200 rounded-2xl">
                <p className="text-xs">No customer reviews are on record currently.</p>
              </div>
            )}
          </div>
        )}

      </div>

    </div>
  );
}
