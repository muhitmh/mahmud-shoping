import React, { useState } from 'react';
import { User, ShoppingBag, MapPin, Key, ShieldCheck, Plus, Trash2, ArrowRight } from 'lucide-react';
import { Order, Address } from '../types';

interface DashboardViewProps {
  currentUser: any;
  orders: Order[];
  onNavigate: (view: string, params?: any) => void;
  onToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
}

export default function DashboardView({
  currentUser,
  orders,
  onNavigate,
  onToast
}: DashboardViewProps) {
  const [activeTab, setActiveTab] = useState<'profile' | 'orders' | 'addresses' | 'security'>('profile');

  // Profile Edit State
  const [name, setName] = useState(currentUser?.name || '');
  const [phone, setPhone] = useState(currentUser?.phone || '+880 1712-345678');

  // Address Book state
  const [addresses, setAddresses] = useState<Address[]>([
    {
      id: 'addr-001',
      label: 'Home Atelier',
      fullName: currentUser?.name || 'Liam Mahmud',
      phone: '+880 1712-345678',
      street: '12 Royal Avenue, Block E, Gulshan-2',
      city: 'Dhaka',
      postalCode: '1212',
      country: 'Bangladesh',
      isDefault: true
    }
  ]);
  const [showAddressForm, setShowAddressForm] = useState(false);
  const [newLabel, setNewLabel] = useState('');
  const [newStreet, setNewStreet] = useState('');
  const [newCity, setNewCity] = useState('Dhaka');
  const [newPostal, setNewPostal] = useState('');

  // Password Edit State
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');

  const userOrders = orders.filter(o => o.shippingAddress.fullName.toLowerCase().includes(currentUser?.name?.toLowerCase() || ''));

  const handleProfileUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    currentUser.name = name;
    currentUser.phone = phone;
    onToast('Your profile identity was updated successfully!', 'success');
  };

  const handleAddAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLabel.trim() || !newStreet.trim() || !newPostal.trim()) {
      onToast('Please fill out all address fields.', 'error');
      return;
    }

    const created: Address = {
      id: `addr-${Date.now()}`,
      label: newLabel,
      fullName: currentUser?.name || 'Liam Mahmud',
      phone: phone,
      street: newStreet,
      city: newCity,
      postalCode: newPostal,
      country: 'Bangladesh',
      isDefault: false
    };

    setAddresses([...addresses, created]);
    setShowAddressForm(false);
    setNewLabel('');
    setNewStreet('');
    setNewPostal('');
    onToast('New shipping address saved with your booklet.', 'success');
  };

  const handleDeleteAddress = (id: string) => {
    setAddresses(addresses.filter(a => a.id !== id));
    onToast('Address removed from booklet.', 'info');
  };

  const handlePasswordUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentPass || !newPass || !confirmPass) {
      onToast('Please complete all security inputs.', 'error');
      return;
    }
    if (newPass !== confirmPass) {
      onToast('Passwords do not match.', 'error');
      return;
    }
    onToast('Your secure account passcode has been updated.', 'success');
    setCurrentPass('');
    setNewPass('');
    setConfirmPass('');
  };

  return (
    <div id="dashboard-view" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 bg-white text-black animate-fade-in">
      
      {/* Welcome Banner */}
      <div className="bg-white border border-neutral-200 text-black rounded-3xl p-6 sm:p-10 relative overflow-hidden shadow-sm">
        <div className="relative z-10 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6 text-left">
          <div className="space-y-1.5">
            <span className="text-[#E60023] font-bold tracking-[0.35em] text-[10px] uppercase">GUEST PATRON PROFILE</span>
            <h1 className="text-2xl sm:text-4xl font-black uppercase tracking-tight text-black">Bonjour, {currentUser?.name || 'Patron'}</h1>
            <p className="text-xs text-neutral-500">Manage order tracking logs, address books, and profile identities.</p>
          </div>
          {currentUser?.role === 'admin' && (
            <button
              onClick={() => onNavigate('admin')}
              className="bg-[#E60023] hover:opacity-90 text-white font-bold text-xs tracking-widest px-5 py-3 rounded-xl transition-all uppercase shadow-md"
            >
              LAUNCH ADMINISTRATIVE CONSOLE
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left: Tab Switcher navigation booklet (Col Span 3) */}
        <aside className="lg:col-span-3 bg-white border border-neutral-200 p-5 rounded-2xl shadow-sm space-y-1 text-xs">
          {[
            { id: 'profile', label: 'My Identity', icon: <User className="w-4 h-4 text-black" /> },
            { id: 'orders', label: 'Order History', icon: <ShoppingBag className="w-4 h-4 text-black" /> },
            { id: 'addresses', label: 'Address Booklet', icon: <MapPin className="w-4 h-4 text-black" /> },
            { id: 'security', label: 'Security & Password', icon: <Key className="w-4 h-4 text-black" /> }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all text-left ${
                activeTab === tab.id
                  ? 'bg-red-50 text-[#E60023] border-l-4 border-[#E60023]'
                  : 'text-neutral-700 hover:bg-neutral-50'
              }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </aside>

        {/* Right: Tab content display (Col Span 9) */}
        <div className="lg:col-span-9 bg-white border border-neutral-200 p-6 sm:p-8 rounded-2xl shadow-sm min-h-[400px]">
          
          {/* PROFILE TAB */}
          {activeTab === 'profile' && (
            <div className="space-y-6">
              <h2 className="text-sm font-black uppercase tracking-widest text-black pb-3 border-b border-neutral-200">1. Edit Identity details</h2>
              
              <form onSubmit={handleProfileUpdate} className="space-y-4 max-w-xl text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Full Name</label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full bg-white border border-neutral-200 rounded-lg p-3 outline-none focus:border-[#E60023] text-black"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Email Address (Read-only)</label>
                    <input
                      type="email"
                      readOnly
                      value={currentUser?.email || ''}
                      className="w-full bg-neutral-100 border border-neutral-200 rounded-lg p-3 text-neutral-500 font-bold outline-none cursor-not-allowed text-xs"
                    />
                  </div>

                  <div className="space-y-1 sm:col-span-2">
                    <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Mobile Phone</label>
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full bg-white border border-neutral-200 rounded-lg p-3 outline-none focus:border-[#E60023] text-black"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="bg-[#E60023] hover:opacity-90 text-white px-6 py-3 rounded-xl text-xs font-bold tracking-widest transition-colors uppercase shadow-md"
                >
                  SAVE IDENTITY CHANGES
                </button>
              </form>
            </div>
          )}

          {/* ORDERS HISTORY TAB */}
          {activeTab === 'orders' && (
            <div className="space-y-6">
              <h2 className="text-sm font-black uppercase tracking-widest text-black pb-3 border-b border-neutral-200">2. Active Order logs</h2>
              
              {userOrders.length > 0 ? (
                <div className="space-y-4">
                  {userOrders.map((ord) => (
                    <div
                      key={ord.id}
                      className="border border-neutral-200 p-4 sm:p-5 rounded-2xl flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center bg-white"
                    >
                      <div className="space-y-1 text-left">
                        <p className="text-[9px] text-neutral-400 font-bold uppercase tracking-widest">ORDER TRACKING ID</p>
                        <p className="text-xs font-bold font-mono text-black">{ord.trackingNumber}</p>
                        <p className="text-[10px] text-neutral-500">{ord.date} • {ord.items.length} garments • ${ord.total}</p>
                      </div>

                      <div className="flex items-center gap-4 w-full sm:w-auto justify-between sm:justify-end">
                        <span className={`px-3 py-1 rounded-full text-[9px] font-bold uppercase tracking-widest ${
                          ord.status === 'Delivered'
                            ? 'bg-emerald-100 text-emerald-800'
                            : ord.status === 'Shipped'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-amber-100 text-amber-850'
                        }`}>
                          {ord.status}
                        </span>

                        <button
                          onClick={() => onNavigate('tracking', { trackId: ord.trackingNumber })}
                          className="text-xs font-bold text-[#E60023] hover:opacity-80 flex items-center gap-1 hover:underline"
                        >
                          Track <ArrowRight className="w-3.5 h-3.5 text-[#E60023]" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-12 text-center text-neutral-400 space-y-3">
                  <ShoppingBag className="w-10 h-10 mx-auto text-[#E60023]" />
                  <p className="text-xs font-bold uppercase tracking-wider text-black">No active order records found.</p>
                  <button
                    onClick={() => onNavigate('shop')}
                    className="text-[#E60023] hover:underline text-xs font-bold"
                  >
                    Browse couture to initiate orders
                  </button>
                </div>
              )}
            </div>
          )}

          {/* ADDRESS BOOK TAB */}
          {activeTab === 'addresses' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center pb-3 border-b border-neutral-200">
                <h2 className="text-sm font-black uppercase tracking-widest text-black">3. Shipping address Booklet</h2>
                <button
                  onClick={() => setShowAddressForm(!showAddressForm)}
                  className="bg-[#E60023] hover:opacity-90 text-white px-4 py-2 rounded-xl text-xs font-bold tracking-wider flex items-center gap-1.5 transition-colors uppercase shadow-sm"
                >
                  <Plus className="w-4 h-4 text-white" /> ADD NEW
                </button>
              </div>

              {/* Add Address Interactive Form */}
              {showAddressForm && (
                <form onSubmit={handleAddAddress} className="bg-white border border-neutral-200 p-5 rounded-2xl text-xs space-y-4 max-w-xl text-left">
                  <h4 className="font-bold text-black uppercase tracking-wider">Register shipping booklet</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Address Label *</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Office, Penthouse"
                        value={newLabel}
                        onChange={(e) => setNewLabel(e.target.value)}
                        className="w-full bg-white border border-neutral-200 p-2.5 rounded-lg outline-none text-black focus:border-[#E60023]"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Postal Code *</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. 1212"
                        value={newPostal}
                        onChange={(e) => setNewPostal(e.target.value)}
                        className="w-full bg-white border border-neutral-200 p-2.5 rounded-lg outline-none text-black focus:border-[#E60023]"
                      />
                    </div>
                    <div className="space-y-1 sm:col-span-2">
                      <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Street & Block Address *</label>
                      <input
                        type="text"
                        required
                        placeholder="House number, apartment, road..."
                        value={newStreet}
                        onChange={(e) => setNewStreet(e.target.value)}
                        className="w-full bg-white border border-neutral-200 p-2.5 rounded-lg outline-none text-black focus:border-[#E60023]"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">City *</label>
                      <select
                        value={newCity}
                        onChange={(e) => setNewCity(e.target.value)}
                        className="w-full bg-white border border-neutral-200 p-2.5 rounded-lg outline-none font-bold text-black text-xs focus:border-[#E60023]"
                      >
                        <option value="Dhaka">Dhaka</option>
                        <option value="Chattogram">Chattogram</option>
                        <option value="Sylhet">Sylhet</option>
                      </select>
                    </div>
                  </div>

                  <div className="flex gap-2 justify-end">
                    <button
                      type="button"
                      onClick={() => setShowAddressForm(false)}
                      className="px-4 py-2 text-neutral-500 font-bold hover:underline"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="bg-[#E60023] hover:opacity-90 text-white px-5 py-2 rounded-lg font-bold"
                    >
                      Save Address
                    </button>
                  </div>
                </form>
              )}

              {/* Addresses List */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {addresses.map((addr) => (
                  <div
                    key={addr.id}
                    className="border border-neutral-200 p-4 rounded-xl space-y-2 relative text-left bg-white flex flex-col justify-between shadow-sm"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-xs uppercase tracking-wider text-black">
                          {addr.label}
                        </span>
                        {addr.isDefault && (
                          <span className="bg-red-100 text-[#E60023] px-1.5 py-0.5 rounded text-[8px] font-bold uppercase tracking-widest">
                            Primary Address
                          </span>
                        )}
                      </div>
                      <p className="text-xs font-semibold text-neutral-700">{addr.fullName} — {addr.phone}</p>
                      <p className="text-xs text-neutral-500">{addr.street}, {addr.city} {addr.postalCode}, {addr.country}</p>
                    </div>

                    {!addr.isDefault && (
                      <button
                        onClick={() => handleDeleteAddress(addr.id)}
                        className="text-neutral-400 hover:text-[#E60023] transition-colors p-1.5 self-end"
                        title="Delete Address"
                      >
                        <Trash2 className="w-4 h-4 text-neutral-400" />
                      </button>
                    )}
                  </div>
                ))}
              </div>

            </div>
          )}

          {/* SECURITY & PASSWORDS TAB */}
          {activeTab === 'security' && (
            <div className="space-y-6 text-left">
              <h2 className="text-sm font-black uppercase tracking-widest text-black pb-3 border-b border-neutral-200">4. Update Secure Account Password</h2>
              
              <form onSubmit={handlePasswordUpdate} className="space-y-4 max-w-xl text-xs">
                <div className="space-y-1">
                  <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Current Security Password</label>
                  <input
                    type="password"
                    required
                    value={currentPass}
                    onChange={(e) => setCurrentPass(e.target.value)}
                    className="w-full bg-white border border-neutral-200 rounded-lg p-3 outline-none focus:border-[#E60023] text-black"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">New Security Password</label>
                  <input
                    type="password"
                    required
                    value={newPass}
                    onChange={(e) => setNewPass(e.target.value)}
                    className="w-full bg-white border border-neutral-200 rounded-lg p-3 outline-none focus:border-[#E60023] text-black"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Confirm Security Password</label>
                  <input
                    type="password"
                    required
                    value={confirmPass}
                    onChange={(e) => setConfirmPass(e.target.value)}
                    className="w-full bg-white border border-neutral-200 rounded-lg p-3 outline-none focus:border-[#E60023] text-black"
                  />
                </div>

                <button
                  type="submit"
                  className="bg-[#E60023] hover:opacity-90 text-white px-6 py-3 rounded-xl text-xs font-bold tracking-widest transition-colors uppercase shadow-md"
                >
                  SAVE SECURITY PASSWORD
                </button>
              </form>

              <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-xl flex items-center gap-3 text-xs text-emerald-800">
                <ShieldCheck className="w-5 h-5 shrink-0 text-emerald-600" />
                <span>Your login details are encrypted and backed by secure, client-side offline sandbox persistence.</span>
              </div>
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
