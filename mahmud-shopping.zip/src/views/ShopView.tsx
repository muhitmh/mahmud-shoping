import React, { useState, useEffect } from 'react';
import { Search, SlidersHorizontal, Eye, Heart, ShoppingBag, Star, RefreshCcw, Check } from 'lucide-react';
import { Product } from '../types';

interface ShopViewProps {
  products: Product[];
  initialCategory?: string;
  initialFilter?: string;
  onNavigate: (view: string, params?: any) => void;
  onQuickView: (product: Product) => void;
  onAddToWishlist: (product: Product) => void;
  wishlistIds: string[];
}

export default function ShopView({
  products,
  initialCategory = 'All',
  initialFilter = '',
  onNavigate,
  onQuickView,
  onAddToWishlist,
  wishlistIds
}: ShopViewProps) {
  // Filters State
  const [selectedCategory, setSelectedCategory] = useState(initialCategory);
  const [priceRange, setPriceRange] = useState<number>(1500);
  const [selectedSize, setSelectedSize] = useState<string>('All');
  const [selectedColor, setSelectedColor] = useState<string>('All');
  const [selectedRating, setSelectedRating] = useState<number | null>(null);
  const [sortBy, setSortBy] = useState<string>('newest');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showFilters, setShowFilters] = useState<boolean>(true);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Trigger loading state for 800ms when categories/filters change
  useEffect(() => {
    setIsLoading(true);
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 800);
    return () => clearTimeout(timer);
  }, [selectedCategory, priceRange, selectedSize, selectedColor, selectedRating, sortBy, searchQuery]);

  // Handle passed initial values
  useEffect(() => {
    if (initialCategory) {
      setSelectedCategory(initialCategory);
    }
    if (initialFilter === 'flash-sale') {
      setPriceRange(1500);
    }
  }, [initialCategory, initialFilter]);

  // Unique lists of sizes and colors for filter buttons
  const allSizes = ['All', 'XS', 'S', 'M', 'L', 'XL', 'XXL', '36', '38', '40', '42', '44'];
  const allColors = [
    { name: 'All', hex: '' },
    { name: 'Black', hex: '#111111' },
    { name: 'Red', hex: '#E60023' },
    { name: 'White', hex: '#F9FAFB' },
    { name: 'Gold', hex: '#EAB308' },
    { name: 'Velvet', hex: '#881337' }
  ];

  // Filtering Logic
  const filteredProducts = products.filter((prod) => {
    // 1. Category
    if (selectedCategory !== 'All' && prod.category !== selectedCategory) return false;

    // 2. Max Price
    if (prod.price > priceRange) return false;

    // 3. Size
    if (selectedSize !== 'All' && !prod.sizes.includes(selectedSize)) return false;

    // 4. Color
    if (selectedColor !== 'All') {
      const hasColor = prod.colors.some(c => c.name.toLowerCase().includes(selectedColor.toLowerCase()));
      if (!hasColor) return false;
    }

    // 5. Rating
    if (selectedRating !== null && prod.rating < selectedRating) return false;

    // 6. Flash Sale (if requested from initial filter)
    if (initialFilter === 'flash-sale' && !prod.isFlashSale) return false;

    // 7. Live search
    if (searchQuery.trim() && !prod.name.toLowerCase().includes(searchQuery.toLowerCase()) && !prod.category.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }

    return true;
  });

  // Sorting Logic
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case 'price-low':
        return a.price - b.price;
      case 'price-high':
        return b.price - a.price;
      case 'best-selling':
        return (b.isBestSeller ? 1 : 0) - (a.isBestSeller ? 1 : 0);
      case 'newest':
      default:
        return (b.isNewArrival ? 1 : 0) - (a.isNewArrival ? 1 : 0);
    }
  });

  const clearAllFilters = () => {
    setSelectedCategory('All');
    setPriceRange(1500);
    setSelectedSize('All');
    setSelectedColor('All');
    setSelectedRating(null);
    setSearchQuery('');
    setSortBy('newest');
    onNavigate('shop', { category: 'All' });
  };

  return (
    <div id="shop-view" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 bg-white text-black animate-fade-in">
      
      {/* Banner / Header */}
      <div className="bg-white text-black border border-neutral-200 rounded-3xl p-8 sm:p-12 relative overflow-hidden shadow-md flex flex-col justify-center min-h-[160px]">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,_var(--tw-gradient-stops))] from-neutral-50 via-white to-white z-0 opacity-85" />
        <div className="relative z-10 text-left space-y-2">
          <p className="text-[#E60023] font-bold tracking-[0.3em] text-xs uppercase">MAHMUD ATELIER ARCHIVE</p>
          <h1 className="text-3xl sm:text-5xl font-black uppercase tracking-tight text-black">The Luxury Catalog</h1>
          <p className="text-xs text-neutral-500 max-w-md leading-relaxed">
            Browse our comprehensive selection of coats, dresses, and customized footwear tailored for high-frequency luxury living.
          </p>
        </div>
      </div>

      {/* Control Bar: Search, Filters Toggle, Sort By */}
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4 bg-white p-4 rounded-2xl border border-neutral-200 shadow-sm">
        
        {/* Toggle Filters & Search */}
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center gap-2 px-4 py-2.5 bg-[#E60023] text-white hover:bg-[#E60023]/90 rounded-xl text-xs font-bold tracking-widest transition-colors shadow-sm"
          >
            <SlidersHorizontal className="w-4 h-4" />
            {showFilters ? 'HIDE ATELIER FILTERS' : 'SHOW ATELIER FILTERS'}
          </button>

          <div className="relative flex-1 sm:w-64">
            <input
              type="text"
              placeholder="Search catalog..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full text-xs bg-white border border-neutral-200 rounded-xl py-2.5 pl-10 pr-4 outline-none focus:border-[#E60023] text-black"
            />
            <Search className="absolute left-3.5 top-3 w-4 h-4 text-[#E60023]" />
          </div>
        </div>

        {/* Results Counter & Sort Selector */}
        <div className="flex items-center justify-between sm:justify-end gap-6 w-full sm:w-auto text-xs">
          <span className="font-bold text-neutral-550 uppercase tracking-wider">
            {sortedProducts.length} Premium Results
          </span>

          <div className="flex items-center gap-2">
            <span className="text-neutral-400 font-bold uppercase tracking-wider text-[10px]">Sort By:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="bg-white border border-neutral-200 px-3 py-2 rounded-xl font-bold outline-none cursor-pointer focus:border-[#E60023] text-black text-xs"
            >
              <option value="newest">Newest & Haute</option>
              <option value="price-low">Price: Low to High</option>
              <option value="price-high">Price: High to Low</option>
              <option value="best-selling">Best Selling</option>
            </select>
          </div>
        </div>

      </div>

      <div className="flex flex-col lg:flex-row gap-8 items-start">
        
        {/* FILTERS SIDEBAR (Collapsible) */}
        {showFilters && (
          <aside className="w-full lg:w-72 bg-white border border-neutral-200 rounded-2xl p-6 space-y-6 shrink-0 shadow-sm sticky top-24 max-h-[80vh] overflow-y-auto">
            
            <div className="flex justify-between items-center pb-3 border-b border-neutral-200">
              <h3 className="text-xs font-black tracking-widest text-black uppercase">Atelier Filters</h3>
              <button
                onClick={clearAllFilters}
                className="text-[10px] text-[#E60023] hover:underline tracking-wider font-bold"
              >
                CLEAR ALL
              </button>
            </div>

            {/* Categories Selection */}
            <div className="space-y-2">
              <h4 className="text-[10px] font-black uppercase tracking-wider text-neutral-400">Department</h4>
              <div className="flex flex-col gap-1 text-xs">
                {['All', 'Fashion', 'Shoes', 'Watches', 'Bags', 'Electronics', 'Accessories', 'Sports Items'].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`w-full text-left py-2 px-3 rounded-lg font-bold transition-all flex justify-between items-center ${
                      selectedCategory === cat
                        ? 'bg-red-50 text-[#E60023] border-l-4 border-[#E60023]'
                        : 'text-black hover:bg-neutral-50'
                    }`}
                  >
                    <span>{cat}</span>
                    <span className="text-[10px] text-neutral-400">
                      ({products.filter(p => cat === 'All' || p.category === cat).length})
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Price Filter Slider */}
            <div className="space-y-3">
              <div className="flex justify-between text-[10px] font-black uppercase tracking-wider text-neutral-400">
                <span>Max Budget</span>
                <span className="text-black font-black">${priceRange}</span>
              </div>
              <input
                type="range"
                min="200"
                max="1500"
                step="50"
                value={priceRange}
                onChange={(e) => setPriceRange(Number(e.target.value))}
                className="w-full accent-[#E60023] cursor-pointer"
              />
              <div className="flex justify-between text-[9px] text-neutral-400 font-mono font-bold">
                <span>$200</span>
                <span>$1,500</span>
              </div>
            </div>

            {/* Size Filter Grid */}
            <div className="space-y-2.5">
              <h4 className="text-[10px] font-black uppercase tracking-wider text-neutral-400">Sizes</h4>
              <div className="flex flex-wrap gap-1.5">
                {allSizes.map((sz) => (
                  <button
                    key={sz}
                    onClick={() => setSelectedSize(sz)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${
                      selectedSize === sz
                        ? 'border-[#E60023] bg-[#E60023] text-white shadow'
                        : 'border-neutral-200 text-black hover:border-[#E60023]'
                    }`}
                  >
                    {sz}
                  </button>
                ))}
              </div>
            </div>

            {/* Color Filter Selector */}
            <div className="space-y-2.5">
              <h4 className="text-[10px] font-black uppercase tracking-wider text-neutral-400">Colors</h4>
              <div className="flex flex-wrap gap-2">
                {allColors.map((color) => (
                  <button
                    key={color.name}
                    onClick={() => setSelectedColor(color.name)}
                    className={`relative w-7 h-7 rounded-full border p-0.5 transition-transform ${
                      selectedColor === color.name ? 'border-[#E60023] scale-110 shadow-md' : 'border-neutral-200'
                    }`}
                    style={{ backgroundColor: color.hex || '#E4E4E7' }}
                    title={color.name}
                  >
                    {color.name === 'All' && <span className="text-[8px] font-bold text-neutral-600">ALL</span>}
                    {selectedColor === color.name && color.name !== 'All' && (
                      <Check className="w-3 h-3 text-white absolute inset-0 m-auto" />
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Rating Filter Selector */}
            <div className="space-y-2">
              <h4 className="text-[10px] font-black uppercase tracking-wider text-neutral-400">Atelier Rating</h4>
              <div className="flex flex-col gap-1.5 text-xs">
                {[4.8, 4.7, 4.6, 4.5].map((rating) => (
                  <button
                    key={rating}
                    onClick={() => setSelectedRating(selectedRating === rating ? null : rating)}
                    className={`w-full text-left py-2 px-3 rounded-lg font-bold transition-all flex items-center justify-between ${
                      selectedRating === rating
                        ? 'bg-red-50 text-[#E60023]'
                        : 'text-black hover:bg-neutral-50'
                    }`}
                  >
                    <span className="flex items-center gap-1.5">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className={`w-3.5 h-3.5 ${i < Math.floor(rating) ? 'fill-amber-400 text-amber-400' : 'text-neutral-200'}`} />
                      ))}
                      <span>{rating}+</span>
                    </span>
                    {selectedRating === rating && <Check className="w-4 h-4 text-[#E60023]" />}
                  </button>
                ))}
              </div>
            </div>

          </aside>
        )}

        {/* PRODUCTS GRID (Adaptive) */}
        <div className="flex-1 w-full space-y-6">
          
          {/* Skeleton Loaders state */}
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="border border-neutral-200 rounded-2xl overflow-hidden p-4 space-y-4 animate-pulse bg-white">
                  <div className="bg-neutral-150 aspect-square rounded-xl" />
                  <div className="h-4 bg-neutral-150 rounded w-1/3" />
                  <div className="h-5 bg-neutral-150 rounded w-2/3" />
                  <div className="h-4 bg-neutral-150 rounded w-1/4" />
                </div>
              ))}
            </div>
          ) : sortedProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
              {sortedProducts.map((prod) => {
                const isWish = wishlistIds.includes(prod.id);
                const discount = prod.originalPrice ? Math.round(((prod.originalPrice - prod.price) / prod.originalPrice) * 100) : 0;
                
                return (
                  <div
                    key={prod.id}
                    className="group border border-neutral-150 rounded-2xl overflow-hidden shadow-sm hover:shadow-md bg-white transition-all duration-300 flex flex-col justify-between h-full"
                  >
                    <div className="relative aspect-square overflow-hidden bg-white p-4">
                      <img
                        src={prod.images[0]}
                        alt={prod.name}
                        className="w-full h-full object-contain transition-transform duration-500 group-hover:scale-105"
                      />
                      {prod.isNewArrival && (
                        <span className="absolute top-3 left-3 bg-[#E60023] text-white text-[9px] font-bold px-2 py-0.5 rounded-full tracking-widest uppercase font-mono">
                          NEW DROP
                        </span>
                      )}
                      {discount > 0 && (
                        <span className="absolute top-3 right-3 bg-[#E60023] text-white text-[9px] font-bold px-2 py-0.5 rounded-full tracking-widest font-mono">
                          -{discount}%
                        </span>
                      )}

                      {/* Interactive hover overlays */}
                      <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-3 z-10">
                        <button
                          onClick={() => onQuickView(prod)}
                          className="bg-white text-black hover:bg-[#E60023] hover:text-white p-2.5 rounded-full transition-transform transform scale-90 group-hover:scale-100 shadow-md"
                          title="Quick Inspect"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => onAddToWishlist(prod)}
                          className="bg-white text-black hover:bg-[#E60023] hover:text-white p-2.5 rounded-full transition-transform transform scale-90 group-hover:scale-100 shadow-md"
                          title="Add to Wishlist"
                        >
                          <Heart className={`w-4 h-4 ${isWish ? 'fill-[#E60023] text-[#E60023]' : 'text-black'}`} />
                        </button>
                        <button
                          onClick={() => onNavigate('product-details', { productId: prod.id })}
                          className="bg-white text-black hover:bg-[#E60023] hover:text-white p-2.5 rounded-full transition-transform transform scale-90 group-hover:scale-100 shadow-md"
                          title="View Details"
                        >
                          <ShoppingBag className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <div className="p-4 space-y-2">
                      <div>
                        <span className="text-[10px] uppercase font-bold text-neutral-400 tracking-widest">
                          {prod.category}
                        </span>
                        <h3
                          onClick={() => onNavigate('product-details', { productId: prod.id })}
                          className="text-sm font-bold text-black hover:text-[#E60023] cursor-pointer truncate mt-0.5"
                        >
                          {prod.name}
                        </h3>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-baseline gap-2">
                          <span className="text-base font-black text-[#E60023]">
                            ${prod.price}
                          </span>
                          {prod.originalPrice && (
                            <span className="text-xs text-neutral-400 line-through">
                              ${prod.originalPrice}
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-1">
                          <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                          <span className="text-xs font-bold text-black">{prod.rating}</span>
                        </div>
                      </div>

                      {/* Add directly to bag button on card bottom */}
                      <button
                        onClick={() => onQuickView(prod)}
                        className="w-full bg-neutral-50 hover:bg-[#E60023] hover:text-white py-2.5 rounded-xl text-[10px] font-bold tracking-widest uppercase transition-colors text-black"
                      >
                        SELECT OPTIONS & BUY
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="bg-white border border-neutral-200 rounded-3xl p-16 text-center space-y-4">
              <RefreshCcw className="w-12 h-12 text-[#E60023] mx-auto animate-spin" />
              <h3 className="text-xl font-bold text-black uppercase tracking-wider">No Products Found</h3>
              <p className="text-xs text-neutral-500 max-w-md mx-auto">
                No luxury garments currently match your selected filters. Reset all filters to resume exploring our catalogs.
              </p>
              <button
                onClick={clearAllFilters}
                className="bg-[#E60023] text-white hover:opacity-90 px-6 py-3 rounded-xl text-xs font-bold tracking-widest transition-colors shadow-sm"
              >
                CLEAR FILTER MATRIX
              </button>
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
