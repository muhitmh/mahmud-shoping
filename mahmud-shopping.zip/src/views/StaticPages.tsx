import React, { useState, useEffect } from 'react';
import { Heart, Search, Eye, Trash2, ShieldCheck, Mail, Phone, MapPin, HelpCircle, Lock, CheckCircle, Truck } from 'lucide-react';
import { Product, Order } from '../types';

// ==========================================
// 1. WISHLIST VIEW
// ==========================================
interface WishlistViewProps {
  wishlist: Product[];
  onRemoveFromWishlist: (product: Product) => void;
  onQuickView: (product: Product) => void;
  onNavigate: (view: string, params?: any) => void;
}

export function WishlistView({ wishlist, onRemoveFromWishlist, onQuickView, onNavigate }: WishlistViewProps) {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 bg-white text-black animate-fade-in">
      <div className="border-b border-neutral-200 pb-4">
        <h1 className="text-3xl font-black uppercase tracking-tight text-black">Saved Favorites</h1>
        <p className="text-xs text-neutral-400 mt-1">Bookmarked luxury garments and couture capsular items.</p>
      </div>

      {wishlist.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {wishlist.map((prod) => (
            <div
              key={prod.id}
              className="border border-neutral-200 rounded-2xl overflow-hidden bg-white shadow-sm flex flex-col justify-between h-full group"
            >
              <div className="relative aspect-square overflow-hidden bg-neutral-50 p-4">
                <img src={prod.images[0]} alt={prod.name} className="w-full h-full object-contain transition-transform duration-500 group-hover:scale-105" />
                
                <button
                  onClick={() => onRemoveFromWishlist(prod)}
                  className="absolute top-3 right-3 bg-white hover:bg-red-50 text-[#E60023] p-2 rounded-full shadow transition-all"
                  title="Remove from favorites"
                >
                  <Trash2 className="w-4 h-4 text-[#E60023]" />
                </button>
              </div>

              <div className="p-4 space-y-3">
                <div>
                  <span className="text-[10px] text-neutral-400 font-bold uppercase block">{prod.category}</span>
                  <h3
                    onClick={() => onNavigate('product-details', { productId: prod.id })}
                    className="text-xs font-bold truncate cursor-pointer text-black hover:text-[#E60023]"
                  >
                    {prod.name}
                  </h3>
                </div>

                <div className="flex justify-between items-center pt-1 border-t border-neutral-200">
                  <span className="font-black text-sm text-[#E60023]">${prod.price}</span>
                  <button
                    onClick={() => onQuickView(prod)}
                    className="bg-[#E60023] hover:opacity-90 text-white px-3 py-1.5 rounded-lg text-[10px] font-bold tracking-widest uppercase transition-colors shadow-sm"
                  >
                    SELECT & BUY
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white border border-neutral-200 rounded-3xl p-16 text-center max-w-xl mx-auto space-y-4 shadow-sm">
          <Heart className="w-12 h-12 text-[#E60023] mx-auto animate-pulse" />
          <h3 className="text-xl font-bold uppercase tracking-wider text-black">Wishlist is Empty</h3>
          <p className="text-xs text-neutral-500 max-w-sm mx-auto leading-relaxed">
            Bookmarks help you tracking premium seasonal markdowns. Explore our shop categories to bookmark your favorites.
          </p>
          <button
            onClick={() => onNavigate('shop')}
            className="bg-[#E60023] hover:opacity-90 text-white px-6 py-2.5 rounded-xl text-xs font-bold tracking-widest uppercase shadow-md"
          >
            Explore Catalog
          </button>
        </div>
      )}
    </div>
  );
}

// ==========================================
// 2. CATEGORIES VIEW
// ==========================================
interface CategoriesViewProps {
  products: Product[];
  onNavigate: (view: string, params?: any) => void;
}

export function CategoriesView({ products, onNavigate }: CategoriesViewProps) {
  const departments = [
    { name: 'Fashion', image: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?auto=format&fit=crop&w=600&q=80', tag: 'Haute Couture Coats, Structured Suits & Elegant Silk Gowns' },
    { name: 'Shoes', image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=600&q=80', tag: 'Architectural Patent Heels, Chelsea Suede & Supple Calf Sneakers' },
    { name: 'Watches', image: 'https://images.unsplash.com/photo-1524592094714-0f0654e20314?auto=format&fit=crop&w=600&q=80', tag: 'Automatic chronographs, solid titanium smart wear, Swiss minimalist pieces' },
    { name: 'Bags', image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=600&q=80', tag: 'Chevron Quilted Leather Clutches, Suede Backpacks & Weekend Duffels' },
    { name: 'Electronics', image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80', tag: 'High-Fidelity Beryllium Headphones, planar earbuds, smart calibrating audio' },
    { name: 'Accessories', image: 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=600&q=80', tag: 'Polarized Titanium Eye Protection, French Silk Twills & Saffiano Leather Wallets' },
    { name: 'Sports Items', image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=600&q=80', tag: 'Eco-Luxury Cork Yoga Mats, dial-adjustable dumbbells & weather-sealed duffels' }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 bg-white text-black animate-fade-in">
      <div className="border-b border-neutral-200 pb-4">
        <h1 className="text-3xl font-black uppercase tracking-tight text-black">Atelier Departments</h1>
        <p className="text-xs text-neutral-400 mt-1">Structured subdivisions of our fine winter and autumn collections.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {departments.map((dept) => {
          const matchedCount = products.filter(p => p.category === dept.name).length;
          return (
            <div
              key={dept.name}
              onClick={() => onNavigate('shop', { category: dept.name })}
              className="group relative h-96 rounded-3xl overflow-hidden cursor-pointer shadow-md hover:shadow-2xl transition-all duration-500 border border-neutral-200"
            >
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent z-10" />
              <img src={dept.image} alt={dept.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
              
              <div className="absolute bottom-6 left-6 z-20 text-white text-left space-y-1 pr-6">
                <span className="bg-[#E60023] text-white text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">{matchedCount} Collections available</span>
                <h3 className="text-xl font-black uppercase tracking-wider text-white">{dept.name}</h3>
                <p className="text-[10px] text-neutral-300 leading-normal font-medium">{dept.tag}</p>
                <div className="pt-2 flex items-center gap-1.5 text-xs text-[#E60023] font-bold tracking-widest uppercase opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  Explore Now
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ==========================================
// 3. SEARCH RESULTS VIEW
// ==========================================
interface SearchViewProps {
  initialQuery?: string;
  products: Product[];
  onNavigate: (view: string, params?: any) => void;
  onQuickView: (product: Product) => void;
}

export function SearchView({ initialQuery = '', products, onNavigate, onQuickView }: SearchViewProps) {
  const [query, setQuery] = useState(initialQuery);

  const matched = products.filter(p => 
    p.name.toLowerCase().includes(query.toLowerCase()) ||
    p.category.toLowerCase().includes(query.toLowerCase()) ||
    p.description.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 bg-white text-black animate-fade-in">
      
      {/* Search Header */}
      <div className="bg-white border border-neutral-200 rounded-3xl p-6 sm:p-10 flex flex-col md:flex-row items-center justify-between gap-6 shadow-sm">
        <div className="space-y-1 text-left flex-1">
          <p className="text-[#E60023] font-bold tracking-[0.3em] text-[10px] uppercase">MAHMUD COUTURE ENGINE</p>
          <h1 className="text-2xl sm:text-3xl font-black uppercase tracking-tight text-black">Search results</h1>
          <p className="text-xs text-neutral-400">{matched.length} results matching "{query}"</p>
        </div>

        <div className="relative w-full max-w-md">
          <input
            type="text"
            placeholder="Type clothing details..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full text-xs bg-white border border-neutral-200 rounded-xl py-3 pl-10 pr-4 outline-none focus:border-[#E60023] text-black"
          />
          <Search className="absolute left-3.5 top-3.5 w-4 h-4 text-neutral-400" />
        </div>
      </div>

      {/* Grid */}
      {matched.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 text-xs">
          {matched.map((p) => (
            <div key={p.id} className="border border-neutral-200 bg-white rounded-2xl overflow-hidden p-4 space-y-3 flex flex-col justify-between group h-full shadow-sm">
              <div className="aspect-square bg-neutral-50 p-2 rounded-xl overflow-hidden relative">
                <img src={p.images[0]} alt="" className="w-full h-full object-contain mix-blend-multiply transition-transform duration-500 group-hover:scale-105" />
                <button
                  onClick={() => onQuickView(p)}
                  className="absolute bottom-2 right-2 bg-white text-neutral-900 p-2 rounded-full shadow hover:bg-[#E60023] hover:text-white transition-all opacity-0 group-hover:opacity-100"
                >
                  <Eye className="w-4 h-4 text-neutral-800" />
                </button>
              </div>
              <div className="space-y-1 text-left">
                <span className="text-[9px] uppercase font-bold text-neutral-400">{p.category}</span>
                <h3 onClick={() => onNavigate('product-details', { productId: p.id })} className="font-bold truncate text-black hover:text-[#E60023] cursor-pointer">{p.name}</h3>
                <span className="font-black text-sm block text-[#E60023]">${p.price}</span>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="py-16 text-center text-neutral-400 max-w-md mx-auto space-y-2">
          <Search className="w-10 h-10 mx-auto text-[#E60023]" />
          <h3 className="font-bold uppercase tracking-wider text-black">No matching collections</h3>
          <p className="text-xs text-neutral-500">We couldn't locate any velvet blazers, wool coats, or silk gowns matching your search term. Expand your queries.</p>
        </div>
      )}

    </div>
  );
}

// ==========================================
// 4. ORDER TRACKING VIEW
// ==========================================
interface TrackingViewProps {
  initialTrackId?: string;
  orders: Order[];
  onToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
}

export function TrackingView({ initialTrackId = '', orders }: TrackingViewProps) {
  const [trackId, setTrackId] = useState(initialTrackId);
  const [searchId, setSearchId] = useState(initialTrackId);

  useEffect(() => {
    if (initialTrackId) {
      setTrackId(initialTrackId);
      setSearchId(initialTrackId);
    }
  }, [initialTrackId]);

  const handleTrackSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!trackId.trim()) return;
    setSearchId(trackId.trim());
  };

  // Find simulated order
  const matchedOrder = orders.find(o => o.trackingNumber.toUpperCase() === searchId.toUpperCase());

  // Stepper helper
  const steps = [
    { label: 'Atelier Placed', desc: 'Garment pattern logged and materials requested.', key: 'Pending' },
    { label: 'Tailoring Consummated', desc: 'Fine stitching completed under check meters.', key: 'Processing' },
    { label: 'Shipped via DHL', desc: 'Secure parcel handed to DHL courier.', key: 'Shipped' },
    { label: 'Verified Delivery', desc: 'Hand-delivered at designated doorstep.', key: 'Delivered' }
  ];

  const getStepIndex = (status: string) => {
    if (status === 'Pending') return 0;
    if (status === 'Processing') return 1;
    if (status === 'Shipped') return 2;
    if (status === 'Delivered') return 3;
    return 0;
  };

  const activeIndex = matchedOrder ? getStepIndex(matchedOrder.status) : -1;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 bg-white text-black animate-fade-in">
      
      <div className="border-b border-neutral-200 pb-4 text-center">
        <h1 className="text-3xl font-black uppercase tracking-tight text-black">Track Your Shipment</h1>
        <p className="text-xs text-neutral-400 mt-1">Monitor the live tailoring and shipping progress of your premium garments.</p>
      </div>

      {/* Input box */}
      <form onSubmit={handleTrackSearch} className="max-w-md mx-auto space-y-2 text-xs">
        <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest block text-left">Recipient Order Tracking ID</label>
        <div className="flex gap-2">
          <input
            type="text"
            required
            placeholder="e.g. MS-123456"
            value={trackId}
            onChange={(e) => setTrackId(e.target.value)}
            className="w-full bg-white border border-neutral-200 rounded-xl p-3 outline-none uppercase font-mono tracking-wider font-bold text-center text-sm text-black focus:border-[#E60023]"
          />
          <button
            type="submit"
            className="bg-[#E60023] text-white px-6 py-3 rounded-xl font-bold tracking-widest uppercase hover:opacity-90 transition-colors text-xs shadow-md"
          >
            TRACK
          </button>
        </div>
        <p className="text-[10px] text-neutral-400 text-left">Tip: Place a Cash on Delivery order to generate a tracking number! Example: try typing "MS-100001" or your receipt codes.</p>
      </form>

      {/* Stepper display */}
      {searchId && (
        matchedOrder ? (
          <div className="bg-white border border-neutral-200 p-6 sm:p-8 rounded-3xl space-y-10 shadow-sm text-left">
            
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-neutral-200 pb-4">
              <div>
                <p className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest">ORDER TRACKING ID</p>
                <p className="text-base font-mono font-black text-[#E60023]">{matchedOrder.trackingNumber}</p>
              </div>
              <div className="sm:text-right text-xs">
                <p className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest">DESTINATION RECIPIENT</p>
                <p className="font-bold text-black">{matchedOrder.shippingAddress.fullName} • {matchedOrder.shippingAddress.city}</p>
              </div>
            </div>

            {/* Steps layout */}
            <div className="relative pl-8 sm:pl-0 sm:flex sm:justify-between items-start gap-4">
              
              {/* Desktop Connecting Line */}
              <div className="hidden sm:block absolute top-5 left-8 right-8 h-1 bg-neutral-100 z-0">
                <div
                  className="h-full bg-[#E60023] transition-all duration-500"
                  style={{ width: `${(activeIndex / (steps.length - 1)) * 100}%` }}
                />
              </div>

              {steps.map((st, idx) => {
                const isPassed = idx <= activeIndex;
                const isActive = idx === activeIndex;

                return (
                  <div key={st.key} className="relative z-10 text-left sm:text-center space-y-2 pb-8 sm:pb-0 sm:flex-1">
                    
                    {/* Circle Indicator */}
                    <div className="absolute left-[-26px] top-1 sm:static mx-auto w-10 h-10 rounded-full border-2 flex items-center justify-center font-bold text-xs transition-all duration-300 shadow bg-white font-mono text-black"
                      style={{
                        borderColor: isPassed ? '#E60023' : '#E5E7EB',
                        backgroundColor: isActive ? '#E60023' : (isPassed ? '#FEF2F2' : '#FFFFFF'),
                        color: isActive ? '#FFFFFF' : (isPassed ? '#E60023' : '#9CA3AF')
                      }}
                    >
                      {isPassed ? <CheckCircle className="w-5 h-5 text-white" /> : `0${idx + 1}`}
                    </div>

                    <div className="space-y-1">
                      <h4 className={`text-xs font-black uppercase tracking-wider ${isPassed ? 'text-black' : 'text-neutral-400'}`}>
                        {st.label}
                      </h4>
                      <p className="text-[10px] text-neutral-400 leading-normal max-w-xs sm:mx-auto">
                        {st.desc}
                      </p>
                    </div>

                  </div>
                );
              })}

            </div>

            {/* Courier specs brief */}
            <div className="bg-white p-4 border border-neutral-200 rounded-xl flex items-center justify-between gap-4 text-xs shadow-sm">
              <div className="flex items-center gap-3">
                <Truck className="w-5 h-5 text-[#E60023]" />
                <div>
                  <h4 className="font-bold text-black">Complimentary Courier Partner</h4>
                  <p className="text-[10px] text-neutral-400 font-normal">DHL Global Express Logistics Bangladesh</p>
                </div>
              </div>
              <span className="font-mono text-xs font-black uppercase text-[#E60023] bg-red-50 px-2.5 py-0.5 rounded-full">{matchedOrder.status}</span>
            </div>

          </div>
        ) : (
          <div className="bg-amber-50 border border-amber-100 p-6 rounded-3xl text-center space-y-2 max-w-md mx-auto shadow-sm">
            <HelpCircle className="w-10 h-10 text-amber-500 mx-auto" />
            <h3 className="font-bold uppercase text-amber-800 text-sm">Tracking ID Not Found</h3>
            <p className="text-xs text-neutral-500">We couldn't locate active DHL packages filed under "{searchId}" in our offline sandbox. Double check your code values.</p>
          </div>
        )
      )}

    </div>
  );
}

// ==========================================
// 5. LOGIN VIEW
// ==========================================
interface LoginViewProps {
  onLogin: (user: any) => void;
  onNavigate: (view: string, params?: any) => void;
  onToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
}

export function LoginView({ onLogin, onNavigate, onToast }: LoginViewProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      onToast('Please enter both email and password.', 'error');
      return;
    }

    if (email === 'admin@mahmud.com' && password === '11111') {
      onLogin({ id: 'u-admin', email, name: 'Admin Mahmud', role: 'admin' });
      onToast('Welcome back, Admin Mahmud! Full controller console unlocked.', 'success');
      onNavigate('admin');
    } else {
      onLogin({ id: 'u-patron', email, name: email.split('@')[0], role: 'user' });
      onToast('Login successful! Welcome back to your patron portal.', 'success');
      onNavigate('dashboard');
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-16 bg-white text-black animate-fade-in">
      
      <div className="bg-white border border-neutral-200 p-8 rounded-3xl shadow-xl space-y-6 text-left">
        
        <div className="text-center space-y-2">
          <span className="font-extrabold text-2xl tracking-[0.15em] text-black">MAHMUD</span>
          <p className="text-[8px] font-bold tracking-[0.45em] text-[#E60023] -mt-2">SHOPPING</p>
          <p className="text-xs text-neutral-400 mt-2">Sign in to track orders, addresses, and secure profiles.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          
          <div className="space-y-1">
            <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Email Address</label>
            <div className="relative">
              <input
                type="email" required placeholder="patron@luxury.com"
                value={email} onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-white border border-neutral-200 rounded-lg py-3 pl-9 pr-3 outline-none focus:border-[#E60023] text-black"
              />
              <MapPin className="absolute left-3 top-3.5 w-4 h-4 text-neutral-400" />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Password</label>
            <div className="relative">
              <input
                type="password" required placeholder="••••••••"
                value={password} onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-white border border-neutral-200 rounded-lg py-3 pl-9 pr-3 outline-none focus:border-[#E60023] text-black"
              />
              <Lock className="absolute left-3 top-3.5 w-4 h-4 text-neutral-400" />
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-[#E60023] hover:opacity-90 text-white py-3.5 rounded-xl font-bold tracking-widest uppercase transition-colors text-xs shadow-md"
          >
            SIGN IN TO ATELIER PORTAL
          </button>

        </form>

        <div className="bg-red-50 border border-red-200 p-3.5 rounded-xl space-y-1 text-[10px] text-[#E60023]">
          <p className="font-extrabold uppercase">Simulated Admin Credentials:</p>
          <p>Email: <span className="font-mono font-bold select-all">admin@mahmud.com</span></p>
          <p>Password: <span className="font-mono font-bold select-all">11111</span></p>
          <p className="font-normal text-neutral-500 mt-1">(Or type any credentials to test guest patron dashboards!)</p>
        </div>

        <div className="text-center pt-2">
          <button
            onClick={() => onNavigate('register')}
            className="text-xs font-bold text-neutral-500 hover:text-[#E60023] hover:underline"
          >
            Don't have a luxury account? Register
          </button>
        </div>

      </div>

    </div>
  );
}

// ==========================================
// 6. REGISTER VIEW
// ==========================================
interface RegisterViewProps {
  onLogin: (user: any) => void;
  onNavigate: (view: string, params?: any) => void;
  onToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
}

export function RegisterView({ onLogin, onNavigate, onToast }: RegisterViewProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !password.trim()) {
      onToast('Please complete all inputs.', 'error');
      return;
    }

    onLogin({ id: `u-reg-${Date.now()}`, email, name, role: 'user' });
    onToast(`Welcome to Mahmud Shopping, ${name}! Account registered.`, 'success');
    onNavigate('dashboard');
  };

  return (
    <div className="max-w-md mx-auto px-4 py-16 bg-white text-black animate-fade-in">
      
      <div className="bg-white border border-neutral-200 p-8 rounded-3xl shadow-xl space-y-6 text-left">
        
        <div className="text-center space-y-2">
          <span className="font-extrabold text-2xl tracking-[0.15em] text-black">REGISTER</span>
          <p className="text-[8px] font-bold tracking-[0.45em] text-[#E60023] -mt-2">PATRON ACCOUNT</p>
          <p className="text-xs text-neutral-400 mt-2">Create details to unlock seasonal capsule sales.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          
          <div className="space-y-1">
            <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Full Name</label>
            <input
              type="text" required placeholder="Liam Mahmud"
              value={name} onChange={(e) => setName(e.target.value)}
              className="w-full bg-white border border-neutral-200 rounded-lg py-3 px-3 outline-none focus:border-[#E60023] text-black"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Email Address</label>
            <input
              type="email" required placeholder="patron@luxury.com"
              value={email} onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-white border border-neutral-200 rounded-lg py-3 px-3 outline-none focus:border-[#E60023] text-black"
            />
          </div>

          <div className="space-y-1">
            <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Password Code</label>
            <input
              type="password" required placeholder="••••••••"
              value={password} onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-white border border-neutral-200 rounded-lg py-3 px-3 outline-none focus:border-[#E60023] text-black"
            />
          </div>

          <button
            type="submit"
            className="w-full bg-[#E60023] hover:opacity-90 text-white py-3.5 rounded-xl font-bold tracking-widest uppercase transition-colors text-xs shadow-md"
          >
            REGISTER LUXURY PATRON
          </button>

        </form>

        <div className="text-center pt-2">
          <button
            onClick={() => onNavigate('login')}
            className="text-xs font-bold text-neutral-500 hover:text-[#E60023] hover:underline"
          >
            Already registered? Login here
          </button>
        </div>

      </div>

    </div>
  );
}

// ==========================================
// 7. CONTACT VIEW
// ==========================================
export function ContactView({ onToast }: { onToast: (msg: string, type?: 'success' | 'info' | 'error') => void }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [comment, setComment] = useState('');

  const handleInquirySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !comment.trim()) {
      onToast('Please complete all contact inputs.', 'error');
      return;
    }
    onToast('Your couture inquiry was transmitted to our Dhaka concierge team!', 'success');
    setName('');
    setEmail('');
    setComment('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12 bg-white text-black animate-fade-in">
      
      <div className="border-b border-neutral-200 pb-4 text-center">
        <h1 className="text-3xl font-black uppercase tracking-tight text-black">Atelier Contact</h1>
        <p className="text-xs text-neutral-400 mt-1">Connect with our Dhaka atelier concierges for tailored fitting assistance.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
        
        {/* Left: Contact Form */}
        <div className="bg-white border border-neutral-200 p-6 sm:p-8 rounded-3xl shadow-sm text-left space-y-4">
          <h3 className="text-xs font-black uppercase tracking-widest text-black border-l-2 border-[#E60023] pl-3">Transmit Inquiry</h3>
          
          <form onSubmit={handleInquirySubmit} className="space-y-4 text-xs">
            <div className="space-y-1">
              <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Recipient Name</label>
              <input
                type="text" required placeholder="Liam Mahmud"
                value={name} onChange={(e) => setName(e.target.value)}
                className="w-full bg-white border border-neutral-200 rounded-lg p-3 outline-none focus:border-[#E60023] text-black"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Email Address</label>
              <input
                type="email" required placeholder="name@luxury.com"
                value={email} onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-white border border-neutral-200 rounded-lg p-3 outline-none focus:border-[#E60023] text-black"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Inquiry Details (Bespoke Sizing details)</label>
              <textarea
                required rows={4} placeholder="Describe size queries, velvet blazer linings, order custom adjustments..."
                value={comment} onChange={(e) => setComment(e.target.value)}
                className="w-full bg-white border border-neutral-200 rounded-lg p-3 outline-none focus:border-[#E60023] text-black"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-[#E60023] hover:opacity-90 text-white py-3.5 rounded-xl font-bold tracking-widest uppercase text-xs shadow-md"
            >
              TRANSMIT SECURE INQUIRY
            </button>
          </form>
        </div>

        {/* Right: Atelier Address Details */}
        <div className="space-y-6 text-left">
          
          <div className="space-y-2">
            <span className="text-[#E60023] font-bold uppercase tracking-wider text-xs">THE DHAKA HEADQUARTERS</span>
            <h3 className="text-xl font-black uppercase text-black">Mahmud Shopping Dhaka Atelier</h3>
            <p className="text-xs text-neutral-500 leading-relaxed">
              Our state-of-the-art flagship boutique stands centered in Gulshan, Dhaka, housing premium AW26 catalogs, tailored suites fitting salons, and a dedicated bKash concierge desk.
            </p>
          </div>

          <div className="space-y-4 pt-4">
            
            <div className="flex items-start gap-4 text-xs font-bold">
              <MapPin className="w-5 h-5 text-[#E60023] mt-0.5" />
              <div>
                <h4 className="text-black">FLAGSHIP ADDRESS</h4>
                <p className="text-[10px] text-neutral-400 font-normal mt-0.5">12 Royal Avenue, Block E, Gulshan-2, Dhaka, Bangladesh</p>
              </div>
            </div>

            <div className="flex items-start gap-4 text-xs font-bold">
              <Phone className="w-5 h-5 text-[#E60023] mt-0.5" />
              <div>
                <h4 className="text-black">PHONE CONCIERGE</h4>
                <p className="text-[10px] text-neutral-400 font-normal mt-0.5">Atelier Line: +880 1712-345678 (10:00 AM — 09:00 PM BST)</p>
              </div>
            </div>

            <div className="flex items-start gap-4 text-xs font-bold">
              <Mail className="w-5 h-5 text-[#E60023] mt-0.5" />
              <div>
                <h4 className="text-black">EMAIL ENVOY</h4>
                <p className="text-[10px] text-neutral-400 font-normal mt-0.5">General inquiries: concierge@mahmudshopping.com</p>
              </div>
            </div>

          </div>

          <div className="bg-white border border-neutral-200 p-4 rounded-2xl flex items-center gap-3 text-xs text-neutral-500 shadow-sm">
            <ShieldCheck className="w-5 h-5 text-emerald-500 shrink-0" />
            <span>SSL Secured transmissions. Concierge responses arrive within 12 business hours.</span>
          </div>

        </div>

      </div>

    </div>
  );
}

// ==========================================
// 8. ABOUT US VIEW
// ==========================================
export function AboutView() {
  return (
    <div className="max-w-4xl mx-auto px-4 py-16 space-y-10 bg-white text-black text-left animate-fade-in">
      <div className="border-b border-neutral-200 pb-4 text-center">
        <span className="text-[#E60023] font-bold tracking-[0.3em] text-[10px] uppercase">SINCE 2012</span>
        <h1 className="text-3xl font-black uppercase tracking-tight text-black">Atelier History</h1>
        <p className="text-xs text-neutral-400 mt-1">Fine garment tailoring and luxury lifestyle curators.</p>
      </div>

      <div className="space-y-6 text-xs text-neutral-600 leading-relaxed">
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center pt-4">
          <div className="space-y-4">
            <h3 className="text-sm font-black uppercase tracking-wider text-black">Our Philosophy</h3>
            <p>
              At Mahmud Shopping, we believe fashion is not merely about garments; it represents an architectural manifestation of personality, stature, and vision.
            </p>
            <p>
              Founded in Dhaka in 2012, our workshop has catered to regional elites, importing fine merino wool directly from Milan and mulberry silks from Paris ateliers. We manage every single line of tailoring with high-frequency laser checks.
            </p>
          </div>
          <img src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=500&q=80" alt="" className="rounded-3xl shadow-lg h-64 object-cover w-full border border-neutral-200" />
        </div>

        <div className="border-t border-neutral-200 pt-8 space-y-4">
          <h3 className="text-sm font-black uppercase tracking-wider text-black">Fine Materials Atelier Guarantee</h3>
          <p>
            Every coat, velvet blazer, and patent heel bearing our royal monogram is backed by our Authenticity Guarantee. We discard synthetics in favor of 100% natural, biodegradable fabrics ensuring eyes-safe, comfort-rich wearability year-over-year.
          </p>
          <p>
            We partner with DHL Express to package and transport our capsule items inside temperature-controlled boxes, ensuring the fabric arrives at your doorstep in pristine condition.
          </p>
        </div>

      </div>
    </div>
  );
}

// ==========================================
// 9. TERMS & PRIVACY POLICY VIEW
// ==========================================
export function TermsView() {
  return (
    <div className="max-w-3xl mx-auto px-4 py-16 space-y-6 text-left bg-white text-black animate-fade-in text-xs">
      <h1 className="text-2xl font-black uppercase border-b border-neutral-200 pb-4 text-black">Terms & Conditions</h1>
      <p className="text-neutral-500">Effective: June 2026</p>
      <p>Welcome to Mahmud Shopping. By accessing our luxury portal and placing orders, you agree to comply with our Terms of Service charter:</p>
      
      <div className="space-y-4">
        <h4 className="font-bold text-black uppercase">1. Sizing Adjustments</h4>
        <p className="text-neutral-500">Each garment fits according to standard luxury specifications. Patrons requesting custom fitting adjustments must note precise measurements in the order details during checkout.</p>
        
        <h4 className="font-bold text-black uppercase">2. bKash payment verification</h4>
        <p className="text-neutral-500">bKash wallet transactions are executed under strict Bangladesh bank guidelines. False bKash sandbox entries are checked and flagged immediately by our local ledger database.</p>
        
        <h4 className="font-bold text-black uppercase">3. DHL Delivery timelines</h4>
        <p className="text-neutral-500">Standard shipment takes 24-48 hours inside Dhaka division, and up to 5 business days for regional divisions in Bangladesh.</p>
      </div>
    </div>
  );
}

export function PrivacyView() {
  return (
    <div className="max-w-3xl mx-auto px-4 py-16 space-y-6 text-left bg-white text-black animate-fade-in text-xs">
      <h1 className="text-2xl font-black uppercase border-b border-neutral-200 pb-4 text-black">Privacy Policy Charter</h1>
      <p className="text-neutral-500">Effective: June 2026</p>
      <p>Mahmud Shopping respects your GDPR and local digital privacy charters. Here is how we protect your information:</p>

      <div className="space-y-4">
        <h4 className="font-bold text-black uppercase">1. Data Storage</h4>
        <p className="text-neutral-500">Your shopping bag, favorites wishlist, credentials, and billing details are stored securely inside client-side LocalStorage. We do not transmit or sell user email booklets to third-party marketing brokers.</p>

        <h4 className="font-bold text-black uppercase">2. Payment Security</h4>
        <p className="text-neutral-500">All payment options (Cash on Delivery and bKash transaction tokens) are processed over end-to-end 256-Bit SSL channels, ensuring complete credential safety.</p>
      </div>
    </div>
  );
}

// ==========================================
// 10. FAQ VIEW
// ==========================================
export function FaqView() {
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  const list = [
    { q: 'How does the bKash checkout simulation operate?', a: 'During checkout, selecting the bKash payment method triggers our secure sandbox gateway simulator modal. To successfully complete payment: type your 11-digit wallet number, enter simulated OTP "123456", and enter simulated PIN "11111". The order will immediately process as "Paid"!' },
    { q: 'What is the DHL Delivery policy in Bangladesh?', a: 'We provide complimentary premium DHL Express delivery on all orders over $500. For orders under $500, a flat $15 courier surcharge is added to cover secure transport boxes.' },
    { q: 'Can I swap a tailored suit if it does not fit?', a: 'Absolutely. We provide a 30-Day Bespoke Swap guarantee. If your wool coat or pleated suit trouser requires adjustments, simply contact our Gulshan salon to request a complimentary courier swap.' },
    { q: 'How can I unlock the Admin Panel and manage inventory?', a: 'To access our admin panel, simply navigate to the login page and type the simulated administrator credentials: Email "admin@mahmud.com" and Password "11111". You will unlock analytics graphs, dynamic product CRUD controls, and order dispatch status managers!' }
  ];

  return (
    <div className="max-w-3xl mx-auto px-4 py-16 space-y-8 bg-white text-black text-left animate-fade-in">
      <div className="border-b border-neutral-200 pb-4 text-center">
        <h1 className="text-3xl font-black uppercase tracking-tight text-black">Atelier Frequently Asked Questions</h1>
        <p className="text-xs text-neutral-400 mt-1">Quick insights into bKash pay, custom sizing, and DHL delivery logistics.</p>
      </div>

      <div className="space-y-4 text-xs">
        {list.map((item, idx) => {
          const isOpen = openIdx === idx;
          return (
            <div
              key={idx}
              className="border border-neutral-200 rounded-2xl bg-white overflow-hidden shadow-sm"
            >
              <button
                onClick={() => setOpenIdx(isOpen ? null : idx)}
                className="w-full text-left p-5 font-black uppercase tracking-wider flex justify-between items-center text-xs text-black"
              >
                <span>{item.q}</span>
                <span className="text-[#E60023] font-mono text-base">{isOpen ? '−' : '+'}</span>
              </button>
              {isOpen && (
                <div className="p-5 border-t border-neutral-200 leading-relaxed text-neutral-600">
                  {item.a}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
