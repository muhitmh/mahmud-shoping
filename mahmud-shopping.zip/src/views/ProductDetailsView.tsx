import React, { useState, useEffect } from 'react';
import { Star, Heart, ShoppingBag, BadgeCheck, Truck, RefreshCw, Send, ShieldAlert } from 'lucide-react';
import { Product, Review } from '../types';

interface ProductDetailsViewProps {
  productId: string;
  products: Product[];
  onAddToCart: (product: Product, size: string, color: { name: string; hex: string }, qty: number) => void;
  onAddToWishlist: (product: Product) => void;
  onNavigate: (view: string, params?: any) => void;
  onToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
  wishlistIds: string[];
}

export default function ProductDetailsView({
  productId,
  products,
  onAddToCart,
  onAddToWishlist,
  onNavigate,
  onToast,
  wishlistIds
}: ProductDetailsViewProps) {
  const product = products.find(p => p.id === productId) || products[0];

  const [selectedSize, setSelectedSize] = useState(product.sizes[0] || 'M');
  const [selectedColor, setSelectedColor] = useState(product.colors[0] || { name: 'Default', hex: '#000000' });
  const [quantity, setQuantity] = useState(1);
  const [activeImgIndex, setActiveImgIndex] = useState(0);
  const [activeTab, setActiveTab] = useState<'details' | 'specs' | 'reviews'>('details');

  // Review Submission State
  const [newReviewer, setNewReviewer] = useState('');
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState('');
  const [productReviews, setProductReviews] = useState<Review[]>(product.reviews);

  // Recently Viewed State
  const [recentlyViewed, setRecentlyViewed] = useState<Product[]>([]);

  // Track product change to reset active states
  useEffect(() => {
    if (product) {
      setSelectedSize(product.sizes[0] || 'M');
      setSelectedColor(product.colors[0] || { name: 'Default', hex: '#000000' });
      setQuantity(1);
      setActiveImgIndex(0);
      setProductReviews(product.reviews);
      
      // Update Recently Viewed in LocalStorage
      const stored = localStorage.getItem('recently_viewed_products');
      let list: string[] = stored ? JSON.parse(stored) : [];
      // Remove if already exists, then prepend
      list = list.filter(id => id !== product.id);
      list.unshift(product.id);
      // Slice to 4 items max
      const updatedList = list.slice(0, 4);
      localStorage.setItem('recently_viewed_products', JSON.stringify(updatedList));

      const matchedProducts = products.filter(p => updatedList.includes(p.id) && p.id !== product.id);
      setRecentlyViewed(matchedProducts);
    }
  }, [productId, product, products]);

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto p-16 text-center bg-white text-black">
        <h2 className="text-xl font-bold">Product not found.</h2>
        <button onClick={() => onNavigate('shop')} className="text-[#E60023] hover:underline">Return to Shop</button>
      </div>
    );
  }

  // Related products (same category, excluding current product)
  const relatedProducts = products
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReviewer.trim() || !newComment.trim()) {
      onToast('Please fill in both name and review comment.', 'error');
      return;
    }

    const createdReview: Review = {
      id: `rev-sub-${Date.now()}`,
      userName: newReviewer,
      rating: newRating,
      comment: newComment,
      date: new Date().toISOString().split('T')[0]
    };

    const updatedReviews = [createdReview, ...productReviews];
    setProductReviews(updatedReviews);
    product.reviews = updatedReviews; // persist in RAM
    product.reviewsCount = updatedReviews.length;
    
    // Recalculate average rating
    const totalRating = updatedReviews.reduce((sum, r) => sum + r.rating, 0);
    product.rating = Number((totalRating / updatedReviews.length).toFixed(1));

    onToast('Your review has been verified and posted!', 'success');
    setNewReviewer('');
    setNewComment('');
  };

  const handleAddToCart = () => {
    onAddToCart(product, selectedSize, selectedColor, quantity);
  };

  const handleBuyNow = () => {
    onAddToCart(product, selectedSize, selectedColor, quantity);
    onNavigate('checkout');
  };

  return (
    <div id="product-details-view" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-16 bg-white text-black animate-fade-in">
      
      {/* Top Breadcrumbs */}
      <div className="text-xs text-neutral-400 font-mono tracking-wider flex items-center gap-2 select-none">
        <span className="hover:text-black cursor-pointer" onClick={() => onNavigate('home')}>HOME</span>
        <span>/</span>
        <span className="hover:text-black cursor-pointer" onClick={() => onNavigate('shop')}>SHOP</span>
        <span>/</span>
        <span className="hover:text-black cursor-pointer uppercase" onClick={() => onNavigate('shop', { category: product.category })}>{product.category}</span>
        <span>/</span>
        <span className="text-black font-bold uppercase truncate max-w-[200px]">{product.name}</span>
      </div>

      {/* Main product configuration card */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        
        {/* Left column: Image Gallery (Span 7) */}
        <div className="lg:col-span-7 grid grid-cols-1 md:grid-cols-12 gap-4">
          
          {/* Vertical Thumbnails */}
          <div className="md:col-span-2 flex md:flex-col gap-2.5 order-2 md:order-1">
            {product.images.map((img, idx) => (
              <button
                key={idx}
                onClick={() => setActiveImgIndex(idx)}
                className={`w-16 h-16 md:w-20 md:h-20 rounded-xl overflow-hidden border-2 p-0.5 transition-all ${
                  idx === activeImgIndex ? 'border-[#E60023] scale-105 shadow' : 'border-neutral-200 opacity-60'
                }`}
              >
                <img src={img} alt="" className="w-full h-full object-cover rounded-lg" />
              </button>
            ))}
          </div>

          {/* Active Featured Image with zoom trigger */}
          <div className="md:col-span-10 order-1 md:order-2 bg-white border border-neutral-200 rounded-3xl p-6 relative flex items-center justify-center min-h-[350px] sm:min-h-[450px]">
            <img
              src={product.images[activeImgIndex]}
              alt={product.name}
              className="max-h-[420px] sm:max-h-[500px] object-contain rounded-2xl transition-transform duration-500 hover:scale-105"
            />
            {product.isFlashSale && (
              <span className="absolute top-4 left-4 bg-[#E60023] text-white text-[10px] font-bold tracking-widest px-3 py-1 rounded-full font-mono shadow-md">
                ⚡ 24HR VENTURE MARKDOWN
              </span>
            )}
          </div>

        </div>

        {/* Right column: Attributes / Variants / Purchasing (Span 5) */}
        <div className="lg:col-span-5 space-y-6 bg-white border border-neutral-200 p-6 sm:p-8 rounded-3xl shadow-sm">
          
          <div className="space-y-3">
            <span className="text-[#E60023] font-bold tracking-[0.25em] text-[10px] uppercase block">{product.category}</span>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-black uppercase">
              {product.name}
            </h1>
            {product.tagline && (
              <p className="text-xs text-neutral-400 italic">{product.tagline}</p>
            )}
          </div>

          {/* Verification Rating row */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1 bg-amber-50 text-amber-600 px-2.5 py-1 rounded-lg">
              <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
              <span className="text-xs font-bold">{product.rating}</span>
            </div>
            <span className="text-xs text-neutral-400 font-bold uppercase tracking-wider">{productReviews.length} Verified Reviews</span>
            <span className="text-neutral-200">|</span>
            <span className="flex items-center gap-1 text-xs text-emerald-600 font-semibold">
              <BadgeCheck className="w-4 h-4" /> Original Atelier Tag
            </span>
          </div>

          {/* Price Tagging */}
          <div className="flex items-baseline gap-3 pt-2">
            <span className="text-3xl font-black text-[#E60023]">${product.price}</span>
            {product.originalPrice && (
              <span className="text-base text-neutral-400 line-through">${product.originalPrice}</span>
            )}
            {product.originalPrice && (
              <span className="bg-red-50 text-[#E60023] text-[9px] font-bold px-2 py-0.5 rounded-md font-mono">
                SAVE ${product.originalPrice - product.price}
              </span>
            )}
          </div>

          <p className="text-xs text-neutral-600 leading-relaxed">
            {product.description}
          </p>

          {/* Dynamic Color Selector */}
          {product.colors.length > 0 && (
            <div className="space-y-2">
              <span className="text-[10px] font-black uppercase tracking-wider text-neutral-400 block">
                Select Shade: <span className="text-black font-black">{selectedColor.name}</span>
              </span>
              <div className="flex gap-2">
                {product.colors.map((color) => (
                  <button
                    key={color.name}
                    onClick={() => setSelectedColor(color)}
                    className={`w-8 h-8 rounded-full border-2 p-0.5 transition-transform ${
                      selectedColor.name === color.name ? 'border-[#E60023] scale-110 shadow-md' : 'border-transparent'
                    }`}
                    style={{ backgroundColor: color.hex }}
                    title={color.name}
                  >
                    <span className="sr-only">{color.name}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Dynamic Size Selection */}
          {product.sizes.length > 0 && (
            <div className="space-y-2 pt-1">
              <div className="flex justify-between">
                <span className="text-[10px] font-black uppercase tracking-wider text-neutral-400 block">
                  Select Size: <span className="text-black font-black">{selectedSize}</span>
                </span>
                <button
                  onClick={() => onNavigate('faq')}
                  className="text-[10px] text-[#E60023] font-bold hover:underline"
                >
                  SIZE GUIDE
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((sz) => (
                  <button
                    key={sz}
                    onClick={() => setSelectedSize(sz)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold border transition-all ${
                      selectedSize === sz
                        ? 'border-[#E60023] bg-[#E60023] text-white shadow'
                        : 'border-neutral-200 text-black hover:border-[#E60023]'
                    }`}
                  >
                    {sz}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Quantity and Inventory Bar */}
          <div className="flex items-center justify-between border-t border-neutral-200 pt-4">
            <div className="space-y-1">
              <span className="text-[10px] font-black uppercase tracking-wider text-neutral-400 block">QUANTITY</span>
              <div className="flex items-center border border-neutral-200 rounded-xl bg-white">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-3.5 py-2 text-neutral-500 hover:text-black transition-colors"
                >
                  -
                </button>
                <span className="px-3 py-2 text-xs font-bold text-black">{quantity}</span>
                <button
                  onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                  className="px-3.5 py-2 text-neutral-500 hover:text-black transition-colors"
                >
                  +
                </button>
              </div>
            </div>

            <div className="text-right">
              <p className={`text-xs font-bold ${product.stock <= 5 ? 'text-[#E60023] animate-pulse' : 'text-neutral-400'}`}>
                {product.stock <= 5 ? `Urgent! Only ${product.stock} items left!` : `${product.stock} units ready`}
              </p>
              <div className="w-24 bg-neutral-100 h-1 rounded-full mt-1.5 overflow-hidden ml-auto">
                <div
                  className={`h-full rounded-full ${product.stock <= 5 ? 'bg-[#E60023]' : 'bg-emerald-550'}`}
                  style={{ width: `${Math.min(100, (product.stock / 25) * 100)}%` }}
                />
              </div>
            </div>
          </div>

          {/* Add to Cart / Wishlist Actions */}
          <div className="pt-4 space-y-2">
            <div className="flex gap-2">
              <button
                onClick={handleAddToCart}
                disabled={product.stock === 0}
                className="flex-1 border border-neutral-200 hover:border-[#E60023] hover:text-[#E60023] text-black py-4 px-6 rounded-xl text-xs font-black tracking-widest transition-all duration-300 flex items-center justify-center gap-2"
              >
                <ShoppingBag className="w-4 h-4 text-black" />
                ADD TO ATELIER BAG
              </button>
              <button
                onClick={() => onAddToWishlist(product)}
                className={`p-4 rounded-xl border transition-all ${
                  wishlistIds.includes(product.id)
                    ? 'border-[#E60023] bg-red-50 text-[#E60023]'
                    : 'border-neutral-200 hover:border-[#E60023]'
                }`}
                title="Save to Wishlist"
              >
                <Heart className={`w-4 h-4 ${wishlistIds.includes(product.id) ? 'fill-[#E60023] text-[#E60023]' : 'text-black'}`} />
              </button>
            </div>

            <button
              onClick={handleBuyNow}
              disabled={product.stock === 0}
              className="w-full bg-[#E60023] hover:opacity-90 text-white py-4 rounded-xl text-xs font-black tracking-widest transition-colors duration-300 uppercase shadow-md animate-pulse"
            >
              Express Checkout
            </button>
          </div>

          {/* Quick trust stamps */}
          <div className="grid grid-cols-2 gap-4 border-t border-neutral-200 pt-4 text-[10px] text-neutral-400 font-bold uppercase tracking-wider">
            <div className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-[#E60023]" />
              <span>Complimentary Courier</span>
            </div>
            <div className="flex items-center gap-2">
              <RefreshCw className="w-4 h-4 text-[#E60023]" />
              <span>30-Day Bespoke Swaps</span>
            </div>
          </div>

        </div>

      </div>

      {/* Description / Specs / Reviews Tabs switcher */}
      <section className="bg-white border border-neutral-200 rounded-3xl p-6 sm:p-8">
        
        {/* Navigation tabs */}
        <div className="flex border-b border-neutral-200 gap-6 pb-3">
          {[
            { id: 'details', label: 'Detailed Description' },
            { id: 'specs', label: 'Atelier Specifications' },
            { id: 'reviews', label: `Patron Reviews (${productReviews.length})` }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`text-xs font-black uppercase tracking-widest pb-2 relative transition-colors ${
                activeTab === tab.id
                  ? 'text-[#E60023]'
                  : 'text-neutral-400 hover:text-black'
              }`}
            >
              {tab.label}
              {activeTab === tab.id && (
                <span className="absolute bottom-0 left-0 w-full h-[2.5px] bg-[#E60023] rounded-full" />
              )}
            </button>
          ))}
        </div>

        {/* Tab content renders here */}
        <div className="pt-6 text-xs text-neutral-600 leading-relaxed">
          {activeTab === 'details' && (
            <div className="space-y-4 text-left max-w-4xl">
              <p className="font-bold text-black uppercase tracking-wider">THE ARTISTRY BEHIND THE GARMENT</p>
              <p>{product.detailedDescription || product.description}</p>
              <p>Each piece is examined under custom lighting meters and undergoes stress checks on structural lines to ensure high-frequency wearability. All stitch boundaries are heat-welded and closed by senior garment weavers.</p>
            </div>
          )}

          {activeTab === 'specs' && (
            <div className="max-w-xl">
              <table className="w-full border-collapse">
                <tbody>
                  {product.specifications.map((spec, idx) => (
                    <tr key={idx} className="border-b border-neutral-200 last:border-b-0">
                      <td className="py-3 font-bold text-neutral-400 uppercase tracking-wider w-1/3">{spec.label}</td>
                      <td className="py-3 font-semibold text-black">{spec.value}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {activeTab === 'reviews' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
              
              {/* Existing Reviews List */}
              <div className="lg:col-span-7 space-y-6">
                {productReviews.length > 0 ? (
                  <div className="space-y-4 divide-y divide-neutral-200">
                    {productReviews.map((rev) => (
                      <div key={rev.id} className="pt-4 first:pt-0 space-y-2 text-left">
                        <div className="flex justify-between items-center">
                          <h4 className="font-bold text-black">{rev.userName}</h4>
                          <span className="text-[10px] text-neutral-400 font-mono">{rev.date}</span>
                        </div>
                        <div className="flex gap-0.5">
                          {[...Array(5)].map((_, i) => (
                            <Star key={i} className={`w-3 h-3 ${i < rev.rating ? 'fill-amber-400 text-amber-400' : 'text-neutral-200'}`} />
                          ))}
                        </div>
                        <p className="text-neutral-600 leading-relaxed">{rev.comment}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="py-8 text-center text-neutral-400">
                    No verified reviews yet. Be the first to share your experience with this haute couture piece!
                  </div>
                )}
              </div>

              {/* Submit Review Form */}
              <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-neutral-200 space-y-4">
                <h4 className="text-xs font-black tracking-widest uppercase text-black">Leave Atelier Feedback</h4>
                
                <form onSubmit={handleReviewSubmit} className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Your Full Name</label>
                    <input
                      type="text"
                      placeholder="e.g. Liam Mahmud"
                      value={newReviewer}
                      onChange={(e) => setNewReviewer(e.target.value)}
                      className="w-full bg-white border border-neutral-200 rounded-lg p-2.5 outline-none focus:border-[#E60023] text-black"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Atelier Score</label>
                    <select
                      value={newRating}
                      onChange={(e) => setNewRating(Number(e.target.value))}
                      className="w-full bg-white border border-neutral-200 rounded-lg p-2.5 outline-none font-bold text-black text-xs"
                    >
                      <option value="5">⭐⭐⭐⭐⭐ 5 Stars (Exceptional)</option>
                      <option value="4">⭐⭐⭐⭐ 4 Stars (Very Good)</option>
                      <option value="3">⭐⭐⭐ 3 Stars (Good)</option>
                      <option value="2">⭐⭐ 2 Stars (Average)</option>
                      <option value="1">⭐ 1 Star (Substandard)</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Verified Comment</label>
                    <textarea
                      placeholder="Review the fabric drape, stitch consistency, sizing, and premium delivery speed..."
                      rows={3}
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      className="w-full bg-white border border-neutral-200 rounded-lg p-2.5 outline-none focus:border-[#E60023] text-black"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-[#E60023] hover:opacity-90 text-white py-3 rounded-xl text-xs font-bold tracking-widest transition-colors flex items-center justify-center gap-2"
                  >
                    <Send className="w-3.5 h-3.5 text-white" />
                    SUBMIT VERIFIED REVIEW
                  </button>
                </form>
              </div>

            </div>
          )}
        </div>

      </section>

      {/* Related Products Section */}
      {relatedProducts.length > 0 && (
        <section className="space-y-6">
          <div className="border-b border-neutral-200 pb-4">
            <h2 className="text-xl font-black uppercase tracking-tight text-black">Atelier Companions</h2>
            <p className="text-xs text-neutral-400 mt-0.5">Patrons who purchased this also layered with these accessories and garments.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            {relatedProducts.map((prod) => (
              <div
                key={prod.id}
                onClick={() => onNavigate('product-details', { productId: prod.id })}
                className="group border border-neutral-200 rounded-2xl overflow-hidden cursor-pointer bg-white transition-all hover:shadow-lg"
              >
                <div className="aspect-square overflow-hidden bg-white p-4">
                  <img
                    src={prod.images[0]}
                    alt={prod.name}
                    className="w-full h-full object-contain transition-transform duration-500 group-hover:scale-105"
                  />
                </div>
                <div className="p-4 space-y-1">
                  <span className="text-[10px] text-neutral-400 uppercase font-bold">{prod.category}</span>
                  <h4 className="text-xs font-bold truncate group-hover:text-[#E60023] transition-colors text-black">{prod.name}</h4>
                  <span className="text-sm font-black block text-[#E60023]">${prod.price}</span>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Recently Viewed Products Section */}
      {recentlyViewed.length > 0 && (
        <section className="space-y-6">
          <div className="border-b border-neutral-200 pb-4">
            <h2 className="text-xl font-black uppercase tracking-tight text-black">Recently Inspected</h2>
            <p className="text-xs text-neutral-400 mt-0.5">Quick access to the premium garments you recently inspected in this session.</p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-6">
            {recentlyViewed.map((prod) => (
              <div
                key={prod.id}
                onClick={() => onNavigate('product-details', { productId: prod.id })}
                className="group flex gap-3 p-3 rounded-xl border border-neutral-200 hover:border-[#E60023] cursor-pointer transition-colors bg-white"
              >
                <img src={prod.images[0]} alt={prod.name} className="w-12 h-12 object-cover rounded-lg bg-white" />
                <div className="flex-1 min-w-0">
                  <h4 className="text-xs font-bold truncate text-black">{prod.name}</h4>
                  <span className="text-xs font-bold text-[#E60023]">${prod.price}</span>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

    </div>
  );
}
