import React, { useState } from 'react';
import { ShoppingBag, ArrowLeft, CheckCircle2, ShieldCheck, Truck, Ticket, Percent, Landmark } from 'lucide-react';
import { CartItem, Order, Address, Coupon } from '../types';

interface CheckoutViewProps {
  cart: CartItem[];
  currentUser: any;
  coupons: Coupon[];
  appliedCoupon: Coupon | null;
  onApplyCoupon: (coupon: Coupon | null) => void;
  onClearCart: () => void;
  onCreateOrder: (order: Order) => void;
  onNavigate: (view: string, params?: any) => void;
  onToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
}

export default function CheckoutView({
  cart,
  currentUser,
  coupons,
  appliedCoupon,
  onApplyCoupon,
  onClearCart,
  onCreateOrder,
  onNavigate,
  onToast
}: CheckoutViewProps) {
  // Address State
  const [fullName, setFullName] = useState(currentUser?.name || '');
  const [email, setEmail] = useState(currentUser?.email || '');
  const [phone, setPhone] = useState('');
  const [street, setStreet] = useState('');
  const [city, setCity] = useState('Dhaka');
  const [postalCode, setPostalCode] = useState('');
  const [country, setCountry] = useState('Bangladesh');
  const [orderNotes, setOrderNotes] = useState('');

  // Payment State
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'bkash'>('cod');
  
  // bKash Sandbox Modal simulation
  const [showBkashModal, setShowBkashModal] = useState(false);
  const [bkashStep, setBkashStep] = useState<'wallet' | 'otp' | 'pin' | 'processing' | 'success'>('wallet');
  const [bkashWalletNo, setBkashWalletNo] = useState('');
  const [bkashOtp, setBkashOtp] = useState('');
  const [bkashPin, setBkashPin] = useState('');

  // Post-purchase invoice display
  const [submittedOrder, setSubmittedOrder] = useState<Order | null>(null);

  // Summary Math
  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const shippingCost = subtotal >= 500 ? 0 : 15;
  let discountAmount = 0;
  if (appliedCoupon) {
    if (appliedCoupon.discountType === 'percentage') {
      discountAmount = Math.round(subtotal * (appliedCoupon.value / 100));
    } else {
      discountAmount = appliedCoupon.value;
    }
  }
  const finalTotal = Math.max(0, subtotal + shippingCost - discountAmount);

  const handlePlaceOrder = () => {
    // Basic Form validation
    if (!fullName.trim() || !email.trim() || !phone.trim() || !street.trim() || !postalCode.trim()) {
      onToast('Please fill in all mandatory billing and shipping inputs.', 'error');
      return;
    }

    if (paymentMethod === 'bkash') {
      // Trigger interactive bKash gateway modal
      setShowBkashModal(true);
      setBkashStep('wallet');
    } else {
      // Direct Cash on Delivery placement
      completeOrderPlacement('cod', 'Pending');
    }
  };

  const completeOrderPlacement = (method: 'cod' | 'bkash', paymentStatus: 'Pending' | 'Paid') => {
    const shippingAddress: Address = {
      id: `addr-${Date.now()}`,
      label: 'Shipping Location',
      fullName,
      phone,
      street,
      city,
      postalCode,
      country,
      isDefault: true
    };

    const trackingNumber = `MS-${Math.floor(100000 + Math.random() * 900000)}`;

    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      trackingNumber,
      date: new Date().toISOString().split('T')[0],
      items: [...cart],
      subtotal,
      shippingCost,
      discount: discountAmount,
      total: finalTotal,
      status: 'Pending',
      paymentMethod: method,
      paymentStatus,
      shippingAddress,
      notes: orderNotes,
      couponCode: appliedCoupon?.code
    };

    onCreateOrder(newOrder);
    setSubmittedOrder(newOrder);
    onClearCart();
    onToast('Order created and registered with the Mahmud Atelier database!', 'success');
  };

  // bKash Simulated sandbox routines
  const handleBkashWalletSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (bkashWalletNo.length < 11) {
      onToast('Please enter a valid 11-digit bKash number.', 'error');
      return;
    }
    setBkashStep('otp');
  };

  const handleBkashOtpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (bkashOtp !== '123456') {
      onToast('Simulated Sandbox OTP is "123456".', 'error');
      return;
    }
    setBkashStep('pin');
  };

  const handleBkashPinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (bkashPin !== '11111') {
      onToast('Simulated Sandbox PIN is "11111".', 'error');
      return;
    }
    setBkashStep('processing');
    setTimeout(() => {
      setBkashStep('success');
      setTimeout(() => {
        setShowBkashModal(false);
        completeOrderPlacement('bkash', 'Paid');
      }, 1500);
    }, 2000);
  };

  // Render Post-purchase invoice display
  if (submittedOrder) {
    return (
      <div id="checkout-invoice" className="max-w-3xl mx-auto px-4 py-16 space-y-8 text-center animate-fade-in bg-white text-black">
        
        <div className="space-y-4">
          <CheckCircle2 className="w-16 h-16 text-emerald-500 mx-auto animate-bounce" />
          <h1 className="text-3xl font-black uppercase tracking-tight text-black">Purchase Successful</h1>
          <p className="text-xs text-neutral-400">Atelier Invoice Registered with the Mahmud Shopping Network.</p>
        </div>

        {/* Invoice Box */}
        <div className="bg-white border border-neutral-200 rounded-3xl p-6 sm:p-8 text-left space-y-6 shadow-sm">
          
          <div className="flex justify-between border-b border-neutral-200 pb-4">
            <div>
              <p className="text-[10px] text-neutral-400 font-bold uppercase tracking-widest">ORDER TRACKING ID</p>
              <p className="text-sm font-black text-[#E60023] font-mono select-all">{submittedOrder.trackingNumber}</p>
            </div>
            <div className="text-right">
              <p className="text-[10px] text-neutral-400 font-bold uppercase tracking-widest">DATE OF PURSUIT</p>
              <p className="text-xs font-bold text-black">{submittedOrder.date}</p>
            </div>
          </div>

          {/* Items breakdown list */}
          <div className="space-y-3">
            <p className="text-[10px] text-neutral-400 font-bold uppercase tracking-widest">Garments & Accessories</p>
            {submittedOrder.items.map((item, idx) => (
              <div key={idx} className="flex justify-between text-xs font-bold text-black">
                <span className="text-neutral-750">
                  {item.product.name} ({item.selectedSize}, {item.selectedColor.name}) <span className="text-neutral-400">x{item.quantity}</span>
                </span>
                <span>${item.product.price * item.quantity}</span>
              </div>
            ))}
          </div>

          {/* Delivery & billing details */}
          <div className="border-t border-neutral-200 pt-4 space-y-2">
            <p className="text-[10px] text-neutral-400 font-bold uppercase tracking-widest">Bespoke Shipping Destination</p>
            <p className="text-xs font-semibold text-black">
              {submittedOrder.shippingAddress.fullName} — {submittedOrder.shippingAddress.phone}
            </p>
            <p className="text-xs text-neutral-500">
              {submittedOrder.shippingAddress.street}, {submittedOrder.shippingAddress.city} {submittedOrder.shippingAddress.postalCode}, {submittedOrder.shippingAddress.country}
            </p>
          </div>

          {/* Price breakdowns */}
          <div className="border-t border-neutral-200 pt-4 space-y-2.5 text-xs">
            <div className="flex justify-between font-bold text-neutral-500">
              <span>Subtotal</span>
              <span className="text-black">${submittedOrder.subtotal}</span>
            </div>
            <div className="flex justify-between font-bold text-neutral-500">
              <span>DHL Delivery Express</span>
              <span className="text-black">{submittedOrder.shippingCost === 0 ? 'Complimentary' : `$${submittedOrder.shippingCost}`}</span>
            </div>
            {submittedOrder.discount > 0 && (
              <div className="flex justify-between font-bold text-[#E60023] font-mono">
                <span>Voucher Applied</span>
                <span>-${submittedOrder.discount}</span>
              </div>
            )}
            <div className="border-t border-neutral-200 pt-2 flex justify-between text-base font-black text-black">
              <span>Atelier Total</span>
              <span className="text-[#E60023] font-black">${submittedOrder.total}</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row justify-between items-center bg-white border border-neutral-200 p-4 rounded-xl gap-2">
            <div>
              <p className="text-[10px] text-neutral-400 font-bold uppercase tracking-widest">Atelier Gateway Method</p>
              <p className="text-xs font-bold text-black uppercase font-mono">{submittedOrder.paymentMethod} — Payment: {submittedOrder.paymentStatus}</p>
            </div>
            <div className="bg-red-50 text-[#E60023] px-3 py-1 rounded-full text-[10px] font-bold tracking-widest uppercase">
              Assigned to DHL Courier
            </div>
          </div>

        </div>

        {/* Buttons */}
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <button
            onClick={() => onNavigate('tracking', { trackId: submittedOrder.trackingNumber })}
            className="bg-[#E60023] hover:opacity-90 text-white px-8 py-3.5 rounded-xl text-xs font-bold tracking-widest transition-colors uppercase"
          >
            Track Active Delivery
          </button>
          <button
            onClick={() => onNavigate('home')}
            className="bg-black hover:opacity-90 text-white px-8 py-3.5 rounded-xl text-xs font-bold tracking-widest transition-colors uppercase"
          >
            Return to Atelier Home
          </button>
        </div>

      </div>
    );
  }

  return (
    <div id="checkout-view" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 bg-white text-black animate-fade-in">
      
      {/* Header */}
      <div className="border-b border-neutral-200 pb-4 flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-black uppercase tracking-tight text-black">Atelier Checkout</h1>
          <p className="text-xs text-neutral-400 mt-1">Provide secure details to register and launch shipment packaging.</p>
        </div>
        <button
          onClick={() => onNavigate('cart')}
          className="text-xs font-bold text-neutral-500 hover:text-[#E60023] flex items-center gap-1.5 uppercase tracking-widest transition-colors"
        >
          <ArrowLeft className="w-4 h-4 text-[#E60023]" /> Return to bag
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        
        {/* Left Column: Input Forms (Col Span 7) */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* Customer / Shipping forms */}
          <div className="bg-white border border-neutral-200 rounded-2xl p-6 sm:p-8 space-y-6 shadow-sm">
            <h3 className="text-xs font-black tracking-widest uppercase text-black border-l-2 border-[#E60023] pl-3">
              1. Customer Identity & Delivery Details
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              
              <div className="space-y-1 sm:col-span-2">
                <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Recipient Full Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Liam Mahmud"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="w-full bg-white border border-neutral-200 rounded-lg p-3 outline-none focus:border-[#E60023] text-black"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Email Address *</label>
                <input
                  type="email"
                  required
                  placeholder="name@luxury.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-white border border-neutral-200 rounded-lg p-3 outline-none focus:border-[#E60023] text-black"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Primary Mobile Phone *</label>
                <input
                  type="tel"
                  required
                  placeholder="e.g. +880 1712-345678"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-white border border-neutral-200 rounded-lg p-3 outline-none focus:border-[#E60023] text-black"
                />
              </div>

              <div className="space-y-1 sm:col-span-2">
                <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Street Address *</label>
                <input
                  type="text"
                  required
                  placeholder="House number, apartment, street name, block..."
                  value={street}
                  onChange={(e) => setStreet(e.target.value)}
                  className="w-full bg-white border border-neutral-200 rounded-lg p-3 outline-none focus:border-[#E60023] text-black"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">City *</label>
                <select
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full bg-white border border-neutral-200 rounded-lg p-3 outline-none font-bold text-black text-xs focus:border-[#E60023]"
                >
                  <option value="Dhaka">Dhaka</option>
                  <option value="Chattogram">Chattogram</option>
                  <option value="Sylhet">Sylhet</option>
                  <option value="Rajshahi">Rajshahi</option>
                  <option value="Khulna">Khulna</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Postal Code *</label>
                <input
                  type="text"
                  required
                  placeholder="1212"
                  value={postalCode}
                  onChange={(e) => setPostalCode(e.target.value)}
                  className="w-full bg-white border border-neutral-200 rounded-lg p-3 outline-none focus:border-[#E60023] text-black"
                />
              </div>

              <div className="space-y-1 sm:col-span-2">
                <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Country</label>
                <input
                  type="text"
                  readOnly
                  value={country}
                  className="w-full bg-neutral-100 border border-neutral-200 rounded-lg p-3 text-neutral-500 font-bold outline-none text-xs"
                />
              </div>

              <div className="space-y-1 sm:col-span-2">
                <label className="text-[9px] font-bold text-neutral-400 uppercase tracking-widest block">Custom Fitting or Order Notes (Optional)</label>
                <textarea
                  placeholder="Notes about bespoke stitching margins, delivery times, or gate pass access code..."
                  rows={3}
                  value={orderNotes}
                  onChange={(e) => setOrderNotes(e.target.value)}
                  className="w-full bg-white border border-neutral-200 rounded-lg p-3 outline-none focus:border-[#E60023] text-black"
                />
              </div>

            </div>
          </div>

          {/* Secure Payment gateways */}
          <div className="bg-white border border-neutral-200 rounded-2xl p-6 sm:p-8 space-y-6 shadow-sm">
            <h3 className="text-xs font-black tracking-widest uppercase text-black border-l-2 border-[#E60023] pl-3">
              2. Secure Atelier Gateway Selection
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-bold">
              
              {/* Cash on Delivery option */}
              <div
                onClick={() => setPaymentMethod('cod')}
                className={`border rounded-2xl p-4 cursor-pointer transition-all flex items-start gap-4 ${
                  paymentMethod === 'cod'
                    ? 'border-[#E60023] bg-red-50 text-[#E60023]'
                    : 'border-neutral-200 hover:border-[#E60023]'
                }`}
              >
                <Truck className="w-5 h-5 text-[#E60023] mt-0.5" />
                <div className="space-y-1 flex-1">
                  <h4 className="text-black">Cash On Delivery (COD)</h4>
                  <p className="text-[10px] text-neutral-400 font-normal leading-relaxed">Pay with cash upon verified hand-delivery by DHL express couriers in Bangladesh.</p>
                </div>
              </div>

              {/* bKash Payment option */}
              <div
                onClick={() => setPaymentMethod('bkash')}
                className={`border rounded-2xl p-4 cursor-pointer transition-all flex items-start gap-4 ${
                  paymentMethod === 'bkash'
                    ? 'border-pink-650 bg-pink-50/20 text-pink-600'
                    : 'border-neutral-200 hover:border-pink-500 text-black'
                }`}
              >
                <Landmark className="w-5 h-5 mt-0.5" />
                <div className="space-y-1 flex-1">
                  <h4>bKash Mobile Wallet</h4>
                  <p className="text-[10px] text-neutral-400 font-normal leading-relaxed">Instantly pay and verify your purchase via safe mobile PIN sandbox gateway. Get 5% cashback.</p>
                </div>
              </div>

            </div>
          </div>

        </div>

        {/* Right Column: Order summary and action checkout (Col Span 5) */}
        <div className="lg:col-span-5 bg-white border border-neutral-200 p-6 sm:p-8 rounded-2xl shadow-sm space-y-6">
          <h3 className="text-xs font-black tracking-widest text-black uppercase pb-3 border-b border-neutral-200">Your Checkout Summary</h3>
          
          {/* Miniature item catalog cards */}
          <div className="space-y-3.5 max-h-56 overflow-y-auto pr-2 divide-y divide-neutral-200">
            {cart.map((item) => (
              <div key={item.id} className="flex gap-3.5 pt-3 first:pt-0 items-center justify-between text-xs">
                <img src={item.product.images[0]} alt="" className="w-11 h-11 object-cover rounded-lg bg-white border border-neutral-200" />
                <div className="flex-1 min-w-0">
                  <h4 className="font-bold text-black truncate">{item.product.name}</h4>
                  <p className="text-[10px] text-neutral-400">{item.selectedSize} / {item.selectedColor.name} <span className="font-black">x{item.quantity}</span></p>
                </div>
                <span className="font-black text-[#E60023]">${item.product.price * item.quantity}</span>
              </div>
            ))}
          </div>

          {/* Pricing list */}
          <div className="border-t border-neutral-200 pt-4 space-y-2.5 text-xs">
            <div className="flex justify-between font-bold text-neutral-500">
              <span>Subtotal</span>
              <span className="text-black">${subtotal}</span>
            </div>
            <div className="flex justify-between font-bold text-neutral-500">
              <span>DHL Courier Cost</span>
              <span>{shippingCost === 0 ? <span className="text-emerald-600 uppercase font-mono text-[10px] tracking-wide font-black">COMPLIMENTARY</span> : <span className="text-black">${shippingCost}</span>}</span>
            </div>
            {appliedCoupon && (
              <div className="flex justify-between font-bold text-[#E60023] font-mono">
                <span>Voucher: {appliedCoupon.code}</span>
                <span>-${discountAmount}</span>
              </div>
            )}
            <div className="border-t border-neutral-200 pt-3 flex justify-between text-base font-black text-black">
              <span>Order Total</span>
              <span className="text-[#E60023] font-black">${finalTotal}</span>
            </div>
          </div>

          {/* Secure Place order Button */}
          <div className="pt-2">
            <button
              onClick={handlePlaceOrder}
              disabled={cart.length === 0}
              className={`w-full py-4 rounded-xl text-xs font-black tracking-widest transition-all duration-300 flex items-center justify-center gap-2 shadow-lg uppercase ${
                paymentMethod === 'bkash' 
                  ? 'bg-pink-600 hover:bg-pink-700 text-white' 
                  : 'bg-[#E60023] hover:opacity-90 text-white'
              }`}
            >
              <ShoppingBag className="w-4 h-4 text-white" />
              {paymentMethod === 'bkash' ? 'LAUNCH SECURE bKASH GATEWAY' : 'PLACE CASH ON DELIVERY ORDER'}
            </button>
            <div className="flex justify-center items-center gap-1.5 text-[9px] text-neutral-400 font-bold uppercase tracking-wider mt-3">
              <ShieldCheck className="w-4 h-4 text-emerald-600" /> Insured Delivery by Mahmud Shipping Bangladesh
            </div>
          </div>

        </div>

      </div>

      {/* 4. bKASH SANDBOX MODAL WINDOW */}
      {showBkashModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-md" onClick={() => setShowBkashModal(false)}></div>
          
          <div className="relative w-full max-w-sm bg-white rounded-3xl overflow-hidden shadow-2xl border border-neutral-200 z-10 font-sans">
            
            {/* bKash Pink Header Banner */}
            <div className="bg-pink-600 text-white p-6 text-center relative">
              <div className="flex justify-center items-center gap-2 mb-1.5">
                <span className="font-extrabold text-2xl tracking-wider uppercase text-white">bKash</span>
                <span className="text-[10px] font-bold border border-white/60 px-1.5 py-0.5 rounded uppercase text-white">Atelier Sandbox</span>
              </div>
              <p className="text-[10px] text-pink-100 uppercase tracking-widest">Atelier Gateway Transaction</p>
              
              <button
                onClick={() => setShowBkashModal(false)}
                className="absolute top-4 right-4 text-white hover:text-pink-200 font-bold text-xs"
              >
                CLOSE
              </button>
            </div>

            {/* bKash Interactive Sandbox Form Content */}
            <div className="p-6 bg-pink-50/10 text-neutral-800 space-y-4">
              
              {/* Transaction Amount Brief */}
              <div className="bg-pink-500/10 border border-pink-200 p-3 rounded-xl flex justify-between items-center text-xs font-bold text-pink-600">
                <span>Charge Amount:</span>
                <span className="font-mono text-base font-black">${finalTotal}</span>
              </div>

              {bkashStep === 'wallet' && (
                <form onSubmit={handleBkashWalletSubmit} className="space-y-4">
                  <div className="space-y-1.5 text-left">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block">Your 11-digit bKash Wallet Number</label>
                    <input
                      type="text"
                      placeholder="e.g. 01700000000"
                      value={bkashWalletNo}
                      onChange={(e) => setBkashWalletNo(e.target.value)}
                      className="w-full bg-white border-2 border-pink-100 rounded-xl p-3.5 outline-none font-bold font-mono tracking-widest text-center text-lg text-black focus:border-pink-600"
                    />
                  </div>
                  <div className="text-[10px] text-neutral-400 leading-relaxed text-center">
                    By clicking checkout, you simulate placing this transaction in the Mahmud local testing environment.
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-pink-600 hover:bg-pink-700 text-white font-bold py-3.5 rounded-xl text-xs tracking-widest uppercase transition-colors"
                  >
                    PROCEED WITH bKASH WALLET
                  </button>
                </form>
              )}

              {bkashStep === 'otp' && (
                <form onSubmit={handleBkashOtpSubmit} className="space-y-4">
                  <div className="space-y-1.5 text-left">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block">Enter simulated verification code (OTP)</label>
                    <input
                      type="text"
                      placeholder="Enter '123456'"
                      value={bkashOtp}
                      onChange={(e) => setBkashOtp(e.target.value)}
                      className="w-full bg-white border-2 border-pink-100 rounded-xl p-3.5 outline-none font-bold font-mono tracking-widest text-center text-lg text-black focus:border-pink-600"
                    />
                    <p className="text-[10px] text-center text-pink-600 font-bold">Type simulated OTP: 123456</p>
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-pink-600 hover:bg-pink-700 text-white font-bold py-3.5 rounded-xl text-xs tracking-widest uppercase transition-colors"
                  >
                    VERIFY CODE
                  </button>
                </form>
              )}

              {bkashStep === 'pin' && (
                <form onSubmit={handleBkashPinSubmit} className="space-y-4">
                  <div className="space-y-1.5 text-left">
                    <label className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block">Enter simulated 5-digit PIN</label>
                    <input
                      type="password"
                      placeholder="Enter '11111'"
                      maxLength={5}
                      value={bkashPin}
                      onChange={(e) => setBkashPin(e.target.value)}
                      className="w-full bg-white border-2 border-pink-100 rounded-xl p-3.5 outline-none font-bold font-mono tracking-[0.6em] text-center text-lg text-black focus:border-pink-600"
                    />
                    <p className="text-[10px] text-center text-pink-600 font-bold font-mono">Type sandbox PIN: 11111</p>
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-pink-600 hover:bg-pink-700 text-white font-bold py-3.5 rounded-xl text-xs tracking-widest uppercase transition-colors"
                  >
                    COMPLETE PAYMENT SECURELY
                  </button>
                </form>
              )}

              {bkashStep === 'processing' && (
                <div className="py-8 text-center space-y-4">
                  <div className="w-12 h-12 border-4 border-pink-600 border-t-transparent rounded-full animate-spin mx-auto" />
                  <p className="text-xs font-bold text-pink-600 animate-pulse uppercase tracking-wider">Verifying Ledger Transactions...</p>
                </div>
              )}

              {bkashStep === 'success' && (
                <div className="py-8 text-center space-y-4 animate-scale-up">
                  <CheckCircle2 className="w-12 h-12 text-pink-600 mx-auto animate-bounce" />
                  <p className="text-xs font-black text-pink-600 uppercase tracking-widest">Payment Completed successfully!</p>
                </div>
              )}

            </div>

            {/* bKash Footer dial logo */}
            <div className="bg-pink-600/10 border-t border-pink-100 py-3 text-center text-[10px] font-bold text-pink-600 font-mono">
              Dial *247# to check mobile balance
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
