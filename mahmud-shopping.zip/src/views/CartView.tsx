import React, { useState } from 'react';
import { ShoppingBag, Trash2, ArrowLeft, ArrowRight, Percent, ShieldCheck, Ticket } from 'lucide-react';
import { CartItem, Coupon } from '../types';

interface CartViewProps {
  cart: CartItem[];
  coupons: Coupon[];
  appliedCoupon: Coupon | null;
  onApplyCoupon: (coupon: Coupon | null) => void;
  onUpdateQuantity: (cartItemId: string, qty: number) => void;
  onRemoveFromCart: (cartItemId: string) => void;
  onNavigate: (view: string, params?: any) => void;
  onToast: (msg: string, type?: 'success' | 'info' | 'error') => void;
}

export default function CartView({
  cart,
  coupons,
  appliedCoupon,
  onApplyCoupon,
  onUpdateQuantity,
  onRemoveFromCart,
  onNavigate,
  onToast
}: CartViewProps) {
  const [couponInput, setCouponInput] = useState('');

  // Calculations
  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  
  // Shipping: Free above $500, else $15 flat rate
  const shippingCost = subtotal >= 500 || subtotal === 0 ? 0 : 15;

  // Coupon discount calculation
  let discountAmount = 0;
  if (appliedCoupon) {
    if (appliedCoupon.discountType === 'percentage') {
      discountAmount = Math.round(subtotal * (appliedCoupon.value / 100));
    } else {
      discountAmount = appliedCoupon.value;
    }
  }

  const finalTotal = Math.max(0, subtotal + shippingCost - discountAmount);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponInput.trim()) return;

    const matched = coupons.find(c => c.code.toUpperCase() === couponInput.toUpperCase());
    if (!matched) {
      onToast('Invalid voucher code. Please try a valid seasonal code.', 'error');
      return;
    }

    if (!matched.isActive) {
      onToast('Voucher is inactive or has expired.', 'error');
      return;
    }

    if (subtotal < matched.minSpend) {
      onToast(`Voucher requires a minimum spend of $${matched.minSpend} to apply.`, 'error');
      return;
    }

    onApplyCoupon(matched);
    onToast(`Voucher "${matched.code}" applied! You saved $${matched.discountType === 'percentage' ? `${matched.value}%` : `$${matched.value}`}.`, 'success');
    setCouponInput('');
  };

  const handleRemoveCoupon = () => {
    onApplyCoupon(null);
    onToast('Voucher code removed.', 'info');
  };

  return (
    <div id="cart-view" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8 bg-white text-black animate-fade-in">
      
      {/* Title */}
      <div className="border-b border-neutral-200 pb-4">
        <h1 className="text-3xl font-black uppercase tracking-tight text-black">Your Shopping Bag</h1>
        <p className="text-xs text-neutral-400 mt-1">Review the luxury couture pieces in your current purchase session.</p>
      </div>

      {cart.length > 0 ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          
          {/* Cart Items List (Col Span 8) */}
          <div className="lg:col-span-8 space-y-4">
            {cart.map((item) => {
              const productTotal = item.product.price * item.quantity;
              
              return (
                <div
                  key={item.id}
                  className="bg-white border border-neutral-200 rounded-2xl p-4 sm:p-5 shadow-sm hover:shadow-md transition-shadow flex flex-col sm:flex-row gap-5 items-center justify-between"
                >
                  {/* Left: Product Image & Selected Variants */}
                  <div className="flex items-center gap-4 w-full sm:w-auto">
                    <img
                      src={item.product.images[0]}
                      alt={item.product.name}
                      className="w-20 h-20 sm:w-24 sm:h-24 object-cover rounded-xl bg-white border border-neutral-200 p-1"
                    />
                    <div className="space-y-1.5 flex-1 min-w-0">
                      <span className="text-[9px] uppercase font-bold tracking-widest text-[#E60023] block">{item.product.category}</span>
                      <h3
                        onClick={() => onNavigate('product-details', { productId: item.product.id })}
                        className="text-xs sm:text-sm font-bold text-black hover:text-[#E60023] cursor-pointer truncate"
                      >
                        {item.product.name}
                      </h3>
                      
                      {/* Active variant badges */}
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold bg-neutral-100 text-neutral-800">
                          Size: {item.selectedSize}
                        </span>
                        <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-bold bg-neutral-100 text-neutral-800">
                          Shade: 
                          <span className="w-2.5 h-2.5 rounded-full border border-neutral-300" style={{ backgroundColor: item.selectedColor.hex }} />
                          {item.selectedColor.name}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Middle/Right: Adjust quantity and display total */}
                  <div className="flex items-center justify-between sm:justify-end gap-6 w-full sm:w-auto border-t sm:border-t-0 pt-3 sm:pt-0">
                    
                    {/* Quantity controls */}
                    <div className="flex items-center border border-neutral-200 rounded-xl bg-white">
                      <button
                        onClick={() => onUpdateQuantity(item.id, Math.max(1, item.quantity - 1))}
                        className="px-3 py-1.5 text-neutral-500 hover:text-black transition-colors font-bold"
                      >
                        -
                      </button>
                      <span className="px-2.5 text-xs font-bold text-black">{item.quantity}</span>
                      <button
                        onClick={() => onUpdateQuantity(item.id, Math.min(item.product.stock, item.quantity + 1))}
                        className="px-3 py-1.5 text-neutral-500 hover:text-black transition-colors font-bold"
                      >
                        +
                      </button>
                    </div>

                    {/* Price and delete option */}
                    <div className="text-right min-w-[100px] space-y-0.5">
                      <span className="text-xs text-neutral-400 block">${item.product.price} each</span>
                      <span className="text-sm font-black text-[#E60023] block">${productTotal}</span>
                    </div>

                    <button
                      onClick={() => onRemoveFromCart(item.id)}
                      className="p-2 text-[#E60023] hover:text-[#E60023]/80 transition-colors rounded-xl hover:bg-red-50"
                      title="Remove Item"
                    >
                      <Trash2 className="w-4.5 h-4.5" />
                    </button>

                  </div>

                </div>
              );
            })}

            {/* Back to shop navigation links */}
            <button
              onClick={() => onNavigate('shop')}
              className="flex items-center gap-2 text-xs font-bold text-neutral-500 hover:text-[#E60023] transition-colors uppercase tracking-widest py-2"
            >
              <ArrowLeft className="w-4 h-4 text-[#E60023]" /> Continue browsing couture
            </button>
          </div>

          {/* Checkout Summary Box (Col Span 4) */}
          <div className="lg:col-span-4 bg-white border border-neutral-200 p-6 rounded-2xl shadow-sm space-y-6">
            <h3 className="text-xs font-black tracking-widest text-black uppercase pb-3 border-b border-neutral-200">Order Summary</h3>
            
            {/* Promo Voucher input */}
            <form onSubmit={handleApplyCoupon} className="space-y-2">
              <label className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block">Apply Voucher Code</label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <input
                    type="text"
                    placeholder="Voucher code e.g. MAHMUD20"
                    value={couponInput}
                    onChange={(e) => setCouponInput(e.target.value)}
                    className="w-full text-xs bg-white border border-neutral-200 rounded-xl py-2.5 pl-9 pr-3 outline-none uppercase focus:border-[#E60023] font-bold text-black"
                  />
                  <Ticket className="absolute left-3 top-3 w-4 h-4 text-[#E60023]" />
                </div>
                <button
                  type="submit"
                  className="bg-[#E60023] text-white hover:opacity-90 px-4 py-2.5 rounded-xl text-xs font-bold tracking-wider transition-colors"
                >
                  APPLY
                </button>
              </div>
            </form>

            {/* Active voucher display */}
            {appliedCoupon && (
              <div className="bg-red-50 border border-red-200 rounded-xl p-3 flex justify-between items-center text-xs text-[#E60023] font-bold">
                <span className="flex items-center gap-1.5 uppercase font-mono">
                  <Percent className="w-4 h-4" /> Active: {appliedCoupon.code}
                </span>
                <button
                  onClick={handleRemoveCoupon}
                  className="text-[10px] text-neutral-500 hover:text-[#E60023] font-bold hover:underline"
                >
                  REMOVE
                </button>
              </div>
            )}

            {/* Price breakdown lists */}
            <div className="space-y-3.5 text-xs">
              <div className="flex justify-between font-bold text-neutral-500">
                <span>Atelier Subtotal</span>
                <span className="text-black">${subtotal}</span>
              </div>
              
              <div className="flex justify-between font-bold text-neutral-500">
                <span>DHL Express Delivery</span>
                <span>{shippingCost === 0 ? <span className="text-emerald-600 uppercase tracking-wider font-mono text-[10px]">COMPLIMENTARY</span> : `$${shippingCost}`}</span>
              </div>

              {appliedCoupon && (
                <div className="flex justify-between font-bold text-[#E60023] font-mono">
                  <span>Discount ({appliedCoupon.code})</span>
                  <span>-${discountAmount}</span>
                </div>
              )}

              <div className="border-t border-neutral-200 pt-3 flex justify-between text-base font-black text-black">
                <span>Estimated Total</span>
                <span className="text-[#E60023] text-lg font-black">${finalTotal}</span>
              </div>
            </div>

            {/* Free shipping dynamic bar indicator */}
            {subtotal < 500 && (
              <div className="bg-amber-50 p-3 rounded-xl space-y-1.5 border border-amber-100">
                <p className="text-[10px] font-bold text-amber-800 uppercase tracking-wide">
                  Add <span className="font-extrabold text-black">${500 - subtotal}</span> more for free DHL express
                </p>
                <div className="w-full bg-amber-200 h-1 rounded-full overflow-hidden">
                  <div className="h-full bg-amber-500" style={{ width: `${(subtotal / 500) * 100}%` }} />
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="space-y-3">
              <button
                onClick={() => onNavigate('checkout')}
                className="w-full bg-[#E60023] hover:opacity-90 text-white py-4 rounded-xl text-xs font-black tracking-widest transition-colors flex items-center justify-center gap-2 shadow-lg uppercase"
              >
                PROCEED TO SECURE CHECKOUT <ArrowRight className="w-4 h-4 text-white" />
              </button>
              <div className="flex justify-center items-center gap-2 text-[10px] text-neutral-400 font-bold uppercase tracking-wider">
                <ShieldCheck className="w-4.5 h-4.5 text-emerald-550" /> Secure 256-Bit SSL Atelier Gateways
              </div>
            </div>

          </div>

        </div>
      ) : (
        <div className="bg-white border border-neutral-200 rounded-3xl p-16 text-center space-y-4 max-w-2xl mx-auto shadow-sm">
          <ShoppingBag className="w-16 h-16 text-[#E60023] mx-auto" />
          <h3 className="text-xl font-bold text-black uppercase tracking-wider">Atelier Bag is Empty</h3>
          <p className="text-xs text-neutral-500 leading-relaxed">
            You haven't added any luxury wool coats, customized shoes, or silk dresses to your active purchase bag yet. Discover our catalogs to customize your lookbook.
          </p>
          <button
            onClick={() => onNavigate('shop')}
            className="bg-[#E60023] text-white hover:opacity-90 px-8 py-3.5 rounded-xl text-xs font-bold tracking-widest transition-colors shadow-sm"
          >
            DISCOVER WINTER CAPSULES
          </button>
        </div>
      )}

    </div>
  );
}
