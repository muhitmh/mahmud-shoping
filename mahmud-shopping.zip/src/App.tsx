import React, { useState, useEffect } from 'react';
import AnnouncementBar from './components/AnnouncementBar';
import NavigationBar from './components/NavigationBar';
import Footer from './components/Footer';
import QuickViewModal from './components/QuickViewModal';

// Views
import HomeView from './views/HomeView';
import ShopView from './views/ShopView';
import ProductDetailsView from './views/ProductDetailsView';
import CartView from './views/CartView';
import CheckoutView from './views/CheckoutView';
import DashboardView from './views/DashboardView';
import AdminView from './views/AdminView';

// Static Views
import {
  WishlistView,
  CategoriesView,
  SearchView,
  TrackingView,
  LoginView,
  RegisterView,
  ContactView,
  AboutView,
  TermsView,
  PrivacyView,
  FaqView
} from './views/StaticPages';

// Mock Data / Types
import { INITIAL_PRODUCTS, INITIAL_COUPONS, INITIAL_BANNERS } from './data/products';
import { Product, CartItem, Order, Coupon, Banner } from './types';

export default function App() {
  // --- 1. CORE DATA STATE (Backed by LocalStorage) ---
  const [products, setProducts] = useState<Product[]>(() => {
    const cached = localStorage.getItem('mahmud_products');
    return cached ? JSON.parse(cached) : INITIAL_PRODUCTS;
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    const cached = localStorage.getItem('mahmud_cart');
    return cached ? JSON.parse(cached) : [];
  });

  const [wishlist, setWishlist] = useState<Product[]>(() => {
    const cached = localStorage.getItem('mahmud_wishlist');
    return cached ? JSON.parse(cached) : [];
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const cached = localStorage.getItem('mahmud_orders');
    if (cached) return JSON.parse(cached);
    // Initial seeded order for testing the tracker immediately
    return [
      {
        id: 'ord-seed-001',
        trackingNumber: 'MS-100001',
        date: new Date().toISOString().split('T')[0],
        items: [
          {
            id: 'cart-seed-1',
            product: INITIAL_PRODUCTS[0],
            quantity: 1,
            selectedSize: 'M',
            selectedColor: INITIAL_PRODUCTS[0].colors[0]
          }
        ],
        subtotal: INITIAL_PRODUCTS[0].price,
        shippingCost: 0,
        discount: 0,
        total: INITIAL_PRODUCTS[0].price,
        status: 'Processing',
        paymentMethod: 'bkash',
        paymentStatus: 'Paid',
        shippingAddress: {
          id: 'addr-seed',
          label: 'Primary Home',
          fullName: 'Liam Mahmud',
          phone: '+880 1712-345678',
          street: '12 Royal Avenue, Block E, Gulshan-2',
          city: 'Dhaka',
          postalCode: '1212',
          country: 'Bangladesh',
          isDefault: true
        },
        notes: 'Hand-tailor the lapel stitching carefully.'
      }
    ];
  });

  const [coupons, setCoupons] = useState<Coupon[]>(() => {
    const cached = localStorage.getItem('mahmud_coupons');
    return cached ? JSON.parse(cached) : INITIAL_COUPONS;
  });

  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(() => {
    const cached = localStorage.getItem('mahmud_applied_coupon');
    return cached ? JSON.parse(cached) : null;
  });

  const [currentUser, setCurrentUser] = useState<any>(() => {
    const cached = localStorage.getItem('mahmud_user');
    return cached ? JSON.parse(cached) : null;
  });

  // --- 2. LAYOUT & NAVIGATION STATES ---
  const [currentView, setCurrentView] = useState<string>('home');
  const [viewParams, setViewParams] = useState<any>({});
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Theme state
  const [darkTheme, setDarkTheme] = useState<boolean>(false);

  // Loading skeleton state (triggers brief 500ms skeleton on route switches for realistic feedback)
  const [viewLoading, setViewLoading] = useState<boolean>(false);

  // Dynamic Toast Notification list
  const [toasts, setToasts] = useState<{ id: string; message: string; type: 'success' | 'info' | 'error' }[]>([]);

  // --- 3. CACHE SYNCHRONIZATION EFFECT ---
  useEffect(() => {
    localStorage.setItem('mahmud_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('mahmud_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('mahmud_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  useEffect(() => {
    localStorage.setItem('mahmud_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('mahmud_coupons', JSON.stringify(coupons));
  }, [coupons]);

  useEffect(() => {
    localStorage.setItem('mahmud_applied_coupon', JSON.stringify(appliedCoupon));
  }, [appliedCoupon]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('mahmud_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('mahmud_user');
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('mahmud_theme', 'light');
    document.documentElement.classList.remove('dark');
  }, []);

  // --- 4. TOAST DISPATCH SYSTEM ---
  const handleToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    const id = `toast-${Date.now()}`;
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3000);
  };

  // --- 5. NAVIGATION ROUTER ---
  const handleNavigate = (view: string, params: any = {}) => {
    setViewLoading(true);
    setCurrentView(view);
    setViewParams(params);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setTimeout(() => {
      setViewLoading(false);
    }, 300);
  };

  // --- 6. SHOPPING ACTIONS ---
  const handleAddToCart = (product: Product, quantity: number, size: string, color: { name: string; hex: string }) => {
    const existingIdx = cart.findIndex(
      (item) =>
        item.product.id === product.id &&
        item.selectedSize === size &&
        item.selectedColor.hex === color.hex
    );

    if (existingIdx > -1) {
      const updated = [...cart];
      updated[existingIdx].quantity += quantity;
      setCart(updated);
    } else {
      const newItem: CartItem = {
        id: `cart-item-${Date.now()}`,
        product,
        quantity,
        selectedSize: size,
        selectedColor: color
      };
      setCart([...cart, newItem]);
    }
    handleToast(`Added ${quantity}x "${product.name}" to your shopping bag!`, 'success');
  };

  const handleUpdateQuantity = (itemId: string, qty: number) => {
    if (qty <= 0) {
      setCart(cart.filter((item) => item.id !== itemId));
      handleToast('Garment removed from your shopping bag.', 'info');
    } else {
      setCart(cart.map((item) => (item.id === itemId ? { ...item, quantity: qty } : item)));
    }
  };

  const handleRemoveFromCart = (itemId: string) => {
    setCart(cart.filter((item) => item.id !== itemId));
    handleToast('Garment removed from your shopping bag.', 'info');
  };

  const handleAddToWishlist = (product: Product) => {
    const isSaved = wishlist.some((p) => p.id === product.id);
    if (isSaved) {
      setWishlist(wishlist.filter((p) => p.id !== product.id));
      handleToast('Removed from saved favorites.', 'info');
    } else {
      setWishlist([...wishlist, product]);
      handleToast('Added to your Saved Favorites booklet!', 'success');
    }
  };

  const handleRemoveFromWishlist = (product: Product) => {
    setWishlist(wishlist.filter((p) => p.id !== product.id));
    handleToast('Removed from saved favorites.', 'info');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setAppliedCoupon(null);
    handleToast('Successfully logged out from the patron portal.', 'info');
    handleNavigate('home');
  };

  // --- 7. DYNAMIC ROUTE SWITCHER RENDERER ---
  const renderView = () => {
    if (viewLoading) {
      // Elegant Skeleton Loading UI
      return (
        <div className="max-w-7xl mx-auto px-4 py-16 space-y-12 animate-pulse text-left">
          <div className="h-10 bg-neutral-200 dark:bg-neutral-800 w-1/3 rounded-xl" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="h-80 bg-neutral-100 dark:bg-neutral-800 rounded-3xl" />
            <div className="h-80 bg-neutral-100 dark:bg-neutral-800 rounded-3xl" />
            <div className="h-80 bg-neutral-100 dark:bg-neutral-800 rounded-3xl" />
          </div>
        </div>
      );
    }

    switch (currentView) {
      case 'home':
        return (
          <HomeView
            products={products}
            banners={INITIAL_BANNERS}
            onNavigate={handleNavigate}
            onQuickView={setQuickViewProduct}
            onAddToWishlist={handleAddToWishlist}
            wishlistIds={wishlist.map(p => p.id)}
            onToast={handleToast}
          />
        );
      case 'shop':
        return (
          <ShopView
            initialCategory={viewParams.category}
            products={products}
            wishlistIds={wishlist.map(p => p.id)}
            onNavigate={handleNavigate}
            onQuickView={setQuickViewProduct}
            onAddToWishlist={handleAddToWishlist}
          />
        );
      case 'product-details':
        return (
          <ProductDetailsView
            productId={viewParams.productId}
            products={products}
            wishlistIds={wishlist.map(p => p.id)}
            onNavigate={handleNavigate}
            onAddToCart={(product, size, color, qty) => handleAddToCart(product, qty, size, color)}
            onAddToWishlist={handleAddToWishlist}
            onToast={handleToast}
          />
        );
      case 'cart':
        return (
          <CartView
            cart={cart}
            coupons={coupons}
            appliedCoupon={appliedCoupon}
            onApplyCoupon={setAppliedCoupon}
            onUpdateQuantity={handleUpdateQuantity}
            onRemoveFromCart={handleRemoveFromCart}
            onNavigate={handleNavigate}
            onToast={handleToast}
          />
        );
      case 'checkout':
        return (
          <CheckoutView
            cart={cart}
            currentUser={currentUser}
            coupons={coupons}
            appliedCoupon={appliedCoupon}
            onApplyCoupon={setAppliedCoupon}
            onClearCart={() => setCart([])}
            onCreateOrder={(newOrder) => setOrders([newOrder, ...orders])}
            onNavigate={handleNavigate}
            onToast={handleToast}
          />
        );
      case 'dashboard':
        return (
          <DashboardView
            currentUser={currentUser}
            orders={orders}
            onNavigate={handleNavigate}
            onToast={handleToast}
          />
        );
      case 'admin':
        return (
          <AdminView
            products={products}
            orders={orders}
            coupons={coupons}
            banners={INITIAL_BANNERS}
            onUpdateProducts={setProducts}
            onUpdateOrders={setOrders}
            onUpdateCoupons={setCoupons}
            onNavigate={handleNavigate}
            onToast={handleToast}
          />
        );
      case 'wishlist':
        return (
          <WishlistView
            wishlist={wishlist}
            onRemoveFromWishlist={handleRemoveFromWishlist}
            onQuickView={setQuickViewProduct}
            onNavigate={handleNavigate}
          />
        );
      case 'categories':
        return <CategoriesView products={products} onNavigate={handleNavigate} />;
      case 'search':
        return (
          <SearchView
            initialQuery={searchQuery}
            products={products}
            onNavigate={handleNavigate}
            onQuickView={setQuickViewProduct}
          />
        );
      case 'tracking':
        return (
          <TrackingView
            initialTrackId={viewParams.trackId}
            orders={orders}
            onToast={handleToast}
          />
        );
      case 'login':
        return (
          <LoginView
            onLogin={setCurrentUser}
            onNavigate={handleNavigate}
            onToast={handleToast}
          />
        );
      case 'register':
        return (
          <RegisterView
            onLogin={setCurrentUser}
            onNavigate={handleNavigate}
            onToast={handleToast}
          />
        );
      case 'contact':
        return <ContactView onToast={handleToast} />;
      case 'about':
        return <AboutView />;
      case 'terms':
        return <TermsView />;
      case 'privacy':
        return <PrivacyView />;
      case 'faq':
        return <FaqView />;
      default:
        return (
          <div className="py-24 text-center">
            <h1 className="text-xl font-bold uppercase">View not Found</h1>
            <button onClick={() => handleNavigate('home')} className="mt-4 text-red-600 underline text-xs font-bold uppercase tracking-widest">
              Return to home
            </button>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-white text-black flex flex-col font-sans selection:bg-red-600 selection:text-white">
      
      {/* 1. Global Announcement Bar */}
      <AnnouncementBar />

      {/* 2. Sticky Custom Navigation Bar */}
      <NavigationBar
        currentView={currentView}
        onNavigate={handleNavigate}
        cartCount={cart.reduce((sum, item) => sum + item.quantity, 0)}
        wishlistCount={wishlist.length}
        searchQuery={searchQuery}
        setSearchQuery={(q) => {
          setSearchQuery(q);
          if (currentView !== 'search') {
            handleNavigate('search');
          }
        }}
        currentUser={currentUser}
        onLogout={handleLogout}
        products={products}
        isDarkMode={darkTheme}
        setIsDarkMode={setDarkTheme}
      />

      {/* 3. Dynamic Center Stage */}
      <main className="flex-1">
        {renderView()}
      </main>

      {/* 4. Global Footing info */}
      <Footer onNavigate={handleNavigate} onToast={handleToast} />

      {/* 5. Overlay Quick View preview modal */}
      {quickViewProduct && (
        <QuickViewModal
          product={quickViewProduct}
          onClose={() => setQuickViewProduct(null)}
          onAddToCart={(product, size, color, qty) => handleAddToCart(product, qty, size, color)}
          onAddToWishlist={handleAddToWishlist}
          onNavigate={handleNavigate}
          isInWishlist={wishlist.some(p => p.id === quickViewProduct.id)}
        />
      )}

      {/* 6. Active Floating Toast stack */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2.5 max-w-sm w-full pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`pointer-events-auto p-4 rounded-xl shadow-2xl border flex items-center justify-between text-xs font-bold uppercase tracking-wider animate-scale-up ${
              toast.type === 'success'
                ? 'bg-neutral-950 dark:bg-white text-white dark:text-neutral-950 border-neutral-800'
                : toast.type === 'error'
                ? 'bg-red-600 text-white border-red-700'
                : 'bg-neutral-800 text-neutral-200 border-neutral-700'
            }`}
          >
            <span>{toast.message}</span>
            <button
              onClick={() => setToasts((prev) => prev.filter((t) => t.id !== toast.id))}
              className="ml-3 font-mono hover:text-red-500 transition-colors"
            >
              ×
            </button>
          </div>
        ))}
      </div>

    </div>
  );
}
